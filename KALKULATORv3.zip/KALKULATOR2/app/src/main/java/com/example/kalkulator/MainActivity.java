package com.example.kalkulator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    Button button1, button2, button3, button4,button5, button6, button7, button8, button9, button0,buttonRowna, buttonPlus, buttonOdj, buttonMnoz, buttonDziel, buttonCzysc, buttonPrzec,buttonPot, buttonPier, buttonlog;
    TextView textView, textView2;
    EditText Edit;
    int i;
    float a,b;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button1 = findViewById(R.id.button1);
        button2 = findViewById(R.id.button2);
        button3 = findViewById(R.id.button);
        button4 = findViewById(R.id.button16);
        button5 = findViewById(R.id.button17);
        button6 = findViewById(R.id.button18);
        button7 = findViewById(R.id.button19);
        button8 = findViewById(R.id.button20);
        button9 = findViewById(R.id.button21);
        button0 = findViewById(R.id.button22);
        buttonRowna = findViewById(R.id.button4);
        buttonPlus = findViewById(R.id.button3);
        buttonOdj = findViewById(R.id.button24);
        buttonMnoz = findViewById(R.id.button25);
        buttonDziel = findViewById(R.id.button26);
        buttonCzysc = findViewById(R.id.button23);
        buttonPrzec = findViewById(R.id.button27);
        buttonPot = findViewById(R.id.button28);
        buttonPier = findViewById(R.id.button29);
        buttonlog = findViewById(R.id.button30);

        Edit = (EditText) findViewById(R.id.textView2);
        //textView = findViewById(R.id.textView2);
        textView.setText("");


        button1.setOnClickListener(new View.OnClickListener() { //przycisk 1
            @Override
            public void onClick(View v) {
                textView.setText(textView.getText()+"1");
            }
        });

        button2.setOnClickListener(new View.OnClickListener() { //Przycisk 2
            @Override
            public void onClick(View v) {
                textView.setText(textView.getText()+"2");
            }
        });
        button3.setOnClickListener(new View.OnClickListener() { //Przycisk 3
            @Override
            public void onClick(View v) {
                textView.setText(textView.getText()+"3");
            }
        });
        button4.setOnClickListener(new View.OnClickListener() { //Przycisk 4
            @Override
            public void onClick(View v) {
                textView.setText(textView.getText()+"4");
            }
        });
        button5.setOnClickListener(new View.OnClickListener() { //Przycisk 5
            @Override
            public void onClick(View v) {
                textView.setText(textView.getText()+"5");
            }
        });
        button6.setOnClickListener(new View.OnClickListener() { //Przycisk 6
            @Override
            public void onClick(View v) {
                textView.setText(textView.getText()+"6");
            }
        });
        button7.setOnClickListener(new View.OnClickListener() { //Przycisk 7
            @Override
            public void onClick(View v) {
                textView.setText(textView.getText()+"7");
            }
        });
        button8.setOnClickListener(new View.OnClickListener() { //Przycisk 8
            @Override
            public void onClick(View v) {
                textView.setText(textView.getText()+"8");
            }
        });
        button9.setOnClickListener(new View.OnClickListener() { //Przycisk 9
            @Override
            public void onClick(View v) {
                textView.setText(textView.getText()+"9");
            }
        });
        button0.setOnClickListener(new View.OnClickListener() { //Przycisk 0
            @Override
            public void onClick(View v) {
                textView.setText(textView.getText()+"0");
            }
        });
        buttonPlus.setOnClickListener(new View.OnClickListener() { //Przycisk +
            @Override
            public void onClick(View v) {
                //pobieranie wartości z pola textView
                if (Edit == null) {
                    Edit.setText("");
                } else {
                    a = Float.parseFloat(Edit.getText() + "");
                //    Edit = true;
                    Edit.setText(null);
                }

            //    i = Integer.parseInt(textView.getText().toString());
              //  textView.setText("");
            }
        });
        buttonRowna.setOnClickListener(new View.OnClickListener() { //przycisk =
            @Override
            public void onClick(View v) {
                int wynik = i + Integer.parseInt(textView.getText().toString());
                textView.setText(""+wynik);//wyswietlenie wyniku
            }
        });

    }
}