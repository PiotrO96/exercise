﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.IO;
using System.Windows.Forms;
using NAudio.Wave;
using NAudio.CoreAudioApi;
using TagLib;

namespace Mp3Player
{
    public partial class Form1 : Form
    {
        IWavePlayer waveOutDevice = new WaveOut();
        AudioFileReader audioFileReader;
        string file;
        bool loop, playlist;

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        public Form1()
        {
            InitializeComponent();

            try
            {
                waveOutDevice = new WaveOut();
            }
            catch (Exception driverCreateException)
            {
                MessageBox.Show(String.Format("{0}", driverCreateException.Message));
                return;
            }
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            openFileDialog1.Filter = "MP3 files|*.mp3";

            DialogResult result = openFileDialog1.ShowDialog();

            if (result == DialogResult.OK)
            {
                file = openFileDialog1.FileName;
                try
                {
                    audioFileReader = new AudioFileReader(file);
                    var tagFile = TagLib.File.Create(file);
                    MemoryStream ms = new MemoryStream(tagFile.Tag.Pictures[0].Data.Data);
                    Image image = Image.FromStream(ms);
                    pictureBox1.Image = image;
                    toolStripStatusLabel1.Text = tagFile.Tag.FirstPerformer + " - " + tagFile.Tag.Title;
                    toolStripStatusLabel2.Text = "Album: " + tagFile.Tag.Album;
                    toolStripStatusLabel3.Text = "Genre: " + tagFile.Tag.FirstGenre;
                    label2.Text = audioFileReader.TotalTime.ToString();
                    label3.Text = audioFileReader.TotalTime.ToString();
                    waveOutDevice.Init(audioFileReader);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Error");
                }
            }
        }

        private void playButton_Click(object sender, EventArgs e)
        {
            try
            {
                loop = false;

                if (playlist == true)
                    playlist = true;
                else
                    playlist = false;

                waveOutDevice.Pause();
                waveOutDevice.Play();
                timer1.Interval = (1000);
                timer1.Enabled = true;
                timer1.Start();
                trackBar1.Maximum = (int)audioFileReader.Length;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error");
            }
        }

        private void pauseButton_Click(object sender, EventArgs e)
        {
            waveOutDevice.Pause();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            label1.Text = audioFileReader.CurrentTime.ToString();
            trackBar1.Value = (int)audioFileReader.Position;
        }

        private void playLoopButton_Click(object sender, EventArgs e)
        {
            try
            {
                loop = true;
                playlist = false;
                waveOutDevice.Pause();
                waveOutDevice.Play();
                timer1.Interval = (1000);
                timer1.Enabled = true;
                timer1.Start();
                trackBar1.Maximum = (int)audioFileReader.Length;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error");
            }
        }

        private void playToolStripMenuItem_Click(object sender, EventArgs e)
        {
            playButton_Click(sender, e);
        }

        private void playLoopToolStripMenuItem_Click(object sender, EventArgs e)
        {
            playLoopButton_Click(sender, e);
        }

        private void pauseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            pauseButton_Click(sender, e);
        }

        private void previousToolStripMenuItem_Click(object sender, EventArgs e)
        {
            previousButton_Click(sender, e);
        }

        private void nextToolStripMenuItem_Click(object sender, EventArgs e)
        {
            nextButton_Click(sender, e);
        }

        private void playlistAddButton_Click(object sender, EventArgs e)
        {
            openFileDialog1.Filter = "MP3 files|*.mp3";

            DialogResult result = openFileDialog1.ShowDialog();

            if (result == DialogResult.OK)
            {
                file = openFileDialog1.FileName;
                try
                {
                    playlistListBox.Items.Add(file);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Error");
                }
            }
        }

        private void playRandomButton_Click(object sender, EventArgs e)
        {
            try
            {
                loop = false;
                int count = playlistListBox.Items.Count;

                Random rnd = new Random();
                int index = rnd.Next(0, count);
                playlistListBox.SelectedIndex = index;
                DataPlay();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error");
            }
        }

        private void previousButton_Click(object sender, EventArgs e)
        {
            try
            {
                int count = playlistListBox.Items.Count - 1;

                if (playlistListBox.SelectedIndex > 0)
                    playlistListBox.SelectedIndex -= 1;
                else
                    playlistListBox.SelectedIndex = count;

                System.Threading.Thread.Sleep(1000);
                DataPlay();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error nothing on playlist");
            }
        }

        private void nextButton_Click(object sender, EventArgs e)
        {
            try
            {
                int count = playlistListBox.Items.Count - 1;

                if (count > playlistListBox.SelectedIndex)
                    playlistListBox.SelectedIndex += 1;
                else
                    playlistListBox.SelectedIndex = 0;

                System.Threading.Thread.Sleep(1000);
                DataPlay();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error nothing on playlist");
            }
        }

        private void upButton_Click(object sender, EventArgs e)
        {
            try
            {
                int count = playlistListBox.Items.Count;
                int index = playlistListBox.SelectedIndex;
                string swapItem = playlistListBox.Items[index - 1].ToString();


                if (playlistListBox.SelectedIndex < count)
                {
                    playlistListBox.Items.RemoveAt(index - 1);
                    playlistListBox.Items.Insert(index, swapItem);
                }

                playlistListBox.Refresh();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Song is already first on playlist.");
            }
        }

        private void downButton_Click(object sender, EventArgs e)
        {
            try
            {
                int count = playlistListBox.Items.Count - 1;
                int index = playlistListBox.SelectedIndex;
                string swapItem = playlistListBox.Items[index + 1].ToString();


                if (playlistListBox.SelectedIndex < count)
                {
                    playlistListBox.Items.RemoveAt(index+1);
                    playlistListBox.Items.Insert(index, swapItem);
                }

                playlistListBox.Refresh();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Song is already last on playlist.");
            }
        }

        private void deleteButton_Click(object sender, EventArgs e)
        {
            try
            {
                int index = playlistListBox.SelectedIndex;
                playlistListBox.Items.RemoveAt(index);
                playlistListBox.Refresh();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Song is already last on playlist.");
            }
        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            try
            {
                audioFileReader.Position = trackBar1.Value;
                waveOutDevice.Play();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Nieprawidłowa wartość!");
            }
        }

        private void trackBar1_ValueChanged(object sender, EventArgs e)
        {
            try
            {
                label2.Text = (audioFileReader.TotalTime - audioFileReader.CurrentTime).ToString();

                if (trackBar1.Value == trackBar1.Maximum && loop == true)
                {
                    System.Threading.Thread.Sleep(1000);
                    audioFileReader.Dispose();
                    audioFileReader = new AudioFileReader(file);
                    waveOutDevice.Init(audioFileReader);
                    waveOutDevice.Play();
                }
                else if (trackBar1.Value == trackBar1.Maximum && playlist == true)
                {
                    nextButton_Click(sender, e);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error");
            }
        }

        private void playlistListBox_DoubleClick(object sender, EventArgs e)
        {
            try
            {
                playlist = true;
                loop = false;
                System.Threading.Thread.Sleep(1000);
                DataPlay();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Nieprawidłowa wartość.");
            }
        }

        public void DataPlay()
        {
            try
            {
                if (audioFileReader != null)
                {
                    audioFileReader.Dispose();
                    timer1.Dispose();
                }

                file = playlistListBox.SelectedItem.ToString();
                audioFileReader = new AudioFileReader(file);
                waveOutDevice.Init(audioFileReader);
                var tagFile = TagLib.File.Create(file);
                MemoryStream ms = new MemoryStream(tagFile.Tag.Pictures[0].Data.Data);
                Image image = Image.FromStream(ms);
                pictureBox1.Image = image;
                toolStripStatusLabel1.Text = tagFile.Tag.FirstPerformer + " - " + tagFile.Tag.Title;
                toolStripStatusLabel2.Text = "Album: " + tagFile.Tag.Album;
                toolStripStatusLabel3.Text = "Genre: " + tagFile.Tag.FirstGenre;
                label2.Text = audioFileReader.TotalTime.ToString();
                label3.Text = audioFileReader.TotalTime.ToString();
                timer1.Interval = (1000);
                timer1.Enabled = true;
                timer1.Start();
                trackBar1.Maximum = (int)audioFileReader.Length;
                waveOutDevice.Play();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error");
            }
        }
    }
}