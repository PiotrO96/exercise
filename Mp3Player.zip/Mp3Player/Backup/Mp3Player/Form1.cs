﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using NAudio.Wave;
using NAudio.CoreAudioApi;


namespace Mp3Player
{
    public partial class Form1 : Form
    {
        //Declarations required for audio out and the MP3 stream
        IWavePlayer waveOutDevice;
        WaveStream mainOutputStream;
        WaveChannel32 volumeStream;

        string fileName = null;
        public Form1()
        {
            InitializeComponent();

            timer2.Interval = (1000) * (5);
            timer2.Enabled = true;
            timer2.Start();  

            timer1.Interval = (1000) * (1);              // Timer will tick evert second
                                // Enable the timer
                                        // Start the timer

            //label1.Location = new Point(100, 100);
            label1.AutoSize = true;
            label1.Text = String.Empty;


            try
            {
                waveOutDevice = new WaveOut();
            }
            catch (Exception driverCreateException)
            {
                MessageBox.Show(String.Format("{0}", driverCreateException.Message));
                return;
            }
        }
        private WaveStream CreateInputStream(string fileName)
        {
            WaveChannel32 inputStream;
            if (fileName.EndsWith(".mp3"))
            {
                WaveStream mp3Reader = new Mp3FileReader(fileName);
                inputStream = new WaveChannel32(mp3Reader);
            }
            else
            {
                throw new InvalidOperationException("Unsupported extension");
            }
            volumeStream = inputStream;
            return volumeStream;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            mainOutputStream = CreateInputStream("c:\\jb.mp3");
            waveOutDevice.Init(mainOutputStream);
            waveOutDevice.Play();

            timer1.Enabled = true;   
            timer1.Start();  
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            label1.Text = DateTime.Now.ToString();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            label2.Text = DateTime.Now.ToString();
        }
    }
}
