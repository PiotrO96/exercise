package com.example.ps7_oltarzewski_piotr;

public class ForecastConstants {

    public static final String cnt = "cnt";

    public static final String lista = "list";

    public static final String dt = "dt";
    public static final String glowne = "main";
    public static final String pogoda = "weather";

    public static final String temperatura = "temp";

    public static final String ikona_id = "icon";
    public static final String tekst_dt = "dt_txt";
}
