﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab1_Sucriber
{
    public interface ISubscriber:IDisposable
    {
        
        //  incyddent
        event Action<string, string> Nofity;

        /// zarejestrowanie topicu subskrybcji
        void RegisterSubscriber(List<string> topics);

       //  Zarejestrowanie subskrybcji
        void RegisterSbuscriberAll();

        ///  Usunięcie wszystkich wiadomości subskrybcji i zamknięcie 
        void RemoveSbuscriberAll();
    }
}
