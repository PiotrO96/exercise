﻿
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using NetMQ;
using NetMQ.Sockets;

namespace Lab1_Sucriber
{
   public class Subscriber:ISubscriber
    {

        private SubscriberSocket _subscriberSocket = null;
        private string _endpoint = @"tcp://127.0.0.1:9876";

        public Subscriber(string endPoint)
        {
            _subscriberSocket = new SubscriberSocket();
            _endpoint = endPoint;
        }


   
        // Wykonaj zadanie, które jest określone w definicji aplikacji związanej z zasobem niezarządzanym.
  
        public void Dispose()
        {
            throw new NotImplementedException();
        }

        //zakonczenie iplementacji IDisposable

       
        //implementacja ISubscriber
        public event Action<string, string> Nofity = delegate { };

      
        // Zarejestrowanie topików subskrypcji
              public void RegisterSubscriber(List<string> topics)
        {
            InnerRegisterSubscriber(topics);
        }

     
        //  Rejestrowanie subskrypcji
        public void RegisterSbuscriberAll()
        {
            InnerRegisterSubscriber();
        }

       
        // usunięcie wszystkich wiadomości subskrypcji i zamknięcie
        public void RemoveSbuscriberAll()
        {
            InnerStop();
        }

        //zakończenie implementacji ISubcriber

        //  implementacja wewnętrzna


        //  zarejestrowanie wiadomości subskrypcji
        //wykorzystanie parametru topics
        private void InnerRegisterSubscriber(List<string> topics = null)
        {
            InnerStop();
            _subscriberSocket = new SubscriberSocket();
            _subscriberSocket.Options.ReceiveHighWatermark = 1000;
            _subscriberSocket.Connect(_endpoint);
            if (null == topics)
            {
                _subscriberSocket.SubscribeToAnyTopic();
            }
            else
            {
                topics.ForEach(item => _subscriberSocket.Subscribe(item));
            }
            Task.Factory.StartNew(() =>
            {
                while (true)
                {
                    string messageTopicReceived = _subscriberSocket.ReceiveFrameString();
                    string messageReceived = _subscriberSocket.ReceiveFrameString();
                    Nofity(messageTopicReceived, messageReceived);
                }
            });
        }

        
        //  Zamknięcie subskrybcji
        private void InnerStop()
        {
            _subscriberSocket.Close();
        }

        // zakończenie implementacji wewnętrznej
    }
}
