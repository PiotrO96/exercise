﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;

namespace Lab1_Sucriber
{
    public partial class SubscriberForm : Form
    {
        private ISubscriber subscriber;
        
        public SubscriberForm()
        {
            InitializeComponent();
        }

        private void SubscriberForm_Load(object sender, EventArgs e)
        {
            subscriber = new Subscriber("tcp://127.0.0.1:8888");
            subscriber.RegisterSbuscriberAll();
              
              subscriber.Nofity += delegate (string stg, string stg1)
              {
                  ListViewItem item = new ListViewItem(string.Format("topic:{0},Data:{1}", stg, stg1));
                  listView1.Items.Add(item);

              };
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedItem.Equals("Data"))
            {
                subscriber = new Subscriber("tcp://127.0.0.1:8888");
                subscriber.RegisterSbuscriberAll();
                subscriber.Nofity += delegate (string s, string s1)
                {
                    ListViewItem item2 = new ListViewItem(string.Format("topic:{0},Data:{1}", s, s1));
                    listBox1.SelectedItem = listView1.Items.Add(item2);
                    listView1.Items.Add(item2);
                    
                };
               
            }
            if (listBox1.SelectedItem.Equals("Czas"))
            {
                subscriber = new Subscriber("tcp://127.0.0.1:8888");
                subscriber.RegisterSbuscriberAll();
                subscriber.Nofity += delegate (string sS, string s2)
                {
                    ListViewItem item3 = new ListViewItem(string.Format("topic:{0},Data:{1}", sS, s2));
                    listBox1.SelectedItem = listView1.Items.Add(item3);
                    listView1.Items.Add(item3);
                    
                   
                };
            }
            if (listBox1.SelectedItem.Equals("Inne"))
            {
                subscriber = new Subscriber("tcp://127.0.0.1:8888");
                subscriber.RegisterSbuscriberAll();
                subscriber.Nofity += delegate (string sSs, string s3)
                {
                    ListViewItem item4 = new ListViewItem(string.Format("topic:{0},Data:{1}", sSs, s3));
                    listBox1.SelectedItem = listView1.Items.Add(item4);
                    listView1.Items.Add(item4);
                   
                };
            }
        }
    }
}
