﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab1Pub_Subv2
{
    public partial class PublisherForm : Form
    {
        private IPublisher publisher;
        Stopwatch watch = new Stopwatch();
        public PublisherForm()
        {
            InitializeComponent();
            publisher = new Publisher("tcp://127.0.0.1:8888");
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }
        
        private void button1_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedItem.Equals("Data"))
            {
                byte[] send = Encoding.ASCII.GetBytes(DateTime.Now.ToString("dd/MM/yyyy"));
                string strContent = Encoding.Default.GetString(send);
                ListViewItem item = new ListViewItem(string.Format("Topic:First,  msg:  {0}", strContent));
                listBox1.SelectedItem = listView1.Items.Add(item);
                publisher.Publish("First", strContent);
            }
            if (listBox1.SelectedItem.Equals("Czas"))
            { 
                byte[] send2 = Encoding.ASCII.GetBytes(DateTime.Now.ToString("h:mm:ss tt"));
            string strContent2 = Encoding.Default.GetString(send2);
            ListViewItem item2 = new ListViewItem(string.Format("Topic:Second,  msg:  {0}", strContent2));
            listBox1.SelectedItem = listView1.Items.Add(item2);
            publisher.Publish("Second", strContent2);
        }
            if (listBox1.SelectedItem.Equals("Inne"))
            {
                    timer1.Start(); 
          }
            
            /*
           byte [] send = Encoding.ASCII.GetBytes(DateTime.Now.ToString("dd/MM/yyyy")); 
            string strContent = Encoding.Default.GetString(send);
            byte[] send2 = Encoding.ASCII.GetBytes(DateTime.Now.ToString("h:mm:ss tt"));
            string strContent2 = Encoding.Default.GetString(send2);
            string strContent3 = "Third topic";
            ListViewItem item = new ListViewItem(string.Format("Topic:First,  Data:  {0}", strContent));
            ListViewItem item2 = new ListViewItem(string.Format("Topic:Second,  Data:  {0}", strContent2));
            ListViewItem item3 = new ListViewItem(string.Format("Topic:Third,  Data:  {0}", strContent3));
            listBox1.SelectedItem = listView1.Items.Add(item);
            listBox1.SelectedItem = listView1.Items.Add(item2);
            listBox1.SelectedItem = listView1.Items.Add(item3);
            publisher.Publish("First", strContent);
            publisher.Publish("Second", strContent2);
            publisher.Publish("Third", strContent3);
            */
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            timer1.Stop();
            timer2.Stop();
            timer3.Stop();
            timer4.Stop();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {

            string strContent3 = "Third topic";
                ListViewItem item3 = new ListViewItem(string.Format("Topic:Third,  msg:  {0}", strContent3));
                listBox1.SelectedItem = listView1.Items.Add(item3);
                publisher.Publish("Third", strContent3);
           
        }
        private void timer2_Tick(object sender, EventArgs e)
        {
            byte[] send5 = Encoding.ASCII.GetBytes(DateTime.Now.ToString("dd/MM/yyyy"));
            string strContent5 = Encoding.Default.GetString(send5);
            ListViewItem item5 = new ListViewItem(string.Format("Topic:First,  msg:  {0}", strContent5));
            listView1.Items.Add(item5);
            publisher.Publish("First", strContent5);
        }

        private void timer3_Tick(object sender, EventArgs e)
        {
            byte[] send6 = Encoding.ASCII.GetBytes(DateTime.Now.ToString("h:mm:ss tt"));
            string strContent6 = Encoding.Default.GetString(send6);
            ListViewItem item6 = new ListViewItem(string.Format("Topic:Second,  msg:  {0}", strContent6));
            listView1.Items.Add(item6);
            publisher.Publish("Second", strContent6);

        }
        private void timer4_Tick(object sender, EventArgs e)
        {
            string strContent7 = "Third topic";
            ListViewItem item7 = new ListViewItem(string.Format("Topic:Third,  msg:  {0}", strContent7));
            listView1.Items.Add(item7);
            publisher.Publish("Third", strContent7);
        }
        private void button3_Click(object sender, EventArgs e)
        {
           //   watch.Start();
            //  while (watch.Elapsed < TimeSpan.FromSeconds(10))
           //  {
            timer2.Start();
            timer3.Start();
            timer4.Start();

            /*
                byte[] send5 = Encoding.ASCII.GetBytes(DateTime.Now.ToString("dd/MM/yyyy"));
                string strContent5 = Encoding.Default.GetString(send5);
                ListViewItem item5 = new ListViewItem(string.Format("Topic:First,  msg:  {0}", strContent5));
                listView1.Items.Add(item5);
                publisher.Publish("First", strContent5);

                byte[] send6 = Encoding.ASCII.GetBytes(DateTime.Now.ToString("h:mm:ss tt"));
                string strContent6 = Encoding.Default.GetString(send6);
                ListViewItem item6 = new ListViewItem(string.Format("Topic:Second,  msg:  {0}", strContent6));
              listView1.Items.Add(item6);
                publisher.Publish("Second", strContent6);

                string strContent7 = "Third topic";
                ListViewItem item7 = new ListViewItem(string.Format("Topic:Third,  msg:  {0}", strContent7));
                 listView1.Items.Add(item7);
                publisher.Publish("Third", strContent7);
            */
          //  }
            //watch.Stop();
        }

       
    }
}
