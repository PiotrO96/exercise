﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab1Pub_Subv2
{
    interface IPublisher:IDisposable
    {
       
        // wypuszczenie wiadomości
       
        // stworzenie parametru topicName oraz data
        void Publish(string topicName, string data);
    }
}
