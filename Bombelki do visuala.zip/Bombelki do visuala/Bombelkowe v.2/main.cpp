#include <cstdlib>
#include <iostream>
#include <time.h>
#include <iomanip>
#include <Windows.h>

using namespace std;

const int N=5000;

int main()
{
	int d[N], i;
	DWORD t1, t2;

	cout<<"Sortowanie babelkowe"<<endl<<endl;

	srand((unsigned)time(NULL));

	for(i=0;i<N;i++) d[i]=rand() % 100;
	cout<<"Przed sortowaniem:"<<endl;

	for(i=0;i<N;i++) cout<<setw(4)<<d[i];
	cout<<endl;

	//Algorytm sortowania
	t1 = GetTickCount(); //Czas

	for(i=0;i<N-1;i++)
		for(int j=0;j<N-i;j++)
			if(d[j]>=d[j+1]) swap(d[j],d[j+1]);



	t2 = GetTickCount() - t1; //Czas
	//Koniec

	cout<<"Po sortowaniem:"<<endl;
	for(i=0;i<N;i++) cout<<setw(4)<<d[i];

	cout<<endl<<"Czas wykonania: "<<t2<<" ms"<<endl;

	system("pause");

	return 0;
}
