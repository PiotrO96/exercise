﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    public float walkSpeed = 0.2f;
    public float jumpForce = 0.1f;
    public int score = 0;
    public int highScore = 0;
    public int gems = 0;
    public int lvlGems = 0;
    public int lives = 1;
    public int lvlLives = 1;
    public int jumpLevel = 1;
    public int runLevel = 1;
    public float checkpointCoordinatesx = 0, checkpointCoordinatesy = 0;
    public static GameManager instance;
    HUDManager hudManager;
    PlayerController play;
    public int currentLevel = 1;
    public int highestLevel = 5;
    public int a = 1;
    public int cL = 1;

    public void Unlock()
    {
        if (a<=cL)
            a = cL;

        for (int i=a;i>1;i--)
        {
            GameObject locked =  GameObject.Find("Lock"+i);
            Destroy(locked);
        }
    }

    void Awake()
    {
        if (instance == null)
        {
            instance = this;
        }
        else if (instance != this)
        {
            Destroy(gameObject);
        }

        DontDestroyOnLoad(gameObject);
        instance.hudManager = FindObjectOfType<HUDManager>();
        instance.play = FindObjectOfType<PlayerController>();
    }

    public void IncreaseScore(int amount)
    {
        score += amount;
        if (hudManager != null)
            hudManager.ResetHud();

        if (score > highScore)
        {
            highScore = score;
        }
    }

    //Zrobione
    public void IncreaseGems(int amount)
    {
        gems += amount;
        lvlGems += amount;
        if (hudManager != null)
            hudManager.ResetHud();
    }

    //Zrobione
    public void ResetGame()
    {
        lvlGems = 0;
        lvlLives = lives;
        checkpointCoordinatesx = 0;
        checkpointCoordinatesy = 0;

        //if (hudManager != null)
            //hudManager.ResetHud();

        SceneManager.LoadScene("LevelSelector");
    }

    //Zrobione
    public void IncreaseLevel()
    {
        if (currentLevel < highestLevel && currentLevel != 4)
        {
            lvlGems = 0;
            lvlLives = lives;
            checkpointCoordinatesx = 0;
            checkpointCoordinatesy = 0;
            currentLevel++;
            SceneManager.LoadScene("Level" + currentLevel);
        }
        else if (currentLevel < highestLevel && currentLevel == 4)
        {
            lvlGems = 0;
            lvlLives = 1;
            checkpointCoordinatesx = 0;
            checkpointCoordinatesy = 0;
            currentLevel++;
            SceneManager.LoadScene("Level" + currentLevel);
        }
        else
        {
            ComplitedGame();
        }
    }

    //Zrobione
    public void LevelCompleted()
    {
        SceneManager.LoadScene("LevelCompleted" + currentLevel);
    }

    //Zrobione
    public void GameOver()
    {
        lvlLives--;
        if (hudManager != null)
            hudManager.ResetHud();

        if (lvlLives > 0)
        {
            play.SetPosition(checkpointCoordinatesx, checkpointCoordinatesy);
        }          
        else
            SceneManager.LoadScene("GameOver");
    }

    //Zrobione
    public void Checkpoint(float cordx, float cordy)
    {
        checkpointCoordinatesx = cordx;
        checkpointCoordinatesy = cordy;
    }

    public void ComplitedGame()
    {
        SceneManager.LoadScene("CompletedGame");
    }

    public void StartLevel()
    {
        SceneManager.LoadScene(gameObject.name.ToString());
    }

    public void LivesLevelUp()
    {
        lives++;
    }

    public void RunLevelUp()
    {
        walkSpeed *= 1.5f;
        runLevel++;
    }
    public void JumpLevelUp()
    {
        jumpForce *= 1.3f;
        jumpLevel++;
    }
}
