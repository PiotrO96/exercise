﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class HUDManager : MonoBehaviour {

    public Text gemLabel;
    public Text livesLabel;

	// Use this for initialization
	void Start () {
        ResetHud();
    }
	
	public void ResetHud()
    {
        gemLabel.text = "x" + GameManager.instance.gems;
        livesLabel.text = "x" + GameManager.instance.lvlLives;
    }
}
