﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class XAxisEnemyController : MonoBehaviour {

    public float speed = 1f;
    public float rangeX = 0.3f;
    Vector3 initialPos;
    int direction = 1;

    // Use this for initialization
    void Start()
    {
        initialPos = transform.position;
    }

    // Update is called once per frame
    void Update()
    {
        float movementX = speed * Time.deltaTime * direction;
        float newX = transform.position.x + movementX;

        if (direction > 0)
        {
            Vector3 theScale = transform.localScale;
            theScale.x = -1;
            transform.localScale = theScale;
        }
        else if (direction < 0)
        {
            Vector3 theScale = transform.localScale;
            theScale.x = 1;
            transform.localScale = theScale;
        }

        if (Mathf.Abs(newX - initialPos.x) > rangeX)
        {
            direction *= -1;
        }
        else
        {
            transform.position += new Vector3(movementX, 0, 0);
        }
    }
}
