﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour {

    public float walkSpeed = GameManager.instance.walkSpeed;
    public float cameraDistanceX = 0;
    Rigidbody2D rb;
    Collider2D col;
    public float jumpForce = GameManager.instance.jumpForce;
    bool pressedJump = false;
    Vector2 size;
    public Animator animator;
    bool isGrounded;
    public AudioSource gemSound, jumpSound;


    // Use this for initialization
    void Start () {
        rb = GetComponent<Rigidbody2D>();
        col = GetComponent<Collider2D>();
        size = col.bounds.size;
        CameraFollowPlayer();
    }
	
	// Update is called once per frame
	void Update () {
        WalkHandler();
        CameraFollowPlayer();
        JumpHandler();
        Falling();
    }

    void WalkHandler()
    {
        float hAxis = Input.GetAxis("Horizontal");

        if (hAxis > 0)
        {
            Vector3 theScale = transform.localScale;

            theScale.x = 1;

            transform.localScale = theScale;
        }
        else if (hAxis < 0)
        {
            Vector3 theScale = transform.localScale;

            theScale.x = -1;

            transform.localScale = theScale;
        }

        rb.velocity = new Vector2(walkSpeed * hAxis, rb.velocity.y);
        animator.SetFloat("Speed", Mathf.Abs(hAxis));
    }

    void CameraFollowPlayer()
    {
        Vector3 cameraPosition = Camera.main.transform.position;
        cameraPosition.x = transform.position.x - cameraDistanceX;
        Camera.main.transform.position = cameraPosition;
    }

    void JumpHandler()
    {
        if (Input.GetKeyDown(KeyCode.Space) && isGrounded)
        {
            animator.SetBool("IsGround", false);
            isGrounded = false;
            jumpSound.Play();
            rb.AddForce(new Vector2(rb.velocity.x, jumpForce));
        }
    }

    void OnCollisionEnter2D(Collision2D other)
    {
        if (other.gameObject.CompareTag("Ground"))
        {
            isGrounded = true;
            animator.SetBool("IsGround", true);
        }
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Gem"))
        {
            GameManager.instance.IncreaseGems(1);
            gemSound.Play();
            Destroy(other.gameObject);
        }
        else if (other.CompareTag("Enemy"))
        {
            GameManager.instance.GameOver();
            StartCoroutine(WaitAfterDeath());
        }
        else if (other.CompareTag("Checkpoint"))
        {
            float cordx = this.transform.position.x;
            float cordy = this.transform.position.y;
            GameManager.instance.Checkpoint(cordx, cordy);
        }
        else if (other.CompareTag("Goal"))
        {
            GameManager.instance.LevelCompleted();
        }
    }

    IEnumerator WaitAfterDeath()
    {
        rb.constraints = RigidbodyConstraints2D.FreezePositionX | RigidbodyConstraints2D.FreezeRotation;
        yield return new WaitForSeconds(0.5f);
        rb.constraints = RigidbodyConstraints2D.FreezeRotation;
        yield return 0;
    }

    public void SetPosition(float cordx, float cordy)
    {
        Vector3 pos = transform.position;
        pos.x = cordx;
        pos.y = cordy;
        transform.position = pos;
    }

    public void Falling()
    {
        if(rb.position.y < -1.5)
            GameManager.instance.GameOver();
    }
}
