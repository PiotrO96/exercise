﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class LevelCompleteManager : MonoBehaviour {

    public Text livesValue;
    public Text gemsValue;

    // Use this for initialization
    void Start()
    {
        gemsValue.text = "x" + GameManager.instance.lvlGems.ToString();
        livesValue.text = "x" + GameManager.instance.lvlLives.ToString();
        GameManager.instance.cL++;
        GameManager.instance.Unlock();
    }

    public void RestartGame()
    {
        GameManager.instance.ResetGame();
        SceneManager.LoadScene("LevelSelector");
    }

    public void NextLevel()
    {
        GameManager.instance.IncreaseLevel();
    }

    public void LevelSelector()
    {
        SceneManager.LoadScene("LevelSelector");
    }
}
