﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class ProgressionManager : MonoBehaviour {

    public Text gemLabel, livesLabel;
    public Text livesLevelLabel, jumpLevelLabel, runLevelLabel;
    public int jumpLevel = GameManager.instance.jumpLevel;
    public int runLevel = GameManager.instance.runLevel;
    private GameObject button;
    private PlayerController player;

    void Start () {
        ResetHud();
    }

    public void ResetHud()
    {
        gemLabel.text = "x" + GameManager.instance.gems;
        livesLabel.text = "x" + GameManager.instance.lives;
        livesLevelLabel.text = GameManager.instance.lives + "/3";
        jumpLevelLabel.text = GameManager.instance.jumpLevel + "/3";
        runLevelLabel.text = GameManager.instance.runLevel + "/3";
        jumpLevel = GameManager.instance.jumpLevel;
        runLevel = GameManager.instance.runLevel;
        MaxLvlsCheck();
    }

    public void Error()
    {

    }

    public void LevelSelector()
    {
        SceneManager.LoadScene("LevelSelector");
    }

    public void JumpLevelUp()
    {
        if (jumpLevel < 2 && GameManager.instance.gems >= 10)
        {
            GameManager.instance.JumpLevelUp();
            GameManager.instance.gems -= 10;
            ResetHud();
        }
        else if (jumpLevel == 2 && GameManager.instance.gems >= 15)
        {
            button = GameObject.Find("LevelUpJump");
            Destroy(button);
            GameManager.instance.JumpLevelUp();
            GameManager.instance.gems -= 15;
            ResetHud();
        }
        else
        {
            print("Za malo gemow");
        }
    }

    public void RunLevelUp()
    {
        if (runLevel < 2 && GameManager.instance.gems >= 10)
        {
            GameManager.instance.RunLevelUp();
            GameManager.instance.gems -= 10;
            ResetHud();
        }
        else if (runLevel == 2 && GameManager.instance.gems >= 15)
        {
            button = GameObject.Find("LevelUpRun");
            Destroy(button);
            GameManager.instance.RunLevelUp();
            GameManager.instance.gems -= 15;
            ResetHud();
        }
    }

    public void LivesLevelUp()
    {
        if (GameManager.instance.lives < 2 && GameManager.instance.gems >= 10)
        {
            GameManager.instance.LivesLevelUp();
            GameManager.instance.gems -= 10;
            ResetHud();
        }
        else if (GameManager.instance.lives == 2 && GameManager.instance.gems >= 15)
        {
            button = GameObject.Find("LevelUpLives");
            Destroy(button);
            GameManager.instance.LivesLevelUp();
            GameManager.instance.gems -= 15;
            ResetHud();
        }
    }

    public void MaxLvlsCheck()
    {
        if (runLevel == 3)
        {
            GameObject button = GameObject.Find("LevelUpRun");
            Destroy(button);
        }

        if (jumpLevel == 3)
        {
            GameObject button = GameObject.Find("LevelUpJump");
            Destroy(button);
        }

        if (GameManager.instance.lives == 3)
        {
            GameObject button = GameObject.Find("LevelUpLives");
            Destroy(button);
        }
    }
}
