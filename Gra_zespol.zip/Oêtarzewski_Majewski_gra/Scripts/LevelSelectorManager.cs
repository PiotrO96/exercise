﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class LevelSelectorManager : MonoBehaviour {

    int l2, l3, l4, l5;

	// Use this for initialization
	void Start () {
        GameManager.instance.Unlock();
	}

    // Update is called once per frame
    public void CharacterProgress()
    {
        SceneManager.LoadScene("CharacterProgress");
    }

    public void Level1()
    {
        GameManager.instance.currentLevel = 0;
        GameManager.instance.cL = 1;
        GameManager.instance.IncreaseLevel();
    }

    public void Level2()
    {
        GameManager.instance.currentLevel = 1;
        GameManager.instance.cL = 2;
        GameManager.instance.IncreaseLevel();
    }
    public void Level3()
    {
        GameManager.instance.currentLevel = 2;
        GameManager.instance.cL = 3;
        GameManager.instance.IncreaseLevel();
    }
    public void Level4()
    {
        GameManager.instance.currentLevel = 3;
        GameManager.instance.cL = 4;
        GameManager.instance.IncreaseLevel();
    }
    public void Level5()
    {
        GameManager.instance.currentLevel = 4;
        GameManager.instance.IncreaseLevel();
    }

    public void Quit()
    {
        Application.Quit();
    }
}
