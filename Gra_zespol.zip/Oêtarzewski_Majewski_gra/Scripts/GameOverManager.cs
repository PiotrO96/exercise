﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GameOverManager : MonoBehaviour {

    public Text livesValue;
    public Text gemsValue;

    // Use this for initialization
    void Start ()
    {
        gemsValue.text = "x" + GameManager.instance.lvlGems.ToString();
        livesValue.text = "x" + GameManager.instance.lvlLives.ToString();
    }

    public void LevelSelector()
    {
        SceneManager.LoadScene("LevelSelector");
    }
}
