﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
namespace PrzegladarkaGrafiki
{
    public partial class Form1 : Form
    {
        Bitmap bmp;
        Image image;
        double zoom = 1;
       
        string[] files, paths;
        string file;
        public Form1()
        {
            InitializeComponent();
            this.pictureBox1.MouseWheel += new MouseEventHandler(pictureBox1_MouseWheel);
            INIT();
        }
        


        private Point firstPoint = new Point();
        public void INIT()
        {
            pictureBox1.MouseDown += (ss, ee) =>
             {
                 if (ee.Button == System.Windows.Forms.MouseButtons.Left) { firstPoint = Control.MousePosition; }
             };
            pictureBox1.MouseMove += (ss, ee) => {
                if (ee.Button == System.Windows.Forms.MouseButtons.Left)
                {
                    Point temp = Control.MousePosition;
                    Point res = new Point(firstPoint.X - temp.X, firstPoint.Y - temp.Y);

                    pictureBox1.Location = new Point(pictureBox1.Location.X - res.X, pictureBox1.Location.Y - res.Y);
                    firstPoint = temp;

                }
            };
        }

      


        private void pictureBox1_MouseWheel(object sender, MouseEventArgs e)
        {
            if (e.Delta != 0)
            {
                if (e.Delta > 0)
                {
                    przybliz_Click(sender, e);
                }
                if (e.Delta < 0)
                {
                    oddal_Click(sender, e);
                }
            }

        }

        private void oddal_Click(object sender, EventArgs e)
        {
            if (pictureBox1.Image != null)
            {
                try
                {
                    if (zoom > 0.4) zoom = zoom - 0.1;
                    Bitmap bmp = new Bitmap(image, Convert.ToInt32(pictureBox1.Width * zoom), Convert.ToInt32(pictureBox1.Height * zoom));
                    Graphics g = Graphics.FromImage(bmp);
                    g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
                    pictureBox1.Image = bmp;
                    //image = bmp;
                }
                catch (Exception ex)
                { }
            }
        }

        private void przybliz_Click(object sender, EventArgs e)
        {
            if (pictureBox1.Image != null)
            {
                try
                {
                    if (zoom < 10) zoom = zoom + 0.1;
                    Bitmap bmp = new Bitmap(image, Convert.ToInt32(pictureBox1.Width * zoom), Convert.ToInt32(pictureBox1.Height * zoom));
                    Graphics g = Graphics.FromImage(bmp);
                    g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
                    pictureBox1.Image = bmp;
                }
                catch (Exception ex)
                { }
            }
        }

        private void open_Click(object sender, EventArgs e)
        {
            // Show the dialog and get result.
            DialogResult result = openFileDialog1.ShowDialog();
            if (result == DialogResult.OK) // Test result.
            {
                string file = openFileDialog1.FileName;
                try
                {
                    image = Image.FromFile(file);
                   // image = ResizeImage(image, this.Size);
                    // Set the PictureBox image property to this image.
                    // ... Then, adjust its height and width properties.
                    pictureBox1.Image = image;

                }
                catch (Exception ex)
                {

                }

            }
        }
        private void Rysuj()
        {
            if (pictureBox1.Image != null)
            {
                try
                {
                    Bitmap bmp = new Bitmap(image, Convert.ToInt32(pictureBox1.Width * zoom), Convert.ToInt32(pictureBox1.Height * zoom));
                    Graphics g = Graphics.FromImage(bmp);
                    g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
                    pictureBox1.Image = bmp;
                }
                catch (Exception ex)
                {

                }
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            //zoom = zoom + 0.1;
            Rysuj();
        }
        private void pictureBox1_MouseEnter(object sender, EventArgs e)
        {
            pictureBox1.Focus();
        }

        private void Rotate_Click(object sender, EventArgs e)
        {
            
       
            if (image != null)
            {
                try
                {
                    image.RotateFlip(RotateFlipType.Rotate180FlipY);
                    pictureBox1.Image = image;
                }
                catch (Exception ex)
                {

                }
            }
        }

        private void RotateX_Click(object sender, EventArgs e)
        {
            if (image != null)
            {
                try
                {
                    image.RotateFlip(RotateFlipType.Rotate180FlipX);
                    pictureBox1.Image = image;
                }
                catch (Exception ex)
                {

                }
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string[] files = Directory.GetFiles(@"D:\Tapety\Inne\");
            DataTable table = new DataTable();
            table.Columns.Add("File Name");
            for (int i = 0; i < files.Length; i++)
            {
                FileInfo file = new FileInfo(files[i]);
                table.Rows.Add(file.Name);
            }
            dataGridView1.DataSource = table;
        }

        private void dataGridView1_DoubleClick(object sender, EventArgs e)
        {
            string imageName = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            image = Image.FromFile(@"D:\Tapety\Inne\" + imageName);
            pictureBox1.Image = image;
            pictureBox1.Show();
        }

       
    }
}
