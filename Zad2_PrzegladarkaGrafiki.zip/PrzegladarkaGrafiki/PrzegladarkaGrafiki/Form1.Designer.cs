﻿namespace PrzegladarkaGrafiki
{
    partial class Form1
    {
        /// <summary>
        /// Wymagana zmienna projektanta.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Wyczyść wszystkie używane zasoby.
        /// </summary>
        /// <param name="disposing">prawda, jeżeli zarządzane zasoby powinny zostać zlikwidowane; Fałsz w przeciwnym wypadku.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kod generowany przez Projektanta formularzy systemu Windows

        /// <summary>
        /// Metoda wymagana do obsługi projektanta — nie należy modyfikować
        /// jej zawartości w edytorze kodu.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.open = new System.Windows.Forms.Button();
            this.przybliz = new System.Windows.Forms.Button();
            this.oddal = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.Rotate = new System.Windows.Forms.Button();
            this.RotateX = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(12, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(966, 498);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // open
            // 
            this.open.AutoSize = true;
            this.open.Location = new System.Drawing.Point(12, 516);
            this.open.Name = "open";
            this.open.Size = new System.Drawing.Size(75, 23);
            this.open.TabIndex = 1;
            this.open.Text = "open";
            this.open.UseVisualStyleBackColor = true;
            this.open.Click += new System.EventHandler(this.open_Click);
            // 
            // przybliz
            // 
            this.przybliz.AutoSize = true;
            this.przybliz.Location = new System.Drawing.Point(93, 516);
            this.przybliz.Name = "przybliz";
            this.przybliz.Size = new System.Drawing.Size(75, 23);
            this.przybliz.TabIndex = 2;
            this.przybliz.Text = "+";
            this.przybliz.UseVisualStyleBackColor = true;
            this.przybliz.Click += new System.EventHandler(this.przybliz_Click);
            // 
            // oddal
            // 
            this.oddal.AutoSize = true;
            this.oddal.Location = new System.Drawing.Point(174, 516);
            this.oddal.Name = "oddal";
            this.oddal.Size = new System.Drawing.Size(75, 23);
            this.oddal.TabIndex = 3;
            this.oddal.Text = "-";
            this.oddal.UseVisualStyleBackColor = true;
            this.oddal.Click += new System.EventHandler(this.oddal_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // Rotate
            // 
            this.Rotate.AutoSize = true;
            this.Rotate.Location = new System.Drawing.Point(255, 516);
            this.Rotate.Name = "Rotate";
            this.Rotate.Size = new System.Drawing.Size(75, 23);
            this.Rotate.TabIndex = 4;
            this.Rotate.Text = "RotateY";
            this.Rotate.UseVisualStyleBackColor = true;
            this.Rotate.Click += new System.EventHandler(this.Rotate_Click);
            // 
            // RotateX
            // 
            this.RotateX.AutoSize = true;
            this.RotateX.Location = new System.Drawing.Point(336, 516);
            this.RotateX.Name = "RotateX";
            this.RotateX.Size = new System.Drawing.Size(75, 23);
            this.RotateX.TabIndex = 5;
            this.RotateX.Text = "RotateX";
            this.RotateX.UseVisualStyleBackColor = true;
            this.RotateX.Click += new System.EventHandler(this.RotateX_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(984, 12);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(166, 527);
            this.dataGridView1.TabIndex = 10;
            this.dataGridView1.DoubleClick += new System.EventHandler(this.dataGridView1_DoubleClick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1162, 551);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.RotateX);
            this.Controls.Add(this.Rotate);
            this.Controls.Add(this.oddal);
            this.Controls.Add(this.przybliz);
            this.Controls.Add(this.open);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button open;
        private System.Windows.Forms.Button przybliz;
        private System.Windows.Forms.Button oddal;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Button Rotate;
        private System.Windows.Forms.Button RotateX;
        private System.Windows.Forms.DataGridView dataGridView1;
    }
}

