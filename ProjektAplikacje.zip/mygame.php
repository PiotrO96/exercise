<?php

	session_start();
	
	if (!isset($_SESSION['zalogowany']))
	{
		header('Location: index.php');
		exit();
	}
	
?>
<!DOCTYPE html>
<html lang="en-us">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <title>Damnation</title>
    <link rel="shortcut icon" href="TemplateData/favicon.ico">
    <link rel="stylesheet" href="TemplateData/style.css">
    <script src="TemplateData/UnityProgress.js"></script>
	<link rel="stylesheet" href="css/style1.css" />
	<style>
	.body{
		background-color:grey;
	}
	</style>


    <script src="Build/UnityLoader.js"></script>
    <script>
      var gameInstance = UnityLoader.instantiate("gameContainer", "Build/mobilekappa.json", {onProgress: UnityProgress});
    </script>
  </head>
  <body >
 <?php
	echo '<p class="text2">Witaj '.$_SESSION['user'].'!    <a  class="myButton" href="index.php">Wroc do odtwarzacza!</a> <a class="myButton" href="logout.php">Wyloguj się!</a></p>';	

?>
    <div class="webgl-content">
      <div id="gameContainer" style="width: 1280px; height: 720"></div>
      <div class="footer">
        
        <div class="fullscreen" onclick="gameInstance.SetFullscreen(1)"></div>
        <div class="title">Damnation</div>
      </div>
    </div>
  </body>
</html>
