<?php

	session_start();
	
	if (!isset($_SESSION['udanarejestracja']))
	{
		header('Location: index.php');
		exit();
	}
	else
	{
		unset($_SESSION['udanarejestracja']);
	}
	if (isset($_SESSION['fr_nick'])) unset($_SESSION['fr_nick']);
	if (isset($_SESSION['fr_haslo1'])) unset($_SESSION['fr_haslo']);	
	if (isset($_SESSION['e_nick'])) unset($_SESSION['e_nick']);
	if (isset($_SESSION['e_haslo'])) unset($_SESSION['e_haslo']);
?>

<!DOCTYPE HTML>
<html lang="pl">
<head>
	<meta charset="utf-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
	<link rel="stylesheet" href="css/style1.css" />
	<title>AudioBook - Witamy!</title>
	<style>
	h1 {
  text-align: center;
}
	</style>
</head>

<body>
	<div id="main" align="center">
	<h1>
	<a >Dziękujemy za rejestrację w serwisie! Możesz już zalogować się na swoje konto! </a>
	</h1>
	<br></br>
	<a  class="myButton" href="index.php">Zaloguj się na swoje konto!</a>
	<br /><br />
</div>
</body>
</html>