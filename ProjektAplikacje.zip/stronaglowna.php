<?php

	session_start();
	
	if (!isset($_SESSION['zalogowany']))
	{
		header('Location: index.php');
		exit();
	}
	
?>



<!doctype html>

<html lang="pl">
<head>
  <meta charset="utf-8">
  <title>AudioBook-StronaGlowna</title>
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <script type="text/javascript" src="../../script/soundmanager2.js"></script>
  <script src="script/bar-ui.js"></script>
  <link rel="stylesheet" href="css/bar-ui.css" />
    <link rel="stylesheet" href="css/style1.css" />
  <style>
  body{
  background: linear-gradient(110deg, #2288cc 30%, #cc5d22 90%);
  }
  #dziecko1 {
  float:left;
}

#dziecko2 {
 float:right;
}
  
   </style>
  <script>
  
  function superfunckja(e)
  {
	  var id = alert(  el.value  )
	  
	
  }
  </script>

 <script>
"use strict";
var my_div = null;
var newDiv = null;
function byId(e){return document.getElementById(e);}

window.addEventListener('load', onDocLoaded, false);

function onDocLoaded()
{
    byId('mFileInput').addEventListener('change', onChosenFileChange, false);
}

function onChosenFileChange(evt)
{
    var fileType = this.files[0].type;

    if (fileType.indexOf('audio') != -1)
        loadFileObject(this.files[0], onSoundLoaded);
}

function loadFileObject(fileObj, loadedCallback)
{
    var reader = new FileReader();
    reader.onload = loadedCallback;
    reader.readAsDataURL( fileObj );
}

function onSoundLoaded(evt)
{
    //byId('sound').src = evt.target.result;
    //byId('sound').play();
	  //newDiv = document.createElement("div");
     // newDiv.innerHTML =  '<ul class="graphic"><li><a href="'+evt.target.result+'">Rain</a></li></ul>';

     // my_div = document.getElementById("org_div1");
     // document.body.insertBefore(newDiv, my_div);
	
	var p =soundManager.createSound({
 url: evt.target.result
});
p.setVolume(20);
p.play();
}

</script>
</head>



<body>

<div id="rodzic" >	


   

<div id="dziecko1" >
<div class="sm2-bar-ui playlist-open">

 <div class="bd sm2-main-controls">

  <div class="sm2-inline-texture"></div>
  <div class="sm2-inline-gradient"></div>

  <div class="sm2-inline-element sm2-button-element">
   <div class="sm2-button-bd">
    <a href="#play" class="sm2-inline-button sm2-icon-play-pause">Play / pause</a>
   </div>
  </div>

  <div class="sm2-inline-element sm2-inline-status">

   <div class="sm2-playlist">
    <div class="sm2-playlist-target">
     <!-- playlist <ul> + <li> markup will be injected here -->
     <!-- if you want default / non-JS content, you can put that here. -->
     <noscript><p>JavaScript is required.</p></noscript>
    </div>
   </div>

   <div class="sm2-progress">
    <div class="sm2-row">
    <div class="sm2-inline-time">0:00</div>
     <div class="sm2-progress-bd">
      <div class="sm2-progress-track">
       <div class="sm2-progress-bar"></div>
       <div class="sm2-progress-ball"><div class="icon-overlay"></div></div>
      </div>
     </div>
     <div class="sm2-inline-duration">0:00</div>
    </div>
   </div>

  </div>

  <div class="sm2-inline-element sm2-button-element sm2-volume">
   <div class="sm2-button-bd">
    <span class="sm2-inline-button sm2-volume-control volume-shade"></span>
    <a href="#volume" class="sm2-inline-button sm2-volume-control">volume</a>
   </div>
  </div>

  <div class="sm2-inline-element sm2-button-element">
   <div class="sm2-button-bd">
    <a href="#prev" title="Previous" class="sm2-inline-button sm2-icon-previous">&lt; previous</a>
   </div>
  </div>

  <div class="sm2-inline-element sm2-button-element">
   <div class="sm2-button-bd">
    <a href="#next" title="Next" class="sm2-inline-button sm2-icon-next">&gt; next</a>
   </div>
  </div>

  <div class="sm2-inline-element sm2-button-element sm2-menu">
   <div class="sm2-button-bd">
     <a href="#menu" class="sm2-inline-button sm2-icon-menu">menu</a>
   </div>
  </div>

 </div>

 <div class="bd sm2-playlist-drawer sm2-element">

  <div class="sm2-inline-texture">
   <div class="sm2-box-shadow"></div>
  </div>

  <!-- playlist content is mirrored here -->

  <div class="sm2-playlist-wrapper">

    <ul class="sm2-playlist-bd">
	 <?php
     require_once "connect.php";	 
    //$files = glob('AUDIOBOOKI/dotyk_zla/*.mp3');
	//foreach($files as $file)
	//{
		
		
		//echo '<li><a href="../'.$file.'">'.$file.'</a></li> ';
	//}
	 if (isset($_GET['hello'])) {
    
		$id = $_GET['hello'];
	$polaczenie = @new mysqli($host, $db_user, $db_password, $db_name);
	if ($rezultat = @$polaczenie->query(
		sprintf("SELECT sciezka_muzyki FROM ksiazki where id=$id",
		mysqli_real_escape_string($polaczenie))))
		{
			$wiersz = $rezultat->fetch_assoc();
		    $files = glob($wiersz["sciezka_muzyki"].'*.mp3');
				foreach($files as $file)
		{
		
		
		echo '<li><a href="../'.$file.'">'.$file.'</a></li> ';
		}
			
		
		}
		$polaczenie->close();
	 }
		

	 ?>


    </ul>

  </div>
<?php
require_once "connect.php";	
 if (isset($_GET['hello'])) {
	$polaczenie = @new mysqli($host, $db_user, $db_password, $db_name);

	if ($rezultat = @$polaczenie->query(
		sprintf("SELECT sciezka_okladki FROM ksiazki where id=$id",
		mysqli_real_escape_string($polaczenie))))
		{
			$wiersz = $rezultat->fetch_assoc();
		    
		echo '<div align="center" class="round-button">
            
                <img src="'.$wiersz['sciezka_okladki'].'" />
            
        </div>';
		}
		$polaczenie->close();
 }
?>
  <div class="sm2-extra-controls">

   <div class="bd">

    <div class="sm2-inline-element sm2-button-element">
     <a href="#prev" title="Previous" class="sm2-inline-button sm2-icon-previous">&lt; previous</a>
    </div>

    <div class="sm2-inline-element sm2-button-element">
     <a href="#next" title="Next" class="sm2-inline-button sm2-icon-next">&gt; next</a>
    </div>

    
    <div class="sm2-inline-element sm2-button-element disabled">
     <div class="sm2-button-bd">
      <a href="#repeat" title="Repeat playlist" class="sm2-inline-button sm2-icon-repeat">&infin; repeat</a>
     </div>
    </div>

    <div class="sm2-inline-element sm2-button-element disabled">
     <a href="#shuffle" title="Shuffle" class="sm2-inline-button sm2-icon-shuffle">shuffle</a>
    </div>
    

   </div>

  </div>

 </div>
<input class="myButton" type="file"  accept=".mp3" id="mFileInput"/>
</div>

</div>
<div id="dziecko2" >
<?php
	echo '<p class="text2">Witaj '.$_SESSION['user'].'!    <a  class="myButton" href="mygame.php">Zagraj w gre!</a> <a class="myButton" href="logout.php">Wyloguj się!</a></p>';	

?>
<?php
require_once "connect.php";	

	
	$polaczenie = @new mysqli($host, $db_user, $db_password, $db_name);

	if ($rezultat = @$polaczenie->query(
		sprintf("SELECT id,sciezka_okladki FROM ksiazki",
		mysqli_real_escape_string($polaczenie))))
		{
			
		
		    while($dane =mysqli_fetch_assoc($rezultat))
		echo '<div align="none" class="round-button">
            <a href="stronaglowna.php?hello='.$dane['id'].'" >
                <img src="'.$dane['sciezka_okladki'].'" height="400" width="250"/>
            </a>
        </div>';
		}
		$polaczenie->close();
 
?>
</div>
</div>
</body>
</html>