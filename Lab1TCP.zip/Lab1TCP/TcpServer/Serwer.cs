﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net.Sockets;
using System.Net;
using System.Timers;
using System.Threading;

namespace TcpServer
{
    public partial class Serwer : Form
    {
        public delegate void delUpdateUITextBox(string text);

        private BackgroundWorker backgroundWorker1;
        ThreadStart threadStart;
        Thread myUpdateThread;

        private const int portNum = 13;
        public static byte[] byteTime;
        TcpClient client = new TcpClient();
        NetworkStream ns = default(NetworkStream);
        TcpListener listener = new TcpListener(IPAddress.Any,portNum);
        string readdata = null;
        bool done = false;
        public Serwer()


        {
            InitializeComponent();
        }
       
        private void Form1_Load(object sender, EventArgs e)
        {
            textBox1.Text = $"Waiting to start server....{Environment.NewLine}";
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
         
        }
        private void serv()
        {
            this.Invoke((MethodInvoker)delegate
            {
               // bool done = false;

                listener.Start();
            
                while (!done)
                {
                    // textBox1.Text = "Waiting for connection...";
                    textBox1.Text = $"Waiting for connection...{Environment.NewLine}";
                    client = listener.AcceptTcpClient();
                    //   textBox1.Text = "Connection accepted";
                   textBox1.Text = $"Connection accepted{Environment.NewLine}";
                    ns = client.GetStream();
                   
                    byteTime = Encoding.ASCII.GetBytes(DateTime.Now.ToString());
                   
                    try
                    {
                        ns.Write(byteTime, 0, byteTime.Length);
                        ns.Close();
                        client.Close();
                    }
                    catch (Exception ex)
                    {
                        throw new Exception(ex.ToString());
                    }

                }
                listener.Stop();
            });


        }
        private void button1_Click(object sender, EventArgs e)
        {
            // listener.Start();
           
          
            //  textBox1.Text = "Waiting for connection...";
            var t2 = Task.Run(() => serv());

            //  serv();
          
          //  textBox1.Text = "Connection accepted";
            //  listener.Stop();
            //  Thread cThread = new Thread(getMessage);
            //    cThread.Start();

            /*  this.Invoke((MethodInvoker)delegate
              {
                  bool done = false;

                 // var listener = new TcpListener(IPAddress.Any, portNum);

                  listener.Start();
                  // textBox1.Text = "Waiting for connection...";
                  while (!done)
                  {

                      textBox1.Text = "Waiting for connection...";
                      //TcpClient client = listener.AcceptTcpClient();
                      client = listener.AcceptTcpClient();
                      textBox1.Text = "Connection accepted";
                      //NetworkStream ns = client.GetStream();
                      ns = client.GetStream();
                      // while (true)
                      // {
                      byteTime = Encoding.ASCII.GetBytes(DateTime.Now.ToString());
                     // byteTime = Encoding.ASCII.GetBytes(textBox1.Text);
                      try
                      {
                         // for (var i = 0; i < 10; i++)
                        //   {

                          ns.Write(byteTime, 0, byteTime.Length);

                          //  Thread.Sleep(1000);
                     // }
                              ns.Close();
                         // }
                          client.Close();
                      }
                      catch (Exception ex)
                      {
                          throw new Exception(ex.ToString());
                         // textBox1.Text = "Error" + ex.Message;
                      }

                      //}

                  }
                  listener.Stop();
              });
   */
        }
        //to na razie tylko test , jak cos wiencej wymysle to odkomentowac ten thread start
        private void getMessage()
        {
            string returndata;
            while (true)
            {
                ns = client.GetStream();
                var buffsize = client.ReceiveBufferSize;
                byte[] instream = new byte[buffsize];
                ns.Read(instream,0,buffsize);
                returndata = System.Text.Encoding.ASCII.GetString(instream);
                readdata = returndata;
                msg();
            }

        }
        private void msg()
        {
            if (this.InvokeRequired)
            {
                this.Invoke(new MethodInvoker(msg));
            }
            else
            {
                textBox1.Text = readdata;
            }

        }
        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = "wiadomosc";
        }
    }
}
