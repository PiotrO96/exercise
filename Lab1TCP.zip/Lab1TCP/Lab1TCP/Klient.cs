﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Windows.Forms;
using System.Net.Sockets;
namespace Lab1TCP
{
    public partial class Klient : Form
    {

        private const int portNum = 13;
        private const string hostName = "127.0.0.1";
         byte[] bytes = new byte[1024];
         int bytesRead;
        TcpClient client = new TcpClient();
        NetworkStream ns = default(NetworkStream);
        public Klient()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
            /*
            try
            {
                var client = new TcpClient(hostName, portNum);

                NetworkStream ns = client.GetStream();

                byte[] bytes = new byte[1024];
                int bytesRead = ns.Read(bytes, 0, bytes.Length);

                textBox1.Text = Encoding.ASCII.GetString(bytes, 0, bytesRead);
                textBox2.Text = hostName;

                // Console.WriteLine(Encoding.ASCII.GetString(bytes, 0, bytesRead));

                client.Close();

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            */
        }
        // TcpClient client = new TcpClient(hostName, portNum);
        private void button1_Click(object sender, EventArgs e)
        {
            this.Invoke((MethodInvoker)delegate
            {
                try
                {
                    client = new TcpClient(hostName, portNum);
                   // var client = new TcpClient(hostName, portNum);

                  //  NetworkStream ns = client.GetStream();
                    ns = client.GetStream();
                    //byte[] bytes = new byte[1024];
                    //int bytesRead = ns.Read(bytes, 0, bytes.Length);
                   // for (var i = 0; i < 10; i++)
                  //  {
                        bytesRead = ns.Read(bytes, 0, bytes.Length);
                        textBox1.Text = Encoding.ASCII.GetString(bytes, 0, bytesRead);
                  //  }
                    textBox2.Text = hostName;

                    // Console.WriteLine(Encoding.ASCII.GetString(bytes, 0, bytesRead));

                    client.Close();

                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.ToString());
                }
            });
            /*
            try
            { 
               // client = new TcpClient(hostName, portNum);
                var client = new TcpClient(hostName, portNum);

                 NetworkStream ns = client.GetStream();
               // ns = client.GetStream();
              byte[] bytes = new byte[1024];
               int bytesRead = ns.Read(bytes, 0, bytes.Length);

              textBox1.Text = Encoding.ASCII.GetString(bytes, 0, bytesRead);
                textBox2.Text = hostName;
               
               // Console.WriteLine(Encoding.ASCII.GetString(bytes, 0, bytesRead));

                client.Close();

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            
           */
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
        }


        private void button2_Click_1(object sender, EventArgs e)
        {
          //  bytesRead = ns.Read(bytes, 0, bytes.Length);
          //  textBox1.Text = Encoding.ASCII.GetString(bytes, 0, bytesRead);
        }
    }
}
