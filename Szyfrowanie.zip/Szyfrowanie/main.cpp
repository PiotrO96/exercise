/*#include <iostream>
#include <string>

using namespace std;

int main()
{
  string s;
  int i;

  getline(cin,s);

  for(i = 0; i < s.length(); i++)
  {
    s[i] = toupper(s[i]);
    if((s[i] >= 'A') && (s[i] <= 'Z')) s[i] = char(65 + (s[i] - 62) % 26);
  }

  cout << s << endl << endl;
  return 0;
} */
/*#include <iostream>

using namespace std;


int main(int argc, char** argv) {
	
	string wyraz= " ";
		cin>> wyraz;
	cout <<wyraz << endl;
	
	
	
	return 0;
}*/
/*#include <iostream>
#include <stdio.h>
#include <cstdlib>
#include <cstdio>
#include <cstring>
using namespace std;

void szyfrowanie(char tab[])
{
    int dlugosc = strlen(tab);
    
   	for(int i=0;i<dlugosc;i++)
        tab[i] = ((tab[i] - 95) % 27) + 97;
}

int main() {
    
    int dlugosc;
    
    cout << "Podaj dlugosc tekstu:\n";
    cin >> dlugosc;
    
    char tab[dlugosc];
    
    cout << "Podaj tekst (maksymalna dlugosc tekstu: " << dlugosc << "):\n";
    scanf("%s", &tab);
    
    szyfrowanie(tab);
    
    cout << "Po zaszyfrowaniu:\n";
    
    for(int i = 0;i<dlugosc;i++)
        cout << tab[i];
    
    return 0;
}*/
/*
#include<iostream>
#include<cstdlib>
#include<cstring>
using namespace std;
 
void szyfruj(string &wyraz)
{
    for(int i=0;i<wyraz.length();i++)
    {
        if(wyraz[i]>='a' && wyraz[i]<='w')
        {
            wyraz[i] +=3;
        }
        else if(wyraz[i]>='A' && wyraz[i]<= 'W')
        {
            wyraz[i] +=3;
        }
        else if(wyraz[i]>='x' && wyraz[i]<= 'z')
        {
            wyraz[i] -=23;
        }
        else if(wyraz[i]>='X' && wyraz[i]<= 'Z')
        {
            wyraz[i] -=23;
        }
    }
 
}
void odszyfruj(string &wyraz)
{
    for(int i=0;i<wyraz.length();i++)
    {
        if(wyraz[i]>='d' && wyraz[i]<='z')
        {
            wyraz[i] -=3;
        }
        else if(wyraz[i]>='D' && wyraz[i]<= 'Z')
        {
            wyraz[i] -=3;
        }
        else if(wyraz[i]>='a' && wyraz[i]<= 'c')
        {
            wyraz[i] +=23;
        }
        else if(wyraz[i]>='A' && wyraz[i]<= 'C')
        {
            wyraz[i] +=23;
        }
    }
 
}
 
int main()
{
  string wyraz;
  cout<< "Podaj wyraz: "<<endl;
  cin>>wyraz;
  szyfruj(wyraz);
    cout<<"Zaszyfrowane: "<<endl;
  cout<<wyraz<<endl;
  cout<<"Odszyfrowane: "<<endl;
  odszyfruj(wyraz);
  cout<<wyraz<<endl;
 
  system("pause");
  return 0;
}*/
#include <iostream>
#include <string>
 
using namespace std;
 
int main()
{
  string org, zaszyf, funkcja, tekst;
  int przesuniecie, i, max;
tekst = "Wybierz funkcje:\n1: Szyfrowanie:\n2: Deszyfrowanie:\n3: KONIEC:\n";
cout << tekst;  
do{      
          cin >>funkcja; 
          if(funkcja == "1"){
                  cout <<"Podaj tekst do szyfrowania:\n";
                  cin >>org;
                  cout <<"Podaj przesuniecie:\n";
                  cin >>przesuniecie;
                  max = org.size();
                  zaszyf.resize(max);
                  for (i=0; i<max; i++)
                    zaszyf[i]= (org[i]+przesuniecie)%256; 
                  cout <<"Tekst zaszyfrowany: "<<zaszyf<<"\n\n";  
                }
          else if(funkcja == "2"){
                  cout <<"Podaj tekst do odszyfrowania:\n";
                  cin >>org;
                  cout <<"Podaj przesuniecie:\n";
                  cin >>przesuniecie;
                  max = org.size();
                  zaszyf.resize(max);
                  for (i=0; i<max; i++)
                    zaszyf[i]= (org[i]-przesuniecie)%256; 
                  cout <<"Tekst odszyfrowany: "<<zaszyf<<"\n\n";  
                  }
           cout <<tekst;
        }while (funkcja != "3");
  return 0;    
}
