﻿using System;
using System.Drawing;
using System.Threading;

namespace Lab3
{
    public class Program
    {
        public static void Main(string[] args)
        {
            PixelManipulation pixMan = new(@"D:\Pictures\Art\sanspng.png");

            pixMan.CountBlackPixels();
            pixMan.FindBrightestPixel();

            Thread thread1 = new(new ThreadStart(pixMan.CountBlackPixels));
            Thread thread2 = new(new ThreadStart(pixMan.FindBrightestPixel));

            thread1.Start();
            thread1.Join();

            thread2.Start();
            thread2.Join();

            Console.WriteLine("Najjaśniejszy piksel: x = "
                + pixMan.brightestPixelAddress[0]
                + ", y = " + pixMan.brightestPixelAddress[1] + ", kolor: "
                + pixMan.brightestPixel);
            Console.WriteLine("Liczba czarnych pikseli: " + pixMan.blackPixelCount);
        }

        public class PixelManipulation
        {
            public Bitmap image1;
            public int blackPixelCount = 0;
            public float brightestPixel = 0.0f;
            public int[] brightestPixelAddress = new int[2];

            public PixelManipulation(string imagePath)
            {
                image1 = new Bitmap(imagePath, true);
            }

            public void CountBlackPixels()
            {
                for (int x = 0; x < image1.Width; x++)
                {
                    for (int y = 0; y < image1.Height; y++)
                    {
                        Color pixelColor = image1.GetPixel(x, y);
                        if (pixelColor == Color.FromArgb(0, 0, 0))
                        {
                            blackPixelCount++;
                        }
                    }
                }
            }

            public void FindBrightestPixel()
            {
                for (int x = 0; x < image1.Width; x++)
                {
                    for (int y = 0; y < image1.Height; y++)
                    {
                        Color pixelColor = image1.GetPixel(x, y);
                        if (brightestPixel < pixelColor.GetBrightness())
                        {
                            brightestPixel = pixelColor.GetBrightness();
                            brightestPixelAddress = new int[] { x, y };
                        }
                    }
                }
            }
        }
    }
}
