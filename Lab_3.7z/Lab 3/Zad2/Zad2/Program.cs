﻿using System;
using System.Collections.Generic;
using System.Threading;
using System.Linq;
using System.IO;

namespace Zad2
{
    class Program
    {
        private static EventWaitHandle readFlag = new AutoResetEvent(false); 
        private static EventWaitHandle countFlag = new AutoResetEvent(false);
        static void Main(string[] args)
        {
            string text = "Ala ma kota. Kot Ali nazywa się Filemon. Zazwyczaj koty lubią mleko, ale Filemon jest inny.";

            File.WriteAllTextAsync("exampleText.txt", text);

            TextSearch textSearch = new("exampleText.txt");
            Thread readThread = new(() =>
            {
                foreach (char c in textSearch.ExampleText)
                {
                    if (Char.IsUpper(c) && !textSearch.UsedLetters.Contains(c))
                    {
                        textSearch.FoundLetter = c;
                        textSearch.UsedLetters.Add(c);
                        Console.Write(c + " - ");
                        countFlag.Set();
                        readFlag.WaitOne();
                    }
                }
                textSearch.finishedSearch = true;
            });

            Thread countThread = new(() =>
            {
                do
                {
                    countFlag.WaitOne();
                    int letterCount = textSearch.ExampleText.Count(f => f == textSearch.FoundLetter);
                    Console.Write(letterCount);
                    Console.Write("\n");
                    readFlag.Set();
                }
                while (!textSearch.finishedSearch);
            });
            readThread.Start();
            countThread.Start();
        }
    }

    public class TextSearch
    {
        public string ExampleText;
        public List<char> UsedLetters = new();
        public char FoundLetter;
        public bool finishedSearch = false;
        public TextSearch(string filePath)
        {
            ExampleText = System.IO.File.ReadAllText(@filePath);
        }
    }
}
