﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.Threading;

namespace Lab1_UTCP
{
    public partial class Server : Form
    {
        

        private const int listenPort = 11000;
        public Server()
        {
            InitializeComponent();

          
        }
      private  void StartListener()
        { //ewentualnie static void
            UdpClient listener = new UdpClient(listenPort);
            IPEndPoint groupEP = new IPEndPoint(IPAddress.Any, listenPort);

            try
            {
                while (true)
                {

                    textBox2.Text = "Waiting for broadcast";
                    //Console.WriteLine("Waiting for broadcast");
                    byte[] bytes = listener.Receive(ref groupEP);

                    textBox2.Text = "Recived broadcast from: " + groupEP;
                    //  Console.WriteLine($"Received broadcast from {groupEP} :");
                   // textBox2.Text = ($" {Encoding.ASCII.GetString(bytes, 0, bytes.Length)}");

                    textBox2.Text = Encoding.ASCII.GetString(bytes, 0, bytes.Length);
                    //   Console.WriteLine($" {Encoding.ASCII.GetString(bytes, 0, bytes.Length)}");
                }
            }
            catch (SocketException ex)
            {
                textBox2.Text = " " + (ex);
                //Console.WriteLine(e);
            }
            finally
            {
                listener.Close();
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            StartListener();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        
       

        

       
    }
}
