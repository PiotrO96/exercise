package com.example.ps4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class WelcomeActivity extends AppCompatActivity {

    private TextView textViewWelcome;
    private Button buttonEditProfile;
    private  Account account;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);
        setTitle(R.string.welcome);
        textViewWelcome = findViewById(R.id.textViewWelcome);
        Intent intent = getIntent();
         account = (Account) intent.getSerializableExtra("account");
        textViewWelcome.setText(getString(R.string.welcome)+ " " + account.getUsername());

        buttonEditProfile = findViewById(R.id.buttonEditProfile);
        buttonEditProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1 = new Intent(WelcomeActivity.this, PanelActivity.class);
                intent1.putExtra("account", account);
                startActivity(intent1);
            }
        });
    }
}