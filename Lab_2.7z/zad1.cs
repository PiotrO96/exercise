using System;
using System.Threading;

namespace Lab2
{
    class Program
    {
        static void Main(string[] args)
        {
            double[,] numbers = new double[9,9];
            Random rnd = new((int)DateTime.Now.Ticks);

            for (int x = 0; x < numbers.GetLength(0); x++)
            {
                for (int y = 0; y < numbers.GetLength(1); y++)
                {
                    numbers[x,y] = Math.Round((rnd.NextDouble() * (20 - 1)) + 1, 2);
                }
            }

            Thread mojWatek = new(delegate () {
                Console.WriteLine(SumMatrixElements(numbers));
            });
            mojWatek.Start();
        }

        public static double SumMatrixElements(double[,] matrix)
        {
            double sum = 0;

            for (int x = 0; x < matrix.GetLength(0); x++)
            {
                for (int y = 0; y < matrix.GetLength(1); y++)
                {
                    sum += matrix[x, y];
                }
            }

            return sum;
        }
    }
}
