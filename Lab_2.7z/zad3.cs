using System;
using System.Threading;

namespace Lab2
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            Random rnd = new((int)DateTime.Now.Ticks);

            double[,] numbers = new double[10000, 10000];
            double scalar = Math.Round((rnd.NextDouble() * (20 - 1)) + 1, 2);
            

            for (int x = 0; x < numbers.GetLength(0); x++)
            {
                for (int y = 0; y < numbers.GetLength(1); y++)
                {
                    numbers[x, y] = Math.Round((rnd.NextDouble() * (20 - 1)) + 1, 2);
                }
            }

            int start1 = Environment.TickCount;

            for (int x = 0; x < numbers.GetLength(0)-1; x++)
            {
                Thread newThread = new(delegate ()
                {
                    MultipleRowByScalar(numbers, x, scalar);
                });
                newThread.Priority = ThreadPriority.Lowest;
                newThread.Start();
            }

            int stop1 = Environment.TickCount;
            Console.WriteLine("Obliczenia sekwencyjne trwały " + (stop1 - start1).ToString() + " ms.");
        }

        public static void MultipleRowByScalar(double[,] matrix, int row, double scalar)
        {
            for (int y = 0; y < matrix.GetLength(1); y++)
            {
                matrix[row, y] = matrix[row, y] * scalar;
            }
        }
    }
}
