using System;

namespace Lab2
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            Random rnd = new((int)DateTime.Now.Ticks);

            double[,] numbers = new double[9, 9];
            double scalar = Math.Round((rnd.NextDouble() * (20 - 1)) + 1, 2);
            

            for (int x = 0; x < numbers.GetLength(0); x++)
            {
                for (int y = 0; y < numbers.GetLength(1); y++)
                {
                    numbers[x, y] = Math.Round((rnd.NextDouble() * (20 - 1)) + 1, 2);
                }
            }

            int start = Environment.TickCount;

            for (int x = 0; x < numbers.GetLength(0); x++)
            {
                for (int y = 0; y < numbers.GetLength(1); y++)
                {
                    numbers[x, y] = numbers[x, y] * scalar;
                }
            }

            int stop = Environment.TickCount;
            Console.WriteLine("Obliczenia sekwencyjne trwały " + (stop - start).ToString() + " ms.");
        }
    }
}
