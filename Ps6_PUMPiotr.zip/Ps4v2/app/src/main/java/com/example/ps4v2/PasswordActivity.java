package com.example.ps4v2;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class PasswordActivity extends AppCompatActivity {

    EditText newPass1, newPass2, oldPass;
    Button submit;

    DataBaseHelper baza;

    int d=0;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_password);

        oldPass = findViewById(R.id.editCurrentPassword);
        newPass1 = findViewById(R.id.editNewPassword);
        newPass2 = findViewById(R.id.editTextRepeatPassword);
        submit = findViewById(R.id.buttonSave);

        baza = new DataBaseHelper(this);

        d = getIntent().getIntExtra("defaultPass",0);


        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(baza.login(Data.username, oldPass.getText().toString())){
                    if(newPass1.getText().toString().equals(newPass2.getText().toString())){
                        if(baza.upadateUserPass(Data.id,newPass1.getText().toString())) {
                            if(d==1){ baza.upadateUserPassDef(Data.id);}
                            Toast.makeText(PasswordActivity.this, "password changed", Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(getApplicationContext(), AdminPanel.class));
                        }
                        else Log.d("Users", "Error password changing");
                    }
                    else Toast.makeText(PasswordActivity.this, "New password is diffrent from old", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
        startActivity(new Intent(getApplicationContext(), AdminPanel.class));
    }
}
