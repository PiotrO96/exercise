package com.example.ps4v2;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {
    EditText username, password;
    Button login;
    Authorization[] Users = new Authorization[5];

    static DataBaseHelper baza;
    public Authorization uzytkownik;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        username = findViewById(R.id.editTextUsername);
        password = findViewById(R.id.editTextPassword);
        login = findViewById(R.id.buttonLogin);

        baza = new DataBaseHelper(this);
        if(baza.checkUserIsExist("admin")==false) {
            baza.addUser("admin", 1,"Grzegorz Brzeczyszczykiewicz");
            baza.addUser("patryk", 0, "Patryk Z");
            baza.addUser("random", 0, "Jakis random");
            Log.d("Users", "admin added");
        }else Log.d("Users", " not added");


        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String usernameS = username.getText().toString();
                String passwdS= password.getText().toString();
                for(int i=0; i<Users.length; i++) {
                    Log.d("Users", "" + usernameS + " - " + passwdS);
                    if (baza.login(usernameS, passwdS)){
                        Toast.makeText(MainActivity.this, "login", Toast.LENGTH_SHORT).show();
                        Log.d("Users", "login "+usernameS+" id: "+baza.selectIdByUsername(usernameS));

                        Data.id = baza.selectIdByUsername(usernameS);
                        Data.name = baza.selectUserById(Data.id).getString(3);
                        Data.username = baza.selectUserById(Data.id).getString(1);
                        Data.isadmin = baza.selectUserById(Data.id).getInt(2);

                        if(baza.checkDefaultPass(Data.id)){
                            Intent intent = new Intent(MainActivity.this, PasswordActivity.class);
                            intent.putExtra("defaultPass", 1);
                            startActivity(intent);
                            finish();
                        }else {
                            Intent intent = new Intent(MainActivity.this, AdminPanel.class);

                            startActivity(intent);
                            finish();
                            break;
                        }
                    }
                    else {
                        Toast.makeText(MainActivity.this, "wrong username or password", Toast.LENGTH_SHORT).show();
                        password.setText(null);
                    }
                }
            }
        });
    }
}