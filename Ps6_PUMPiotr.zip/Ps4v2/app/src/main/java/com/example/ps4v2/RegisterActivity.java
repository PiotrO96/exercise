package com.example.ps4v2;

import static android.text.TextUtils.isEmpty;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class RegisterActivity extends AppCompatActivity {
    EditText username, name;
    Spinner isAdmin;
    Button submit;
    int intRange;
    boolean selectRange = false;

    DataBaseHelper baza;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        baza = new DataBaseHelper(this);
        username = findViewById(R.id.editTextUsername);
        name = findViewById(R.id.editTextFullName);
        isAdmin = findViewById(R.id.RegisterIsAdmin);
        submit = findViewById(R.id.buttonSave);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.isAdmin_list, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        isAdmin.setAdapter(adapter);

        isAdmin.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                intRange = position;
                selectRange = true;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(isEmpty(username.getText()) ||
                        isEmpty(name.getText()) ||
                        selectRange){
                    if(!baza.checkUserIsExist(username.getText().toString())){
                        if(baza.addUser(username.getText().toString(), intRange, name.getText().toString())) {
                            startActivity(new Intent(getApplicationContext(), AdminPanel.class));
                            Toast.makeText(RegisterActivity.this, "User added", Toast.LENGTH_SHORT).show();
                            finish();
                        }
                        else Toast.makeText(RegisterActivity.this, "Error in user adding", Toast.LENGTH_SHORT).show();
                    }else
                        Toast.makeText(RegisterActivity.this, "user exists", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
        startActivity(new Intent(getApplicationContext(), MainActivity.class));
    }
}
