package com.example.ps4v2;

public class Authorization {

    public int Id;
    public String Username;
    public int Isadmin;
    private String Password;
    public String Name;

    public Authorization(int id, String user, String passwd, int isadmin, String name){
        Id = id;
        Username = user;
        Password = "abc"+passwd+"def";
        Isadmin = isadmin;
        Name = name;
    }
    public boolean checkPass(String user, String pass){
        String passSalt = "abc"+pass+"def";
        if(user.equals(Username) && passSalt.equals(Password)) return true;
        else return false;
    }
}
