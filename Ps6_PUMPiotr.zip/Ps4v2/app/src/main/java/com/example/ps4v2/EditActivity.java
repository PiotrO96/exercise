package com.example.ps4v2;
import static android.text.TextUtils.isEmpty;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class EditActivity extends AppCompatActivity {

    EditText username;
    EditText name;
    EditText password;
    Spinner isAdmin;
    int intIsAdmin = 0;
    int editId=0;
    boolean selectRange= false;
    DataBaseHelper baza;
    Button submit;
    Button delete;
    Button editPassword;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit);
        baza = new DataBaseHelper(this);


        editId = getIntent().getIntExtra("edit",0);
        Log.d("Users", "User edited "+ editId);

        editId++;

        username = findViewById(R.id.editUsername);
        name = findViewById(R.id.editFullname);
        password = findViewById(R.id.editPassword);
        isAdmin = findViewById(R.id.spinnerIsAdmin);
        submit = findViewById(R.id.buttonEditUser);
        delete = findViewById(R.id.buttonDelete);


        username.setText(baza.selectUserById(editId).getString(1));
        name.setText(baza.selectUserById(editId).getString(3));

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.isAdmin_list, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        isAdmin.setAdapter(adapter);

        intIsAdmin = baza.selectUserById(editId).getInt(2);

        isAdmin.setSelection(intIsAdmin);

        isAdmin.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                intIsAdmin = position;
                selectRange = true;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(isEmpty(username.getText())||
                        isEmpty(name.getText())
                        || isEmpty(password.getText())){
                    Toast.makeText(EditActivity.this, "All fields must be filled", Toast.LENGTH_SHORT).show();
                }else
                if(baza.upadateUser(editId, username.getText().toString(), password.getText().toString(), intIsAdmin, name.getText().toString())){
                    //if(baza.upadateUser(editId, username.getText().toString(), intRange, name.getText().toString())){
                    Toast.makeText(EditActivity.this, "Date changed", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(getApplicationContext(), AdminPanel.class));
                    finish();
                }else Toast.makeText(EditActivity.this, "Editing user error", Toast.LENGTH_SHORT).show();

            }
        });
        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new AlertDialog.Builder(EditActivity.this).setMessage(
                        "Do you want delete user ?").setPositiveButton(
                        "Delete", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                if (baza.deleteUser(editId)){
                                    Toast.makeText(EditActivity.this, "User deleted.", Toast.LENGTH_SHORT).show();
                                    startActivity(new Intent(getApplicationContext(), AdminPanel.class));
                                    finish();
                                }
                                else Toast.makeText(EditActivity.this, "Error deleting user", Toast.LENGTH_SHORT).show();
                            }
                        }).show();
            }
        });

    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
        startActivity(new Intent(getApplicationContext(), AdminPanel.class));
    }

}
