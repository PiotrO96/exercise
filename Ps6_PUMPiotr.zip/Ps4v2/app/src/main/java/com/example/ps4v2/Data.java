package com.example.ps4v2;

public class Data {

    public static int id = 0;
    public static String username = "example";
    public static String name = "example";
    public static int isadmin = 0;
    public static String salt = "abc";
}
