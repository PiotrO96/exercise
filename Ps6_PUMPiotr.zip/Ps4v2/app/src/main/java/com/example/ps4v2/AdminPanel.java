package com.example.ps4v2;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class AdminPanel extends AppCompatActivity {

    TextView textView;

    Button addUser;
    Button changePass;
    ListView listUsers;
    DataBaseHelper baza;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_panel);
        baza = new DataBaseHelper(this);

        textView = findViewById(R.id.textViewHello);
        addUser = findViewById(R.id.buttonAddNewUser);
        listUsers = findViewById(R.id.panelListViewUser);
        changePass = findViewById(R.id.buttonChangePassword);


        String a;
        if(Data.isadmin==1)
            a = "Admin";
        else
            a = "User";

        textView.setText(a + ": " + Data.name);

        if(Data.isadmin==1){
            addUser.setEnabled(true);
            RefreshList();
        }

        addUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), RegisterActivity.class));
                finish();
            }
        });

        listUsers.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(AdminPanel.this, EditActivity.class);
                intent.putExtra("edit", position);
                startActivity(intent);
                finish();
            }
        });

        changePass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), PasswordActivity.class));
                finish();
            }
        });
    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
        startActivity(new Intent(getApplicationContext(), MainActivity.class));
    }

    public void RefreshList(){
        Cursor usersCursor = baza.selectAll();
        UsersAdapter PunktyAdapter = new UsersAdapter(AdminPanel.this, usersCursor);
        listUsers.setAdapter(PunktyAdapter);
        registerForContextMenu(listUsers);
    }


}
