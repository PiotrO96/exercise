﻿namespace Odtwarzacz_audio
{
    partial class Form1
    {
        /// <summary>
        /// Wymagana zmienna projektanta.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Wyczyść wszystkie używane zasoby.
        /// </summary>
        /// <param name="disposing">prawda, jeżeli zarządzane zasoby powinny zostać zlikwidowane; Fałsz w przeciwnym wypadku.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kod generowany przez Projektanta formularzy systemu Windows

        /// <summary>
        /// Metoda wymagana do obsługi projektanta — nie należy modyfikować
        /// jej zawartości w edytorze kodu.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.menuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.zamknijToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.odtwarznieToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.playSyncToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.playAsyncToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.stopToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nextToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.prevToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.loopToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.FilePathTxtBox = new System.Windows.Forms.TextBox();
            this.Stop = new System.Windows.Forms.Button();
            this.Next = new System.Windows.Forms.Button();
            this.Prev = new System.Windows.Forms.Button();
            this.Loop = new System.Windows.Forms.Button();
            this.SelectFile = new System.Windows.Forms.Button();
            this.playlist = new System.Windows.Forms.Button();
            this.PlaySync = new System.Windows.Forms.Button();
            this.PlayAsync = new System.Windows.Forms.Button();
            this.listBox2 = new System.Windows.Forms.ListBox();
            this.listBox3 = new System.Windows.Forms.ListBox();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.URL = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.Wyb3 = new System.Windows.Forms.Button();
            this.Path = new System.Windows.Forms.TextBox();
            this.menuStrip1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuToolStripMenuItem,
            this.odtwarznieToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // menuToolStripMenuItem
            // 
            this.menuToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.zamknijToolStripMenuItem});
            this.menuToolStripMenuItem.Name = "menuToolStripMenuItem";
            this.menuToolStripMenuItem.Size = new System.Drawing.Size(50, 20);
            this.menuToolStripMenuItem.Text = "Menu";
            this.menuToolStripMenuItem.Click += new System.EventHandler(this.menuToolStripMenuItem_Click);
            // 
            // zamknijToolStripMenuItem
            // 
            this.zamknijToolStripMenuItem.Name = "zamknijToolStripMenuItem";
            this.zamknijToolStripMenuItem.Size = new System.Drawing.Size(117, 22);
            this.zamknijToolStripMenuItem.Text = "Zamknij";
            this.zamknijToolStripMenuItem.Click += new System.EventHandler(this.zamknijToolStripMenuItem_Click);
            // 
            // odtwarznieToolStripMenuItem
            // 
            this.odtwarznieToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.playSyncToolStripMenuItem,
            this.playAsyncToolStripMenuItem,
            this.stopToolStripMenuItem,
            this.nextToolStripMenuItem,
            this.prevToolStripMenuItem,
            this.loopToolStripMenuItem});
            this.odtwarznieToolStripMenuItem.Name = "odtwarznieToolStripMenuItem";
            this.odtwarznieToolStripMenuItem.Size = new System.Drawing.Size(79, 20);
            this.odtwarznieToolStripMenuItem.Text = "Odtwarznie";
            // 
            // playSyncToolStripMenuItem
            // 
            this.playSyncToolStripMenuItem.Name = "playSyncToolStripMenuItem";
            this.playSyncToolStripMenuItem.Size = new System.Drawing.Size(128, 22);
            this.playSyncToolStripMenuItem.Text = "PlaySync";
            this.playSyncToolStripMenuItem.Click += new System.EventHandler(this.playSyncToolStripMenuItem_Click);
            // 
            // playAsyncToolStripMenuItem
            // 
            this.playAsyncToolStripMenuItem.Name = "playAsyncToolStripMenuItem";
            this.playAsyncToolStripMenuItem.Size = new System.Drawing.Size(128, 22);
            this.playAsyncToolStripMenuItem.Text = "PlayAsync";
            this.playAsyncToolStripMenuItem.Click += new System.EventHandler(this.playAsyncToolStripMenuItem_Click);
            // 
            // stopToolStripMenuItem
            // 
            this.stopToolStripMenuItem.Name = "stopToolStripMenuItem";
            this.stopToolStripMenuItem.Size = new System.Drawing.Size(128, 22);
            this.stopToolStripMenuItem.Text = "Stop";
            this.stopToolStripMenuItem.Click += new System.EventHandler(this.stopToolStripMenuItem_Click);
            // 
            // nextToolStripMenuItem
            // 
            this.nextToolStripMenuItem.Name = "nextToolStripMenuItem";
            this.nextToolStripMenuItem.Size = new System.Drawing.Size(128, 22);
            this.nextToolStripMenuItem.Text = "Next";
            this.nextToolStripMenuItem.Click += new System.EventHandler(this.nextToolStripMenuItem_Click);
            // 
            // prevToolStripMenuItem
            // 
            this.prevToolStripMenuItem.Name = "prevToolStripMenuItem";
            this.prevToolStripMenuItem.Size = new System.Drawing.Size(128, 22);
            this.prevToolStripMenuItem.Text = "Prev";
            this.prevToolStripMenuItem.Click += new System.EventHandler(this.prevToolStripMenuItem_Click);
            // 
            // loopToolStripMenuItem
            // 
            this.loopToolStripMenuItem.Name = "loopToolStripMenuItem";
            this.loopToolStripMenuItem.Size = new System.Drawing.Size(128, 22);
            this.loopToolStripMenuItem.Text = "Loop";
            this.loopToolStripMenuItem.Click += new System.EventHandler(this.loopToolStripMenuItem_Click);
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(660, 110);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(128, 238);
            this.listBox1.TabIndex = 2;
            this.listBox1.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // FilePathTxtBox
            // 
            this.FilePathTxtBox.Location = new System.Drawing.Point(482, 110);
            this.FilePathTxtBox.Name = "FilePathTxtBox";
            this.FilePathTxtBox.Size = new System.Drawing.Size(172, 20);
            this.FilePathTxtBox.TabIndex = 5;
            // 
            // Stop
            // 
            this.Stop.Location = new System.Drawing.Point(59, 357);
            this.Stop.Name = "Stop";
            this.Stop.Size = new System.Drawing.Size(75, 23);
            this.Stop.TabIndex = 7;
            this.Stop.Text = "Stop";
            this.Stop.UseVisualStyleBackColor = true;
            this.Stop.Click += new System.EventHandler(this.Stop_Click);
            // 
            // Next
            // 
            this.Next.Location = new System.Drawing.Point(223, 357);
            this.Next.Name = "Next";
            this.Next.Size = new System.Drawing.Size(75, 23);
            this.Next.TabIndex = 10;
            this.Next.Text = "Next";
            this.Next.UseVisualStyleBackColor = true;
            this.Next.Click += new System.EventHandler(this.Next_Click);
            // 
            // Prev
            // 
            this.Prev.Location = new System.Drawing.Point(305, 357);
            this.Prev.Name = "Prev";
            this.Prev.Size = new System.Drawing.Size(75, 23);
            this.Prev.TabIndex = 11;
            this.Prev.Text = "Prev";
            this.Prev.UseVisualStyleBackColor = true;
            this.Prev.Click += new System.EventHandler(this.Prev_Click);
            // 
            // Loop
            // 
            this.Loop.Location = new System.Drawing.Point(387, 356);
            this.Loop.Name = "Loop";
            this.Loop.Size = new System.Drawing.Size(75, 23);
            this.Loop.TabIndex = 12;
            this.Loop.Text = "Loop";
            this.Loop.UseVisualStyleBackColor = true;
            this.Loop.Click += new System.EventHandler(this.Loop_Click);
            // 
            // SelectFile
            // 
            this.SelectFile.Location = new System.Drawing.Point(482, 52);
            this.SelectFile.Name = "SelectFile";
            this.SelectFile.Size = new System.Drawing.Size(172, 29);
            this.SelectFile.TabIndex = 14;
            this.SelectFile.Text = "SelectFile";
            this.SelectFile.UseVisualStyleBackColor = true;
            this.SelectFile.Click += new System.EventHandler(this.SelectFile_Click);
            // 
            // playlist
            // 
            this.playlist.Location = new System.Drawing.Point(660, 52);
            this.playlist.Name = "playlist";
            this.playlist.Size = new System.Drawing.Size(128, 29);
            this.playlist.TabIndex = 15;
            this.playlist.Text = "Add to playlist";
            this.playlist.UseVisualStyleBackColor = true;
            this.playlist.Click += new System.EventHandler(this.playlist_Click);
            // 
            // PlaySync
            // 
            this.PlaySync.Location = new System.Drawing.Point(140, 354);
            this.PlaySync.Name = "PlaySync";
            this.PlaySync.Size = new System.Drawing.Size(75, 25);
            this.PlaySync.TabIndex = 16;
            this.PlaySync.Text = "PlaySync";
            this.PlaySync.UseVisualStyleBackColor = true;
            this.PlaySync.Click += new System.EventHandler(this.PlaySync_Click);
            // 
            // PlayAsync
            // 
            this.PlayAsync.Location = new System.Drawing.Point(140, 325);
            this.PlayAsync.Name = "PlayAsync";
            this.PlayAsync.Size = new System.Drawing.Size(75, 23);
            this.PlayAsync.TabIndex = 17;
            this.PlayAsync.Text = "PlayAsync";
            this.PlayAsync.UseVisualStyleBackColor = true;
            this.PlayAsync.Click += new System.EventHandler(this.PlayAsync_Click);
            // 
            // listBox2
            // 
            this.listBox2.FormattingEnabled = true;
            this.listBox2.Location = new System.Drawing.Point(12, 170);
            this.listBox2.Name = "listBox2";
            this.listBox2.Size = new System.Drawing.Size(172, 108);
            this.listBox2.TabIndex = 19;
            this.listBox2.SelectedIndexChanged += new System.EventHandler(this.listBox2_SelectedIndexChanged);
            // 
            // listBox3
            // 
            this.listBox3.FormattingEnabled = true;
            this.listBox3.Location = new System.Drawing.Point(12, 69);
            this.listBox3.Name = "listBox3";
            this.listBox3.Size = new System.Drawing.Size(172, 95);
            this.listBox3.TabIndex = 20;
            this.listBox3.SelectedIndexChanged += new System.EventHandler(this.listBox3_SelectedIndexChanged);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1});
            this.statusStrip1.Location = new System.Drawing.Point(0, 428);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(800, 22);
            this.statusStrip1.TabIndex = 21;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(118, 17);
            this.toolStripStatusLabel1.Text = "toolStripStatusLabel1";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(702, 97);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(45, 13);
            this.label1.TabIndex = 22;
            this.label1.Text = "Playlista";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(479, 94);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 13);
            this.label2.TabIndex = 23;
            this.label2.Text = "File path";
            // 
            // URL
            // 
            this.URL.Location = new System.Drawing.Point(482, 170);
            this.URL.Name = "URL";
            this.URL.Size = new System.Drawing.Size(172, 20);
            this.URL.TabIndex = 24;
            this.URL.TextChanged += new System.EventHandler(this.URL_TextChanged);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(482, 136);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(172, 28);
            this.button1.TabIndex = 25;
            this.button1.Text = " From URL";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Wyb3
            // 
            this.Wyb3.Location = new System.Drawing.Point(12, 40);
            this.Wyb3.Name = "Wyb3";
            this.Wyb3.Size = new System.Drawing.Size(75, 23);
            this.Wyb3.TabIndex = 26;
            this.Wyb3.Text = "Add";
            this.Wyb3.UseVisualStyleBackColor = true;
            this.Wyb3.Click += new System.EventHandler(this.Wyb3_Click);
            // 
            // Path
            // 
            this.Path.Location = new System.Drawing.Point(190, 69);
            this.Path.Name = "Path";
            this.Path.Size = new System.Drawing.Size(100, 20);
            this.Path.TabIndex = 27;
            this.Path.TextChanged += new System.EventHandler(this.Path_TextChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.Path);
            this.Controls.Add(this.Wyb3);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.URL);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.listBox3);
            this.Controls.Add(this.listBox2);
            this.Controls.Add(this.PlayAsync);
            this.Controls.Add(this.PlaySync);
            this.Controls.Add(this.playlist);
            this.Controls.Add(this.SelectFile);
            this.Controls.Add(this.Loop);
            this.Controls.Add(this.Prev);
            this.Controls.Add(this.Next);
            this.Controls.Add(this.Stop);
            this.Controls.Add(this.FilePathTxtBox);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.TextBox FilePathTxtBox;
        private System.Windows.Forms.Button Stop;
        private System.Windows.Forms.Button Next;
        private System.Windows.Forms.Button Prev;
        private System.Windows.Forms.Button Loop;
        private System.Windows.Forms.ToolStripMenuItem menuToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem zamknijToolStripMenuItem;
        private System.Windows.Forms.Button SelectFile;
        private System.Windows.Forms.Button playlist;
        private System.Windows.Forms.Button PlaySync;
        private System.Windows.Forms.Button PlayAsync;
        private System.Windows.Forms.ToolStripMenuItem odtwarznieToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem playSyncToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem playAsyncToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem stopToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem nextToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem prevToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem loopToolStripMenuItem;
        private System.Windows.Forms.ListBox listBox2;
        private System.Windows.Forms.ListBox listBox3;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox URL;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button Wyb3;
        private System.Windows.Forms.TextBox Path;
    }
}

