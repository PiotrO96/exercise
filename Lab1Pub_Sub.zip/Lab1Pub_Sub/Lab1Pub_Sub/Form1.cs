﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using NetMQ;
using NetMQ.Sockets;

namespace Lab1Pub_Sub
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            Random rand = new Random(50);
            using (var pubSocket = new PublisherSocket())
            {
                textBox1.Text = $"Publisher socket binding... {Environment.NewLine}";
               // Console.WriteLine("Publisher socket binding...");
                pubSocket.Options.SendHighWatermark = 1000;
                pubSocket.Bind("tcp://*:12345");
                for (var i = 0; i < 100; i++)
                {
                    var randomizedTopic = rand.NextDouble();
                    if (randomizedTopic > 0.5)
                    {
                        var msg = "TopicA msg-" + i;
                        textBox1.Text = $"Sending a message:  {Environment.NewLine}";
                        //Console.WriteLine("Sending message : {0}", msg);
                        pubSocket.SendMoreFrame("TopicA").SendFrame(msg);
                    }
                    else
                    {
                        //var dateandtime = "TopicB Date and time: " + i;
                        var dateandtime = Encoding.ASCII.GetBytes(DateTime.Now.ToString());
                        textBox1.Text = $"Sending message:  {Environment.NewLine}" + dateandtime;
                       // Console.WriteLine("Sending message : {0}", dateandtime);
                        pubSocket.SendMoreFrame("Date and time").SendFrame(dateandtime);
                    }
                    Thread.Sleep(500);
                }
            }
        }
    }
}
