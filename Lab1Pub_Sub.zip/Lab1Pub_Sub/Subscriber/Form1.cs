﻿
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using NetMQ;
using NetMQ.Sockets;

namespace Subscriber
{
    public partial class Form1 : Form
    {
        public static IList<string> allowableCommandLineArgs
               = new[] { "TopicA", "dateandtime", "All" };
        string args;
        public Form1()
        {
            InitializeComponent();
        }

       private void button1_Click(object sender, EventArgs e)
        {
            if (args.Length != 1 || !allowableCommandLineArgs.Contains(args))
            {
                textBox1.Text = "Expected one argument, either " + "'TopicA', 'dateandtime' or 'All'";
                // Console.WriteLine("Expected one argument, either " +
                //        "'TopicA', 'dateandtime' or 'All'");
                Environment.Exit(-1);
            }
            string topic = args == "All" ? "" : args;
            //Console.WriteLine("Subscriber started for Topic : {0}", topic);
            textBox1.Text = "Subscriber started for Topic : {0}"+ topic;
            using (var subSocket = new SubscriberSocket())
            {
                subSocket.Options.ReceiveHighWatermark = 1000;
                subSocket.Connect("tcp://localhost:12345");
                subSocket.Subscribe(topic);
                textBox1.Text = "Subscriber socket connecting...";
                //Console.WriteLine("Subscriber socket connecting...");
                while (true)
                {
                    string messageTopicReceived = subSocket.ReceiveFrameString();
                    string messageReceived = subSocket.ReceiveFrameString();
                    textBox1.Text = messageReceived;

                 //   Console.WriteLine(messageReceived);
                }
            }
        }
    }
}
