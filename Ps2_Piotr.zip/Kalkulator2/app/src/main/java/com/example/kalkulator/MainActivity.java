package com.example.kalkulator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    Button button1, button2, button3, button4,button5, button6, button7, button8, button9, button0,buttonRowna, buttonPlus, buttonOdj, buttonMnoz, buttonDziel, buttonCzysc, buttonPrzec;
    EditText Edit;
    int i;
    float a,b;

    boolean add, minus, multi, div;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button1 = findViewById(R.id.button1);
        button2 = findViewById(R.id.button2);
        button3 = findViewById(R.id.button3);
        button4 = findViewById(R.id.button4);
        button5 = findViewById(R.id.button5);
        button6 = findViewById(R.id.button6);
        button7 = findViewById(R.id.button7);
        button8 = findViewById(R.id.button8);
        button9 = findViewById(R.id.button9);
        button0 = findViewById(R.id.button0);
        buttonRowna = findViewById(R.id.buttonequal);
        buttonPlus = findViewById(R.id.buttonplus);
        buttonOdj = findViewById(R.id.buttonminus);
        buttonMnoz = findViewById(R.id.buttonstar);
        buttonDziel = findViewById(R.id.buttonslash);
        buttonCzysc = findViewById(R.id.buttonC);
        buttonPrzec = findViewById(R.id.buttondot);


        Edit = (EditText) findViewById(R.id.ViewResault);



        button1.setOnClickListener(new View.OnClickListener() { //przycisk 1
            @Override
            public void onClick(View v) {
                Edit.setText(Edit.getText()+"1");
            }
        });

        button2.setOnClickListener(new View.OnClickListener() { //Przycisk 2
            @Override
            public void onClick(View v) {
                Edit.setText(Edit.getText()+"2");
            }
        });
        button3.setOnClickListener(new View.OnClickListener() { //Przycisk 3
            @Override
            public void onClick(View v) {
                Edit.setText(Edit.getText()+"3");
            }
        });
        button4.setOnClickListener(new View.OnClickListener() { //Przycisk 4
            @Override
            public void onClick(View v) {
                Edit.setText(Edit.getText()+"4");
            }
        });
        button5.setOnClickListener(new View.OnClickListener() { //Przycisk 5
            @Override
            public void onClick(View v) {
                Edit.setText(Edit.getText()+"5");
            }
        });
        button6.setOnClickListener(new View.OnClickListener() { //Przycisk 6
            @Override
            public void onClick(View v) {
                Edit.setText(Edit.getText()+"6");
            }
        });
        button7.setOnClickListener(new View.OnClickListener() { //Przycisk 7
            @Override
            public void onClick(View v) {
                Edit.setText(Edit.getText()+"7");
            }
        });
        button8.setOnClickListener(new View.OnClickListener() { //Przycisk 8
            @Override
            public void onClick(View v) {
                Edit.setText(Edit.getText()+"8");
            }
        });
        button9.setOnClickListener(new View.OnClickListener() { //Przycisk 9
            @Override
            public void onClick(View v) {
                Edit.setText(Edit.getText()+"9");
            }
        });
        button0.setOnClickListener(new View.OnClickListener() { //Przycisk 0
            @Override
            public void onClick(View v) {
                Edit.setText(Edit.getText()+"0");
            }
        });
        buttonPlus.setOnClickListener(new View.OnClickListener() { //Przycisk +
            @Override
            public void onClick(View v) {

                if (Edit == null) {
                    Edit.setText("");
                } else {
                    a = Float.parseFloat(Edit.getText() + "");
                    add = true;
                    Edit.setText(null);
                }


            }
        });

        buttonOdj.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                a = Float.parseFloat(Edit.getText() + "");
                minus = true;
                Edit.setText(null);
            }
        });
        buttonMnoz.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                a = Float.parseFloat(Edit.getText() + "");
                multi = true;
                Edit.setText(null);
            }
        });
        buttonDziel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                a = Float.parseFloat(Edit.getText() + "");
                div = true;
                Edit.setText(null);
            }
        });

        buttonCzysc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Edit.setText("");
            }
        });

        buttonPrzec.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Edit.setText(Edit.getText() + ".");
            }
        });

        buttonRowna.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                b = Float.parseFloat(Edit.getText() + "");

                if (add == true) {
                    Edit.setText(a + b + "");
                    add = false;
                }

                if (minus == true) {
                    Edit.setText(a - b + "");
                    minus = false;
                }

                if (multi == true) {
                    Edit.setText(a * b + "");
                    multi = false;
                }

                if (div == true) {
                    Edit.setText(a / b + "");
                    div = false;

                    if( b ==0)
                    {
                        Edit.setText("Don't divide by zero.");

                    }
                }
            }
        });

    }
}