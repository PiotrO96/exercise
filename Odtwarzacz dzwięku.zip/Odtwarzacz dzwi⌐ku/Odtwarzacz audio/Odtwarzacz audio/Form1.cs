﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Media;
using System.IO;

namespace Odtwarzacz_audio
{
    public partial class Form1 : Form
    {
        string[] array1;
        string[] files, paths;
        string file;

        private SoundPlayer player;

        public Form1()
        {
            InitializeComponent();
            
    
            // Set up the status bar and other controls.
            InitializeControls();

            // Set up the SoundPlayer object.
            InitializeSound();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void toolStripStatusLabel1_Click(object sender, EventArgs e)
        {
         
        }
       

        // Sets up the SoundPlayer object.
        private void InitializeSound()
        {
            // nowy soundplayer
            player = new SoundPlayer();

            
        }

        private void SelectFile_Click(object sender, EventArgs e)
        {
           
             // tworzenie nowego openfiledialog
            OpenFileDialog dlg = new OpenFileDialog();

             // sprawdza czy istnieje wybrany plik
             dlg.CheckFileExists = true;

             // filtry tylko na typ pliku .wav 
             dlg.Filter = "WAV files (*.wav)|*.wav";
             dlg.DefaultExt = ".wav";

             // aktywuj okno wyboru pliku
             if (dlg.ShowDialog() == DialogResult.OK)
             {
                 // pobiera wybraną scieżkę pliku z okna dialogowego
                 this.FilePathTxtBox.Text = dlg.FileName;
                file = FilePathTxtBox.Text;
                toolStripStatusLabel1.Text =file;
                // Przypisz ścieżkę wybranego pliku do obiektu SoundPlayer.
                player.SoundLocation = FilePathTxtBox.Text;
             }


        }
        
        
       

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            player.SoundLocation = paths[listBox1.SelectedIndex]; // jakiekolwiek wybierzesz nazwe w lisboxie albo sciezke to skopiuje ci to do player.soundlocation
          
        }
        private void listBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            Path.Text = listBox3.SelectedItem.ToString();
            array1 = Directory.GetFiles(Path.Text);
            listBox2.Items.Clear();
            foreach (string name in array1)
            {

                if (File.Exists(name))
                {
                    // This path is a file
                    listBox2.Items.Add(name);
                }
            }
            Path.Text = listBox3.SelectedItem.ToString();

            array1 = Directory.GetDirectories(Path.Text);

            listBox3.Items.Clear();
            foreach (string name in array1)
            {
                if (Directory.Exists(name))
                {
                    // This path is a directory
                    listBox3.Items.Add(name);
                }

            }
        }

        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            SoundPlayer player = new SoundPlayer();
            try
            {

                player.SoundLocation = listBox2.SelectedItem.ToString();
                player.Load();
                player.Play();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error loading sound");
            }
        }

        private void playlist_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog1 = new OpenFileDialog();
            openFileDialog1.Multiselect = true; // pozwala nam wybrać wiele plików
            openFileDialog1.Filter = "WAV files (*.wav)|*.wav";
            openFileDialog1.DefaultExt = ".wav";
            if (openFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                files = openFileDialog1.SafeFileNames; //save only the names zapisuje nazwe pliku w files
                paths = openFileDialog1.FileNames; //save the fill paths kopiuje sciezke pliku do paths

                    for (int i = 0; i < files.Length; i++)
                {
                    listBox1.Items.Add(files[i]); //dodaje piosenki do listboxa
                 
                    toolStripStatusLabel1.Text = files[i]; // zeby status bar wyswietlał nam nazwe pliku
                }
                    
            }
           // player.SoundLocation = listBox1.Items(files[i]);

            //player.Load();
            //  player.Play();
        }
        private void InitializeControls()
        {
            //toolStripStatusLabel1.Text = "welcome"; //status bar


        }

    
        private void Stop_Click(object sender, EventArgs e) // Stops the currently playing .wav file, if any.
        {
            player.Stop();
            
        }

        private void toolStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }
        // Odtwarzanie synchroniczne pliku , jeśli będzie on duży.
        private void PlaySync_Click(object sender, EventArgs e)
        {
           try
            {
                player.PlaySync();
              //  toolStripStatusLabel1.Text = file;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error playing sound");
            }
            
        }
        // Asynchronously plays the selected .wav file once.
        private void PlayAsync_Click(object sender, EventArgs e)
        {

            try
            {

                player.Play();
                //  toolStripStatusLabel1.Text = file;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error playing sound");
            }
        }

        private void Next_Click(object sender, EventArgs e)
        {
            try
            {
                if (listBox1.SelectedIndex != listBox1.Items.Count - 1)
                    listBox1.SelectedIndex = listBox1.SelectedIndex + 1;
                player.Play();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error playing sound");
            }
        }

        private void Prev_Click(object sender, EventArgs e)
        {
            try
            {
                if (listBox1.SelectedIndex > 0)
                    listBox1.SelectedIndex = listBox1.SelectedIndex - 1;
                player.Play();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error playing sound");
            }
        }
        // Asynchronously plays the selected .wav file until the user
        // clicks the Stop button.
        private void Loop_Click(object sender, EventArgs e)
        {
            try
            {
                player.PlayLooping();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error playing sound");
            }
        }

        private void menuToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void zamknijToolStripMenuItem_Click(object sender, EventArgs e)
        {
           this.Close();
        }

        private void playSyncToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.PlaySync_Click(this, e);
        }

        private void playAsyncToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.PlayAsync_Click(this, e);
        }

        private void stopToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Stop_Click(this, e);
        }

        private void nextToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Next_Click(this, e);

        }

        private void prevToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Prev_Click(this, e);

        }

        private void statusBar2_PanelClick(object sender, StatusBarPanelClickEventArgs e)
        {

        }

        private void URL_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                file = URL.Text;
                toolStripStatusLabel1.Text = file;
                player.SoundLocation = file;
                player.Load();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error loading sound");
            }
        }

        private void Wyb3_Click(object sender, EventArgs e)
        {

            array1 = Directory.GetFiles(@"C:\");
            foreach (string name in array1)
            {
                if (File.Exists(name))
                {
                    // This path is a file
                    listBox2.Items.Add(name);
                }
            }
            array1 = Directory.GetDirectories(@"C:\");
            foreach (string name in array1)
            {
                if (Directory.Exists(name))
                {
                    // This path is a directory
                    listBox3.Items.Add(name);
                }

            }
        }

        private void Path_TextChanged(object sender, EventArgs e)
        {

        }

        private void loopToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Loop_Click(this, e);
        }


        

        
        

       
    }
}
