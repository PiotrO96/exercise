﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using NetMQ;
using NetMQ.Sockets;


namespace Lab1Req_Resp
{
    public partial class Form1 : Form
    {

        string msg = $"requestSocket : Sending  Date and Time{Environment.NewLine}";


        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
          


        }

        private void button2_Click(object sender, EventArgs e)
        {
            using (var responseSocket = new ResponseSocket("@tcp://*:5555"))
            using (var requestSocket = new RequestSocket(">tcp://localhost:5555"))
            {
                textBox2.Text = "localhost:5555";
                textBox1.Text += msg;
                textBox1.AppendText("\r\n");
                //Request
                //   textBox1.Text("requestSocket : Sending 'Hello");
                //  Console.WriteLine("requestSocket : Sending 'Hello'");
                //requestSocket.SendFrame("Hello");
                textBox1.Text = $"requestSocket : Sending  Date and Time {Environment.NewLine}".ToString();
                requestSocket.SendFrame(Encoding.ASCII.GetBytes(DateTime.Now.ToString()));
                //Response  
                var message = responseSocket.ReceiveFrameString();
               // msg = message;
               
                textBox1.Text += "responseSocket : Server Received: "+ message.ToString();
                // Console.WriteLine("responseSocket : Server Received '{0}'", message);
                //Console.WriteLine("responseSocket Sending 'World'");
                // responseSocket.SendFrame("World");
                //Request
                // message = requestSocket.ReceiveFrameString();
                // Console.WriteLine("requestSocket : Received '{0}'", message);
                //Console.ReadLine();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
