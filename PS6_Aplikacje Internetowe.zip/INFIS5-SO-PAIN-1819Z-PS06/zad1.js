function SimpleChart(elementId, width, height) {
  // uzupełnij funkcję-konstruktor niezbędnymi elementami aby zrealizować podaną w zadaniu funkcjonalność
  
  var figura = document.getElementById(elementId)
  figura.style.width=width + 'px';
  figura.style.height = height + 'px';
  
  var divs= document.createElement('div');
  var figcap = document.createElement('figcaption');
  figura.appendChild(divs);
  figura.appendChild(figcap);
  
  this.loadData = function(url) {
    // w tej metodzie dopisz kod podciągający dane z podanego w formacie 'json' z podanego adresu url
    
	//figura.innerHTML = '';
	divs.innerHTML='';
	console.log(figura);
	
	//figure.style.width = 100 + 'px';
	fetch(url).then(function(result){
		result.json().then(function(daneWykresu){
		console.log(daneWykresu);
		figura.innerHTML = daneWykresu.label;
		var max = daneWykresu.data.reduce(function(max, cur) {return cur.value > max ? cur.value : max}, 0);
		
		daneWykresu.data.forEach(function(element){
			var divs = document.createElement('div');
			
			divs.style.height ='50%';
			
			
		});
		});
	});
	
  };
}


	