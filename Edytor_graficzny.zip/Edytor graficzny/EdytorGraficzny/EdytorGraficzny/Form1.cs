﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing.Imaging;


namespace EdytorGraficzny
{
    public partial class Form1 : Form
    {
        Image image;
        bool paint = false;
        SolidBrush color;
        
        private System.Drawing.Graphics g;
        private System.Drawing.Pen pen1 = new System.Drawing.Pen(Color.Blue, 4F);
        Bitmap bm;

        public Form1()
        {
            InitializeComponent();
         
        }

      


        private void wybórNarzędziaToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

       

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void czyszczenieEkranuToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {

                pictureBox1.Image = null;
                //pictureBox1.Refresh();
                toolStripStatusLabel1.Text = "Ekran wyczyszczony ";
            }
            catch (Exception ex)
            { }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            toolStripStatusLabel1.Text = "Program uruchomiony ";
        }

        private void liniaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                g = pictureBox1.CreateGraphics();
                g.DrawLine(pen1, 250, 50, 400, 200);
                toolStripStatusLabel1.Text = "Wybrano linie ";
            }
            catch (Exception ex)
            { }
        }

        private void elipsaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                g = pictureBox1.CreateGraphics();
                g.DrawEllipse(pen1, 50, 50, 100, 150);
                toolStripStatusLabel1.Text = "Wybrano elipse ";
            }
            catch (Exception ex)
            { }
        }

        private void kwadratToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                g = pictureBox1.CreateGraphics();
                g.DrawRectangle(pen1, 30, 30, 50, 60);
                toolStripStatusLabel1.Text = "Wybrano kwadrat ";
            }
            catch (Exception ex)
            { }
        }

  
        private void wielokotToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                System.Drawing.Point[] p = new System.Drawing.Point[6];
                p[0].X = 0;
                p[0].Y = 0;
                p[1].X = 53;
                p[1].Y = 111;
                p[2].X = 114;
                p[2].Y = 86;
                p[3].X = 34;
                p[3].Y = 34;
                p[4].X = 165;
                p[4].Y = 7;
                g = pictureBox1.CreateGraphics();
                g.DrawPolygon(pen1, p);
                toolStripStatusLabel1.Text = "Wybrano wielokat ";
            }
            catch (Exception ex)
            { }
        }

        private void krzywaBezieraToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                g = pictureBox1.CreateGraphics();
                g.DrawBezier(pen1, 100, 200, 240, 250, 100, 200, 150, 30);
                toolStripStatusLabel1.Text = "Wybrano krzywo ";
            }
            catch (Exception ex)
            { }
        }

        private void koloToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                g = pictureBox1.CreateGraphics();
                g.DrawEllipse(pen1, 100, 100, 100, 100);
                toolStripStatusLabel1.Text = "Wybrano kolo ";
            }
            catch (Exception ex) { }
        }

        private void lukToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                g = pictureBox1.CreateGraphics();
                g.DrawArc(pen1, 150, 100, 150, 200, 150, 160);
                toolStripStatusLabel1.Text = "Wybrano luk ";
            }
            catch (Exception ex) { }
        }

        private void wycinekKolaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                g = pictureBox1.CreateGraphics();
                g.DrawPie(pen1, 50, 50, 150, 150, 0, 170);
                toolStripStatusLabel1.Text = "Wybrano wycinek kola ";
            }
            catch (Exception ex) { }
        }

        private void czerwonyToolStripMenuItem_Click(object sender, EventArgs e)
        {

            pen1.Color = Color.Red;
            toolStripStatusLabel1.Text = "Wybrano czerwony kolor ";
        }

        private void niebieskiToolStripMenuItem_Click(object sender, EventArgs e)
        {
            pen1.Color = Color.Blue;
            toolStripStatusLabel1.Text = "Wybrano niebieski kolor ";
        }

        private void czarnyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            pen1.Color = Color.Black;
            toolStripStatusLabel1.Text = "Wybrano czarny kolor ";
        }

        private void zielonyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            pen1.Color = Color.Green;
            toolStripStatusLabel1.Text = "Wybrano zielony kolor ";

        }

        private void fioletowyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            pen1.Color = Color.Purple;
            toolStripStatusLabel1.Text = "Wybrano fioletowy kolor ";

        }

        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {
            pen1.Width = 10F;
            toolStripStatusLabel1.Text = "Grubosc to 10 ";
        }

        private void toolStripMenuItem3_Click(object sender, EventArgs e)
        {
            pen1.Width = 15F;
            toolStripStatusLabel1.Text = "Grubosc to 15 ";
        }

        private void toolStripMenuItem4_Click(object sender, EventArgs e)
        {
            pen1.Width = 20F;
            toolStripStatusLabel1.Text = "Grubosc to 20 ";
        }

        private void toolStripMenuItem5_Click(object sender, EventArgs e)
        {
            pen1.Width = 1F;
            toolStripStatusLabel1.Text = "Grubosc to 1 ";
        }

        private void toolStripMenuItem6_Click(object sender, EventArgs e)
        {
            pen1.Width = 2F;
            toolStripStatusLabel1.Text = "Grubosc to 2 ";
        }

        private void toolStripMenuItem7_Click(object sender, EventArgs e)
        {
            pen1.Width = 3F;
            toolStripStatusLabel1.Text = "Grubosc to 3 ";
        }

        private void pictureBox1_MouseUp(object sender, MouseEventArgs e)
        {
            paint = false;
        }
        private void pictureBox1_MouseMove(object sender, MouseEventArgs e)
        {
            try
            {
                if (paint)
                {
                    if (btGumka.Text == "Gumka")
                    {
                        int size = Convert.ToInt32(tbSize.Text);
                        Graphics g = pictureBox1.CreateGraphics();

                        color = new SolidBrush(Color.Yellow);
                        g.FillEllipse(color, e.X - size / 2, e.Y - size / 2, size, size);

                    }
                    else
                    {
                        int Gumkasize = Convert.ToInt32(Gumka.Text);
                        Graphics g = pictureBox1.CreateGraphics();

                        color = new SolidBrush(Color.White);
                        g.FillEllipse(color, e.X - Gumkasize / 2, e.Y - Gumkasize / 2, Gumkasize, Gumkasize);

                    }

                }
            }
            catch (Exception ex) { }
        }

        private void pictureBox1_MouseDown(object sender, MouseEventArgs e)
        {
            paint = true;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        

        private void btGumka_Click(object sender, EventArgs e)
        {
            try
            {

                if (btGumka.Text == "Gumka")
                {
                    btGumka.Text = "Pen";
                    toolStripStatusLabel1.Text = "Wybrano gumke ";

                }
                else
                {
                    btGumka.Text = "Gumka";
                    toolStripStatusLabel1.Text = "Wybrano pena";
                }
            }
            catch (Exception ex)
            { }

        }

        private void wgranieTlaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                DialogResult result = openFileDialog1.ShowDialog();
                if (result == DialogResult.OK) // Test result.
                {
                    string file = openFileDialog1.FileName;
                    try
                    {
                        image = Image.FromFile(file);
                        // image = ResizeImage(image, this.Size);
                        // Set the PictureBox image property to this image.
                        // ... Then, adjust its height and width properties.
                        pictureBox1.Image = image;
                        toolStripStatusLabel1.Text = "Wgrano tlo";

                    }
                    catch (Exception ex)
                    {

                    }

                }
            }
            catch (Exception ex) { }
        }

        private void zapiszToolStripMenuItem_Click(object sender, EventArgs e)
        {
            /*saveFileDialog1.Filter = "JPG|*.jpg|PNG|*.png";
            
            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                int width = Convert.ToInt32(pictureBox1.Width);
                int height = Convert.ToInt32(pictureBox1.Height);
                Bitmap bmp1 = new Bitmap(width, height);
                pictureBox1.DrawToBitmap(bmp1, new Rectangle(0, 0, width, height));
                bmp1.Save(saveFileDialog1.FileName, ImageFormat.Jpeg);
            }*/
            try
            {
                using (SaveFileDialog sfdlg = new SaveFileDialog())
                {
                    sfdlg.Title = "Zapisz";
                    sfdlg.Filter = "Bitmap Images (*.bmp)|*.bmp|All files(*.*)|*.* |jpeg (*.jpeg)|*.jpeg|png (*.png)|*.png";
                    if (sfdlg.ShowDialog(this) == DialogResult.OK)
                    {
                        using (Bitmap bmp = new Bitmap(pictureBox1.Width, pictureBox1.Height))
                        {
                            pictureBox1.DrawToBitmap(bmp, new Rectangle(0, 0, bmp.Width, bmp.Height));
                            pictureBox1.Image = new Bitmap(pictureBox1.Width, pictureBox1.Height);
                            // pictureBox1.Image.Save(@"D:\Programy\Multimedia\ZapisZdjecGrafika\test.jpg", ImageFormat.Jpeg);
                            bmp.Save(sfdlg.FileName, ImageFormat.Bmp);


                        }
                    }
                }
            }
            catch (Exception ex) { }
            //pictureBox1.Image.Save(@"D:\Programy\Multimedia\ZapisZdjecGrafika\test.jpg", ImageFormat.Jpeg);
        }

        private void statusStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

      
    }
}
