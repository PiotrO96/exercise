﻿namespace EdytorGraficzny
{
    partial class Form1
    {
        /// <summary>
        /// Wymagana zmienna projektanta.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Wyczyść wszystkie używane zasoby.
        /// </summary>
        /// <param name="disposing">prawda, jeżeli zarządzane zasoby powinny zostać zlikwidowane; Fałsz w przeciwnym wypadku.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kod generowany przez Projektanta formularzy systemu Windows

        /// <summary>
        /// Metoda wymagana do obsługi projektanta — nie należy modyfikować
        /// jej zawartości w edytorze kodu.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.wybórNarzędziaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aktualneNarzedzieToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.wybórKoloruToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.czerwonyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.niebieskiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.czarnyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.zielonyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fioletowyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gruboscToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.zwiekszToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.zmniejszToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem6 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem7 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.operacjeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.czyszczenieEkranuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.zapisEkranuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.wgranieTlaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.zapiszToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.obiektyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.liniaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.elipsaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.koloToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lukToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kwadratToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.wielokotToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.krzywaBezieraToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.wycinekKolaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tbSize = new System.Windows.Forms.TextBox();
            this.Gumka = new System.Windows.Forms.TextBox();
            this.btGumka = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Dock = System.Windows.Forms.DockStyle.None;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.wybórNarzędziaToolStripMenuItem,
            this.operacjeToolStripMenuItem,
            this.obiektyToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(-10, 4);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(348, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // wybórNarzędziaToolStripMenuItem
            // 
            this.wybórNarzędziaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aktualneNarzedzieToolStripMenuItem,
            this.wybórKoloruToolStripMenuItem,
            this.gruboscToolStripMenuItem});
            this.wybórNarzędziaToolStripMenuItem.Name = "wybórNarzędziaToolStripMenuItem";
            this.wybórNarzędziaToolStripMenuItem.Size = new System.Drawing.Size(94, 20);
            this.wybórNarzędziaToolStripMenuItem.Text = "Panel narzędzi";
            this.wybórNarzędziaToolStripMenuItem.Click += new System.EventHandler(this.wybórNarzędziaToolStripMenuItem_Click);
            // 
            // aktualneNarzedzieToolStripMenuItem
            // 
            this.aktualneNarzedzieToolStripMenuItem.Name = "aktualneNarzedzieToolStripMenuItem";
            this.aktualneNarzedzieToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.aktualneNarzedzieToolStripMenuItem.Text = "Aktualne narzedzie";
            // 
            // wybórKoloruToolStripMenuItem
            // 
            this.wybórKoloruToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.czerwonyToolStripMenuItem,
            this.niebieskiToolStripMenuItem,
            this.czarnyToolStripMenuItem,
            this.zielonyToolStripMenuItem,
            this.fioletowyToolStripMenuItem});
            this.wybórKoloruToolStripMenuItem.Name = "wybórKoloruToolStripMenuItem";
            this.wybórKoloruToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.wybórKoloruToolStripMenuItem.Text = "Wybór koloru";
            // 
            // czerwonyToolStripMenuItem
            // 
            this.czerwonyToolStripMenuItem.Name = "czerwonyToolStripMenuItem";
            this.czerwonyToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.czerwonyToolStripMenuItem.Text = "Czerwony";
            this.czerwonyToolStripMenuItem.Click += new System.EventHandler(this.czerwonyToolStripMenuItem_Click);
            // 
            // niebieskiToolStripMenuItem
            // 
            this.niebieskiToolStripMenuItem.Name = "niebieskiToolStripMenuItem";
            this.niebieskiToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.niebieskiToolStripMenuItem.Text = "Niebieski";
            this.niebieskiToolStripMenuItem.Click += new System.EventHandler(this.niebieskiToolStripMenuItem_Click);
            // 
            // czarnyToolStripMenuItem
            // 
            this.czarnyToolStripMenuItem.Name = "czarnyToolStripMenuItem";
            this.czarnyToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.czarnyToolStripMenuItem.Text = "Czarny";
            this.czarnyToolStripMenuItem.Click += new System.EventHandler(this.czarnyToolStripMenuItem_Click);
            // 
            // zielonyToolStripMenuItem
            // 
            this.zielonyToolStripMenuItem.Name = "zielonyToolStripMenuItem";
            this.zielonyToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.zielonyToolStripMenuItem.Text = "Zielony";
            this.zielonyToolStripMenuItem.Click += new System.EventHandler(this.zielonyToolStripMenuItem_Click);
            // 
            // fioletowyToolStripMenuItem
            // 
            this.fioletowyToolStripMenuItem.Name = "fioletowyToolStripMenuItem";
            this.fioletowyToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.fioletowyToolStripMenuItem.Text = "Fioletowy";
            this.fioletowyToolStripMenuItem.Click += new System.EventHandler(this.fioletowyToolStripMenuItem_Click);
            // 
            // gruboscToolStripMenuItem
            // 
            this.gruboscToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.zwiekszToolStripMenuItem,
            this.toolStripMenuItem2,
            this.toolStripMenuItem3,
            this.toolStripMenuItem4});
            this.gruboscToolStripMenuItem.Name = "gruboscToolStripMenuItem";
            this.gruboscToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.gruboscToolStripMenuItem.Text = "Grubosc";
            // 
            // zwiekszToolStripMenuItem
            // 
            this.zwiekszToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.zmniejszToolStripMenuItem,
            this.toolStripMenuItem5,
            this.toolStripMenuItem6,
            this.toolStripMenuItem7});
            this.zwiekszToolStripMenuItem.Name = "zwiekszToolStripMenuItem";
            this.zwiekszToolStripMenuItem.Size = new System.Drawing.Size(116, 22);
            this.zwiekszToolStripMenuItem.Text = "Wieksza";
            // 
            // zmniejszToolStripMenuItem
            // 
            this.zmniejszToolStripMenuItem.Name = "zmniejszToolStripMenuItem";
            this.zmniejszToolStripMenuItem.Size = new System.Drawing.Size(120, 22);
            this.zmniejszToolStripMenuItem.Text = "Mniejsza";
            // 
            // toolStripMenuItem5
            // 
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            this.toolStripMenuItem5.Size = new System.Drawing.Size(120, 22);
            this.toolStripMenuItem5.Text = "1";
            this.toolStripMenuItem5.Click += new System.EventHandler(this.toolStripMenuItem5_Click);
            // 
            // toolStripMenuItem6
            // 
            this.toolStripMenuItem6.Name = "toolStripMenuItem6";
            this.toolStripMenuItem6.Size = new System.Drawing.Size(120, 22);
            this.toolStripMenuItem6.Text = "2";
            this.toolStripMenuItem6.Click += new System.EventHandler(this.toolStripMenuItem6_Click);
            // 
            // toolStripMenuItem7
            // 
            this.toolStripMenuItem7.Name = "toolStripMenuItem7";
            this.toolStripMenuItem7.Size = new System.Drawing.Size(120, 22);
            this.toolStripMenuItem7.Text = "3";
            this.toolStripMenuItem7.Click += new System.EventHandler(this.toolStripMenuItem7_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(116, 22);
            this.toolStripMenuItem2.Text = "10";
            this.toolStripMenuItem2.Click += new System.EventHandler(this.toolStripMenuItem2_Click);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(116, 22);
            this.toolStripMenuItem3.Text = "15";
            this.toolStripMenuItem3.Click += new System.EventHandler(this.toolStripMenuItem3_Click);
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(116, 22);
            this.toolStripMenuItem4.Text = "20";
            this.toolStripMenuItem4.Click += new System.EventHandler(this.toolStripMenuItem4_Click);
            // 
            // operacjeToolStripMenuItem
            // 
            this.operacjeToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.czyszczenieEkranuToolStripMenuItem,
            this.zapisEkranuToolStripMenuItem,
            this.wgranieTlaToolStripMenuItem,
            this.zapiszToolStripMenuItem});
            this.operacjeToolStripMenuItem.Name = "operacjeToolStripMenuItem";
            this.operacjeToolStripMenuItem.Size = new System.Drawing.Size(66, 20);
            this.operacjeToolStripMenuItem.Text = "Operacje";
            // 
            // czyszczenieEkranuToolStripMenuItem
            // 
            this.czyszczenieEkranuToolStripMenuItem.Name = "czyszczenieEkranuToolStripMenuItem";
            this.czyszczenieEkranuToolStripMenuItem.Size = new System.Drawing.Size(175, 22);
            this.czyszczenieEkranuToolStripMenuItem.Text = "Czyszczenie ekranu";
            this.czyszczenieEkranuToolStripMenuItem.Click += new System.EventHandler(this.czyszczenieEkranuToolStripMenuItem_Click);
            // 
            // zapisEkranuToolStripMenuItem
            // 
            this.zapisEkranuToolStripMenuItem.Name = "zapisEkranuToolStripMenuItem";
            this.zapisEkranuToolStripMenuItem.Size = new System.Drawing.Size(175, 22);
            this.zapisEkranuToolStripMenuItem.Text = "Zapis ekranu";
            // 
            // wgranieTlaToolStripMenuItem
            // 
            this.wgranieTlaToolStripMenuItem.Name = "wgranieTlaToolStripMenuItem";
            this.wgranieTlaToolStripMenuItem.Size = new System.Drawing.Size(175, 22);
            this.wgranieTlaToolStripMenuItem.Text = "Wgranie tła";
            this.wgranieTlaToolStripMenuItem.Click += new System.EventHandler(this.wgranieTlaToolStripMenuItem_Click);
            // 
            // zapiszToolStripMenuItem
            // 
            this.zapiszToolStripMenuItem.Name = "zapiszToolStripMenuItem";
            this.zapiszToolStripMenuItem.Size = new System.Drawing.Size(175, 22);
            this.zapiszToolStripMenuItem.Text = "Zapisz";
            this.zapiszToolStripMenuItem.Click += new System.EventHandler(this.zapiszToolStripMenuItem_Click);
            // 
            // obiektyToolStripMenuItem
            // 
            this.obiektyToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.liniaToolStripMenuItem,
            this.elipsaToolStripMenuItem,
            this.koloToolStripMenuItem,
            this.lukToolStripMenuItem,
            this.kwadratToolStripMenuItem,
            this.wielokotToolStripMenuItem,
            this.krzywaBezieraToolStripMenuItem,
            this.wycinekKolaToolStripMenuItem});
            this.obiektyToolStripMenuItem.Name = "obiektyToolStripMenuItem";
            this.obiektyToolStripMenuItem.Size = new System.Drawing.Size(60, 20);
            this.obiektyToolStripMenuItem.Text = "Obiekty";
            // 
            // liniaToolStripMenuItem
            // 
            this.liniaToolStripMenuItem.Name = "liniaToolStripMenuItem";
            this.liniaToolStripMenuItem.Size = new System.Drawing.Size(151, 22);
            this.liniaToolStripMenuItem.Text = "Linia";
            this.liniaToolStripMenuItem.Click += new System.EventHandler(this.liniaToolStripMenuItem_Click);
            // 
            // elipsaToolStripMenuItem
            // 
            this.elipsaToolStripMenuItem.Name = "elipsaToolStripMenuItem";
            this.elipsaToolStripMenuItem.Size = new System.Drawing.Size(151, 22);
            this.elipsaToolStripMenuItem.Text = "Elipsa";
            this.elipsaToolStripMenuItem.Click += new System.EventHandler(this.elipsaToolStripMenuItem_Click);
            // 
            // koloToolStripMenuItem
            // 
            this.koloToolStripMenuItem.Name = "koloToolStripMenuItem";
            this.koloToolStripMenuItem.Size = new System.Drawing.Size(151, 22);
            this.koloToolStripMenuItem.Text = "Kolo";
            this.koloToolStripMenuItem.Click += new System.EventHandler(this.koloToolStripMenuItem_Click);
            // 
            // lukToolStripMenuItem
            // 
            this.lukToolStripMenuItem.Name = "lukToolStripMenuItem";
            this.lukToolStripMenuItem.Size = new System.Drawing.Size(151, 22);
            this.lukToolStripMenuItem.Text = "Luk";
            this.lukToolStripMenuItem.Click += new System.EventHandler(this.lukToolStripMenuItem_Click);
            // 
            // kwadratToolStripMenuItem
            // 
            this.kwadratToolStripMenuItem.Name = "kwadratToolStripMenuItem";
            this.kwadratToolStripMenuItem.Size = new System.Drawing.Size(151, 22);
            this.kwadratToolStripMenuItem.Text = "Kwadrat";
            this.kwadratToolStripMenuItem.Click += new System.EventHandler(this.kwadratToolStripMenuItem_Click);
            // 
            // wielokotToolStripMenuItem
            // 
            this.wielokotToolStripMenuItem.Name = "wielokotToolStripMenuItem";
            this.wielokotToolStripMenuItem.Size = new System.Drawing.Size(151, 22);
            this.wielokotToolStripMenuItem.Text = "Wielokot";
            this.wielokotToolStripMenuItem.Click += new System.EventHandler(this.wielokotToolStripMenuItem_Click);
            // 
            // krzywaBezieraToolStripMenuItem
            // 
            this.krzywaBezieraToolStripMenuItem.Name = "krzywaBezieraToolStripMenuItem";
            this.krzywaBezieraToolStripMenuItem.Size = new System.Drawing.Size(151, 22);
            this.krzywaBezieraToolStripMenuItem.Text = "Krzywa Beziera";
            this.krzywaBezieraToolStripMenuItem.Click += new System.EventHandler(this.krzywaBezieraToolStripMenuItem_Click);
            // 
            // wycinekKolaToolStripMenuItem
            // 
            this.wycinekKolaToolStripMenuItem.Name = "wycinekKolaToolStripMenuItem";
            this.wycinekKolaToolStripMenuItem.Size = new System.Drawing.Size(151, 22);
            this.wycinekKolaToolStripMenuItem.Text = "Wycinek Kola";
            this.wycinekKolaToolStripMenuItem.Click += new System.EventHandler(this.wycinekKolaToolStripMenuItem_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.Window;
            this.pictureBox1.Location = new System.Drawing.Point(12, 58);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(984, 463);
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseDown);
            this.pictureBox1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseMove);
            this.pictureBox1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseUp);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(74, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Grubosc pena";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(259, 34);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(80, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Grubosc Gumki";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // tbSize
            // 
            this.tbSize.Location = new System.Drawing.Point(92, 30);
            this.tbSize.Name = "tbSize";
            this.tbSize.Size = new System.Drawing.Size(100, 20);
            this.tbSize.TabIndex = 5;
            this.tbSize.Text = "20";
            // 
            // Gumka
            // 
            this.Gumka.Location = new System.Drawing.Point(345, 30);
            this.Gumka.Name = "Gumka";
            this.Gumka.Size = new System.Drawing.Size(100, 20);
            this.Gumka.TabIndex = 6;
            this.Gumka.Text = "20";
            // 
            // btGumka
            // 
            this.btGumka.Location = new System.Drawing.Point(471, 30);
            this.btGumka.Name = "btGumka";
            this.btGumka.Size = new System.Drawing.Size(75, 23);
            this.btGumka.TabIndex = 7;
            this.btGumka.Text = "Gumka";
            this.btGumka.UseVisualStyleBackColor = true;
            this.btGumka.Click += new System.EventHandler(this.btGumka_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1});
            this.statusStrip1.Location = new System.Drawing.Point(0, 524);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(1008, 22);
            this.statusStrip1.TabIndex = 8;
            this.statusStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.statusStrip1_ItemClicked);
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(118, 17);
            this.toolStripStatusLabel1.Text = "toolStripStatusLabel1";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1008, 546);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.btGumka);
            this.Controls.Add(this.Gumka);
            this.Controls.Add(this.tbSize);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem wybórNarzędziaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aktualneNarzedzieToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem wybórKoloruToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem operacjeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem czyszczenieEkranuToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem zapisEkranuToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem wgranieTlaToolStripMenuItem;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ToolStripMenuItem obiektyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem liniaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem elipsaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kwadratToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem wielokotToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem krzywaBezieraToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem koloToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lukToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem wycinekKolaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem czerwonyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem niebieskiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem czarnyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem zielonyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fioletowyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gruboscToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem zwiekszToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem zmniejszToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem6;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem7;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbSize;
        private System.Windows.Forms.TextBox Gumka;
        private System.Windows.Forms.Button btGumka;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.ToolStripMenuItem zapiszToolStripMenuItem;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
    }
}

