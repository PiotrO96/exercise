﻿namespace ImageEditor
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.ZmianaRozmiaru = new System.Windows.Forms.Button();
            this.HistogramEqualization = new System.Windows.Forms.Button();
            this.HistogramShift = new System.Windows.Forms.Button();
            this.Obrot = new System.Windows.Forms.Button();
            this.DodajiSubstrakcja = new System.Windows.Forms.Button();
            this.Inwersja = new System.Windows.Forms.Button();
            this.Negatyw = new System.Windows.Forms.Button();
            this.CzernBiel = new System.Windows.Forms.Button();
            this.Szarosc = new System.Windows.Forms.Button();
            this.numericUpDownGamma = new System.Windows.Forms.NumericUpDown();
            this.buttonGama = new System.Windows.Forms.Button();
            this.buttonFilter = new System.Windows.Forms.Button();
            this.buttonLoad = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.SzaroscJasniej = new System.Windows.Forms.Button();
            this.SzaroscLuminancja = new System.Windows.Forms.Button();
            this.ObrotPoziomy = new System.Windows.Forms.Button();
            this.ObrotPionowy = new System.Windows.Forms.Button();
            this.EfektKreskowka = new System.Windows.Forms.Button();
            this.EfektOlejowy = new System.Windows.Forms.Button();
            this.EfektDlugopisu = new System.Windows.Forms.Button();
            this.DetekcjaKrawedzi = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.DomainUpDownBrightness = new System.Windows.Forms.NumericUpDown();
            this.TrackBarBrightness = new System.Windows.Forms.TrackBar();
            this.LinearFIlter = new System.Windows.Forms.Button();
            this.KuwaharaFilter = new System.Windows.Forms.Button();
            this.KolorFilterMagneta = new System.Windows.Forms.Button();
            this.KolorFilterZolty = new System.Windows.Forms.Button();
            this.KolorFilterCyan = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.trackBarContrast = new System.Windows.Forms.TrackBar();
            this.DomainUpDownContrast = new System.Windows.Forms.NumericUpDown();
            this.RysHistogram = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownGamma)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DomainUpDownBrightness)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TrackBarBrightness)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarContrast)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DomainUpDownContrast)).BeginInit();
            this.SuspendLayout();
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.label12);
            this.splitContainer1.Panel1.Controls.Add(this.label11);
            this.splitContainer1.Panel1.Controls.Add(this.label10);
            this.splitContainer1.Panel1.Controls.Add(this.label9);
            this.splitContainer1.Panel1.Controls.Add(this.label8);
            this.splitContainer1.Panel1.Controls.Add(this.label7);
            this.splitContainer1.Panel1.Controls.Add(this.label6);
            this.splitContainer1.Panel1.Controls.Add(this.label5);
            this.splitContainer1.Panel1.Controls.Add(this.label4);
            this.splitContainer1.Panel1.Controls.Add(this.label3);
            this.splitContainer1.Panel1.Controls.Add(this.RysHistogram);
            this.splitContainer1.Panel1.Controls.Add(this.DomainUpDownContrast);
            this.splitContainer1.Panel1.Controls.Add(this.trackBarContrast);
            this.splitContainer1.Panel1.Controls.Add(this.label2);
            this.splitContainer1.Panel1.Controls.Add(this.KolorFilterCyan);
            this.splitContainer1.Panel1.Controls.Add(this.KolorFilterZolty);
            this.splitContainer1.Panel1.Controls.Add(this.KolorFilterMagneta);
            this.splitContainer1.Panel1.Controls.Add(this.KuwaharaFilter);
            this.splitContainer1.Panel1.Controls.Add(this.LinearFIlter);
            this.splitContainer1.Panel1.Controls.Add(this.TrackBarBrightness);
            this.splitContainer1.Panel1.Controls.Add(this.DomainUpDownBrightness);
            this.splitContainer1.Panel1.Controls.Add(this.label1);
            this.splitContainer1.Panel1.Controls.Add(this.DetekcjaKrawedzi);
            this.splitContainer1.Panel1.Controls.Add(this.EfektDlugopisu);
            this.splitContainer1.Panel1.Controls.Add(this.EfektOlejowy);
            this.splitContainer1.Panel1.Controls.Add(this.EfektKreskowka);
            this.splitContainer1.Panel1.Controls.Add(this.ObrotPionowy);
            this.splitContainer1.Panel1.Controls.Add(this.ObrotPoziomy);
            this.splitContainer1.Panel1.Controls.Add(this.SzaroscLuminancja);
            this.splitContainer1.Panel1.Controls.Add(this.SzaroscJasniej);
            this.splitContainer1.Panel1.Controls.Add(this.ZmianaRozmiaru);
            this.splitContainer1.Panel1.Controls.Add(this.HistogramEqualization);
            this.splitContainer1.Panel1.Controls.Add(this.HistogramShift);
            this.splitContainer1.Panel1.Controls.Add(this.Obrot);
            this.splitContainer1.Panel1.Controls.Add(this.DodajiSubstrakcja);
            this.splitContainer1.Panel1.Controls.Add(this.Inwersja);
            this.splitContainer1.Panel1.Controls.Add(this.Negatyw);
            this.splitContainer1.Panel1.Controls.Add(this.CzernBiel);
            this.splitContainer1.Panel1.Controls.Add(this.Szarosc);
            this.splitContainer1.Panel1.Controls.Add(this.numericUpDownGamma);
            this.splitContainer1.Panel1.Controls.Add(this.buttonGama);
            this.splitContainer1.Panel1.Controls.Add(this.buttonFilter);
            this.splitContainer1.Panel1.Controls.Add(this.buttonLoad);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.pictureBox1);
            this.splitContainer1.Size = new System.Drawing.Size(1418, 836);
            this.splitContainer1.SplitterDistance = 312;
            this.splitContainer1.TabIndex = 0;
            // 
            // ZmianaRozmiaru
            // 
            this.ZmianaRozmiaru.Location = new System.Drawing.Point(6, 546);
            this.ZmianaRozmiaru.Name = "ZmianaRozmiaru";
            this.ZmianaRozmiaru.Size = new System.Drawing.Size(93, 23);
            this.ZmianaRozmiaru.TabIndex = 15;
            this.ZmianaRozmiaru.Text = "ZmianaRozmiaru";
            this.ZmianaRozmiaru.UseVisualStyleBackColor = true;
            this.ZmianaRozmiaru.Click += new System.EventHandler(this.ZmianaRozmiaru_Click);
            // 
            // HistogramEqualization
            // 
            this.HistogramEqualization.Location = new System.Drawing.Point(6, 680);
            this.HistogramEqualization.Name = "HistogramEqualization";
            this.HistogramEqualization.Size = new System.Drawing.Size(75, 23);
            this.HistogramEqualization.TabIndex = 14;
            this.HistogramEqualization.Text = "HistogramEqualization";
            this.HistogramEqualization.UseVisualStyleBackColor = true;
            this.HistogramEqualization.Click += new System.EventHandler(this.HistogramEqualization_Click);
            // 
            // HistogramShift
            // 
            this.HistogramShift.Location = new System.Drawing.Point(6, 652);
            this.HistogramShift.Name = "HistogramShift";
            this.HistogramShift.Size = new System.Drawing.Size(75, 23);
            this.HistogramShift.TabIndex = 13;
            this.HistogramShift.Text = "HistogramShifting";
            this.HistogramShift.UseVisualStyleBackColor = true;
            this.HistogramShift.Click += new System.EventHandler(this.HistogramShift_Click);
            // 
            // Obrot
            // 
            this.Obrot.Location = new System.Drawing.Point(4, 440);
            this.Obrot.Name = "Obrot";
            this.Obrot.Size = new System.Drawing.Size(75, 23);
            this.Obrot.TabIndex = 10;
            this.Obrot.Text = "Obrot";
            this.Obrot.UseVisualStyleBackColor = true;
            this.Obrot.Click += new System.EventHandler(this.Obrot_Click);
            // 
            // DodajiSubstrakcja
            // 
            this.DodajiSubstrakcja.Location = new System.Drawing.Point(4, 391);
            this.DodajiSubstrakcja.Name = "DodajiSubstrakcja";
            this.DodajiSubstrakcja.Size = new System.Drawing.Size(75, 23);
            this.DodajiSubstrakcja.TabIndex = 9;
            this.DodajiSubstrakcja.Text = "DodajiSubstrakcja";
            this.DodajiSubstrakcja.UseVisualStyleBackColor = true;
            this.DodajiSubstrakcja.Click += new System.EventHandler(this.DodajiSubstrakcja_Click);
            // 
            // Inwersja
            // 
            this.Inwersja.Location = new System.Drawing.Point(4, 344);
            this.Inwersja.Name = "Inwersja";
            this.Inwersja.Size = new System.Drawing.Size(75, 23);
            this.Inwersja.TabIndex = 8;
            this.Inwersja.Text = "Inwersja";
            this.Inwersja.UseVisualStyleBackColor = true;
            this.Inwersja.Click += new System.EventHandler(this.Inwersja_Click);
            // 
            // Negatyw
            // 
            this.Negatyw.Location = new System.Drawing.Point(4, 315);
            this.Negatyw.Name = "Negatyw";
            this.Negatyw.Size = new System.Drawing.Size(75, 23);
            this.Negatyw.TabIndex = 7;
            this.Negatyw.Text = "Negatyw";
            this.Negatyw.UseVisualStyleBackColor = true;
            this.Negatyw.Click += new System.EventHandler(this.Negatyw_Click);
            // 
            // CzernBiel
            // 
            this.CzernBiel.Location = new System.Drawing.Point(0, 273);
            this.CzernBiel.Name = "CzernBiel";
            this.CzernBiel.Size = new System.Drawing.Size(75, 23);
            this.CzernBiel.TabIndex = 6;
            this.CzernBiel.Text = "CzernBiel";
            this.CzernBiel.UseVisualStyleBackColor = true;
            this.CzernBiel.Click += new System.EventHandler(this.CzernBiel_Click);
            // 
            // Szarosc
            // 
            this.Szarosc.Location = new System.Drawing.Point(0, 164);
            this.Szarosc.Name = "Szarosc";
            this.Szarosc.Size = new System.Drawing.Size(75, 23);
            this.Szarosc.TabIndex = 5;
            this.Szarosc.Text = "SzaroscSrednia";
            this.Szarosc.UseVisualStyleBackColor = true;
            this.Szarosc.Click += new System.EventHandler(this.Szarosc_Click);
            // 
            // numericUpDownGamma
            // 
            this.numericUpDownGamma.DecimalPlaces = 1;
            this.numericUpDownGamma.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.numericUpDownGamma.Location = new System.Drawing.Point(212, 182);
            this.numericUpDownGamma.Name = "numericUpDownGamma";
            this.numericUpDownGamma.Size = new System.Drawing.Size(88, 20);
            this.numericUpDownGamma.TabIndex = 3;
            this.numericUpDownGamma.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // buttonGama
            // 
            this.buttonGama.Location = new System.Drawing.Point(225, 138);
            this.buttonGama.Name = "buttonGama";
            this.buttonGama.Size = new System.Drawing.Size(75, 23);
            this.buttonGama.TabIndex = 2;
            this.buttonGama.Text = "Gama";
            this.buttonGama.UseVisualStyleBackColor = true;
            this.buttonGama.Click += new System.EventHandler(this.buttonGama_Click);
            // 
            // buttonFilter
            // 
            this.buttonFilter.Location = new System.Drawing.Point(0, 64);
            this.buttonFilter.Name = "buttonFilter";
            this.buttonFilter.Size = new System.Drawing.Size(75, 23);
            this.buttonFilter.TabIndex = 1;
            this.buttonFilter.Text = "Filter";
            this.buttonFilter.UseVisualStyleBackColor = true;
            this.buttonFilter.Click += new System.EventHandler(this.buttonFilter_Click);
            // 
            // buttonLoad
            // 
            this.buttonLoad.Location = new System.Drawing.Point(4, 12);
            this.buttonLoad.Name = "buttonLoad";
            this.buttonLoad.Size = new System.Drawing.Size(75, 23);
            this.buttonLoad.TabIndex = 0;
            this.buttonLoad.Text = "Load";
            this.buttonLoad.UseVisualStyleBackColor = true;
            this.buttonLoad.Click += new System.EventHandler(this.button1_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1102, 836);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // SzaroscJasniej
            // 
            this.SzaroscJasniej.Location = new System.Drawing.Point(3, 193);
            this.SzaroscJasniej.Name = "SzaroscJasniej";
            this.SzaroscJasniej.Size = new System.Drawing.Size(75, 23);
            this.SzaroscJasniej.TabIndex = 18;
            this.SzaroscJasniej.Text = "SzaroscJasniejsza";
            this.SzaroscJasniej.UseVisualStyleBackColor = true;
            this.SzaroscJasniej.Click += new System.EventHandler(this.SzaroscJasniej_Click);
            // 
            // SzaroscLuminancja
            // 
            this.SzaroscLuminancja.Location = new System.Drawing.Point(0, 222);
            this.SzaroscLuminancja.Name = "SzaroscLuminancja";
            this.SzaroscLuminancja.Size = new System.Drawing.Size(75, 23);
            this.SzaroscLuminancja.TabIndex = 19;
            this.SzaroscLuminancja.Text = "SzaroscLuminancja";
            this.SzaroscLuminancja.UseVisualStyleBackColor = true;
            this.SzaroscLuminancja.Click += new System.EventHandler(this.SzaroscLuminancja_Click);
            // 
            // ObrotPoziomy
            // 
            this.ObrotPoziomy.Location = new System.Drawing.Point(4, 469);
            this.ObrotPoziomy.Name = "ObrotPoziomy";
            this.ObrotPoziomy.Size = new System.Drawing.Size(75, 23);
            this.ObrotPoziomy.TabIndex = 20;
            this.ObrotPoziomy.Text = "ObrotPoziomy";
            this.ObrotPoziomy.UseVisualStyleBackColor = true;
            this.ObrotPoziomy.Click += new System.EventHandler(this.ObrotPoziomy_Click);
            // 
            // ObrotPionowy
            // 
            this.ObrotPionowy.Location = new System.Drawing.Point(3, 498);
            this.ObrotPionowy.Name = "ObrotPionowy";
            this.ObrotPionowy.Size = new System.Drawing.Size(75, 23);
            this.ObrotPionowy.TabIndex = 21;
            this.ObrotPionowy.Text = "ObrotPionowy";
            this.ObrotPionowy.UseVisualStyleBackColor = true;
            this.ObrotPionowy.Click += new System.EventHandler(this.ObrotPionowy_Click);
            // 
            // EfektKreskowka
            // 
            this.EfektKreskowka.Location = new System.Drawing.Point(4, 722);
            this.EfektKreskowka.Name = "EfektKreskowka";
            this.EfektKreskowka.Size = new System.Drawing.Size(117, 23);
            this.EfektKreskowka.TabIndex = 22;
            this.EfektKreskowka.Text = "Efekt Kreskowka";
            this.EfektKreskowka.UseVisualStyleBackColor = true;
            this.EfektKreskowka.Click += new System.EventHandler(this.EfektKreskowka_Click);
            // 
            // EfektOlejowy
            // 
            this.EfektOlejowy.Location = new System.Drawing.Point(4, 751);
            this.EfektOlejowy.Name = "EfektOlejowy";
            this.EfektOlejowy.Size = new System.Drawing.Size(118, 23);
            this.EfektOlejowy.TabIndex = 23;
            this.EfektOlejowy.Text = "Efekt Olejowy";
            this.EfektOlejowy.UseVisualStyleBackColor = true;
            this.EfektOlejowy.Click += new System.EventHandler(this.EfektOlejowy_Click);
            // 
            // EfektDlugopisu
            // 
            this.EfektDlugopisu.Location = new System.Drawing.Point(4, 780);
            this.EfektDlugopisu.Name = "EfektDlugopisu";
            this.EfektDlugopisu.Size = new System.Drawing.Size(117, 23);
            this.EfektDlugopisu.TabIndex = 24;
            this.EfektDlugopisu.Text = "Efekt Dlugopisu";
            this.EfektDlugopisu.UseVisualStyleBackColor = true;
            this.EfektDlugopisu.Click += new System.EventHandler(this.EfektDlugopisu_Click);
            // 
            // DetekcjaKrawedzi
            // 
            this.DetekcjaKrawedzi.Location = new System.Drawing.Point(0, 575);
            this.DetekcjaKrawedzi.Name = "DetekcjaKrawedzi";
            this.DetekcjaKrawedzi.Size = new System.Drawing.Size(118, 23);
            this.DetekcjaKrawedzi.TabIndex = 25;
            this.DetekcjaKrawedzi.Text = "DetekcjaKrawedzi";
            this.DetekcjaKrawedzi.UseVisualStyleBackColor = true;
            this.DetekcjaKrawedzi.Click += new System.EventHandler(this.DetekcjaKrawedzi_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(232, 320);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(46, 13);
            this.label1.TabIndex = 28;
            this.label1.Text = "Jasnosc";
            // 
            // DomainUpDownBrightness
            // 
            this.DomainUpDownBrightness.DecimalPlaces = 1;
            this.DomainUpDownBrightness.Location = new System.Drawing.Point(212, 408);
            this.DomainUpDownBrightness.Name = "DomainUpDownBrightness";
            this.DomainUpDownBrightness.Size = new System.Drawing.Size(88, 20);
            this.DomainUpDownBrightness.TabIndex = 29;
            // 
            // TrackBarBrightness
            // 
            this.TrackBarBrightness.Location = new System.Drawing.Point(142, 357);
            this.TrackBarBrightness.Name = "TrackBarBrightness";
            this.TrackBarBrightness.Size = new System.Drawing.Size(158, 45);
            this.TrackBarBrightness.TabIndex = 12;
            this.TrackBarBrightness.Scroll += new System.EventHandler(this.TrackBarBrightness_Scroll);
            // 
            // LinearFIlter
            // 
            this.LinearFIlter.Location = new System.Drawing.Point(0, 93);
            this.LinearFIlter.Name = "LinearFIlter";
            this.LinearFIlter.Size = new System.Drawing.Size(75, 23);
            this.LinearFIlter.TabIndex = 30;
            this.LinearFIlter.Text = "Filter drugi";
            this.LinearFIlter.UseVisualStyleBackColor = true;
            this.LinearFIlter.Click += new System.EventHandler(this.LinearFIlter_Click);
            // 
            // KuwaharaFilter
            // 
            this.KuwaharaFilter.Location = new System.Drawing.Point(0, 122);
            this.KuwaharaFilter.Name = "KuwaharaFilter";
            this.KuwaharaFilter.Size = new System.Drawing.Size(75, 23);
            this.KuwaharaFilter.TabIndex = 31;
            this.KuwaharaFilter.Text = "Filter trzeci";
            this.KuwaharaFilter.UseVisualStyleBackColor = true;
            this.KuwaharaFilter.Click += new System.EventHandler(this.KuwaharaFilter_Click);
            // 
            // KolorFilterMagneta
            // 
            this.KolorFilterMagneta.Location = new System.Drawing.Point(92, 64);
            this.KolorFilterMagneta.Name = "KolorFilterMagneta";
            this.KolorFilterMagneta.Size = new System.Drawing.Size(75, 23);
            this.KolorFilterMagneta.TabIndex = 32;
            this.KolorFilterMagneta.Text = "Magneta";
            this.KolorFilterMagneta.UseVisualStyleBackColor = true;
            this.KolorFilterMagneta.Click += new System.EventHandler(this.KolorFilterMagneta_Click);
            // 
            // KolorFilterZolty
            // 
            this.KolorFilterZolty.Location = new System.Drawing.Point(92, 93);
            this.KolorFilterZolty.Name = "KolorFilterZolty";
            this.KolorFilterZolty.Size = new System.Drawing.Size(75, 23);
            this.KolorFilterZolty.TabIndex = 33;
            this.KolorFilterZolty.Text = "Zolty";
            this.KolorFilterZolty.UseVisualStyleBackColor = true;
            this.KolorFilterZolty.Click += new System.EventHandler(this.KolorFilterZolty_Click);
            // 
            // KolorFilterCyan
            // 
            this.KolorFilterCyan.Location = new System.Drawing.Point(92, 122);
            this.KolorFilterCyan.Name = "KolorFilterCyan";
            this.KolorFilterCyan.Size = new System.Drawing.Size(75, 23);
            this.KolorFilterCyan.TabIndex = 34;
            this.KolorFilterCyan.Text = "Cyan";
            this.KolorFilterCyan.UseVisualStyleBackColor = true;
            this.KolorFilterCyan.Click += new System.EventHandler(this.KolorFilterCyan_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(98, 48);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(69, 13);
            this.label2.TabIndex = 35;
            this.label2.Text = "Filtry Kolorow";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // trackBarContrast
            // 
            this.trackBarContrast.Location = new System.Drawing.Point(142, 238);
            this.trackBarContrast.Name = "trackBarContrast";
            this.trackBarContrast.Size = new System.Drawing.Size(158, 45);
            this.trackBarContrast.SmallChange = 5;
            this.trackBarContrast.TabIndex = 12;
            this.trackBarContrast.Scroll += new System.EventHandler(this.trackBarContrast_Scroll);
            // 
            // DomainUpDownContrast
            // 
            this.DomainUpDownContrast.DecimalPlaces = 1;
            this.DomainUpDownContrast.Location = new System.Drawing.Point(212, 273);
            this.DomainUpDownContrast.Name = "DomainUpDownContrast";
            this.DomainUpDownContrast.Size = new System.Drawing.Size(88, 20);
            this.DomainUpDownContrast.TabIndex = 36;
            // 
            // RysHistogram
            // 
            this.RysHistogram.Location = new System.Drawing.Point(3, 623);
            this.RysHistogram.Name = "RysHistogram";
            this.RysHistogram.Size = new System.Drawing.Size(102, 23);
            this.RysHistogram.TabIndex = 37;
            this.RysHistogram.Text = "Rysuj Histogram";
            this.RysHistogram.UseVisualStyleBackColor = true;
            this.RysHistogram.Click += new System.EventHandler(this.RysHistogram_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(3, 48);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(28, 13);
            this.label3.TabIndex = 38;
            this.label3.Text = "Filtry";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(1, 148);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(45, 13);
            this.label4.TabIndex = 39;
            this.label4.Text = "Szarosc";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(3, 257);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(58, 13);
            this.label5.TabIndex = 40;
            this.label5.Text = "Czern i biel";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(3, 299);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(96, 13);
            this.label6.TabIndex = 41;
            this.label6.Text = "Negatyw i Inwersja";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(9, 369);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(63, 13);
            this.label7.TabIndex = 42;
            this.label7.Text = "Substrakcja";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(9, 417);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(44, 13);
            this.label8.TabIndex = 43;
            this.label8.Text = "Rotacja";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(9, 524);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(45, 13);
            this.label9.TabIndex = 44;
            this.label9.Text = "Rozmiar";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(9, 706);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(37, 13);
            this.label10.TabIndex = 45;
            this.label10.Text = "Efekty";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(3, 607);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(54, 13);
            this.label11.TabIndex = 46;
            this.label11.Text = "Histogram";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(232, 222);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(46, 13);
            this.label12.TabIndex = 47;
            this.label12.Text = "Kontrast";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1418, 836);
            this.Controls.Add(this.splitContainer1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownGamma)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DomainUpDownBrightness)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TrackBarBrightness)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarContrast)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DomainUpDownContrast)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button buttonFilter;
        private System.Windows.Forms.Button buttonLoad;
        private System.Windows.Forms.NumericUpDown numericUpDownGamma;
        private System.Windows.Forms.Button buttonGama;
        private System.Windows.Forms.Button ZmianaRozmiaru;
        private System.Windows.Forms.Button HistogramEqualization;
        private System.Windows.Forms.Button HistogramShift;
        private System.Windows.Forms.Button Obrot;
        private System.Windows.Forms.Button DodajiSubstrakcja;
        private System.Windows.Forms.Button Inwersja;
        private System.Windows.Forms.Button Negatyw;
        private System.Windows.Forms.Button CzernBiel;
        private System.Windows.Forms.Button Szarosc;
        private System.Windows.Forms.Button SzaroscLuminancja;
        private System.Windows.Forms.Button SzaroscJasniej;
        private System.Windows.Forms.Button ObrotPionowy;
        private System.Windows.Forms.Button ObrotPoziomy;
        private System.Windows.Forms.Button EfektDlugopisu;
        private System.Windows.Forms.Button EfektOlejowy;
        private System.Windows.Forms.Button EfektKreskowka;
        private System.Windows.Forms.Button DetekcjaKrawedzi;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.NumericUpDown DomainUpDownBrightness;
        private System.Windows.Forms.TrackBar TrackBarBrightness;
        private System.Windows.Forms.Button KuwaharaFilter;
        private System.Windows.Forms.Button LinearFIlter;
        private System.Windows.Forms.Button KolorFilterCyan;
        private System.Windows.Forms.Button KolorFilterZolty;
        private System.Windows.Forms.Button KolorFilterMagneta;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TrackBar trackBarContrast;
        private System.Windows.Forms.NumericUpDown DomainUpDownContrast;
        private System.Windows.Forms.Button RysHistogram;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
    }
}

