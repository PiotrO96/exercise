﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using FIP;
using System.Drawing.Imaging;
using System.Drawing.Drawing2D;

namespace ImageEditor
{
    public partial class Form1 : Form
    {
        FIP.FIP fip;
        Bitmap img;
        float contrast = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            fip = new FIP.FIP(); // many "fip's" in one line...
            img = new Bitmap("lena2.jpg");
            pictureBox1.Image = img; 
            

            //Bitmap median = fip.ImageMedianFilterColor(img, 5); // Median filtration with mask size 5;
           
        }


        private void buttonFilter_Click(object sender, EventArgs e)
        {

            Bitmap median = fip.ImageMedianFilterColor(img, 5); // Median filtration with mask size 5;
            pictureBox1.Image = median;
        }

        private void buttonGama_Click(object sender, EventArgs e)
        {

            Bitmap gamma = fip.GammaCorrection(img, (double)numericUpDownGamma.Value);
            pictureBox1.Image = gamma;

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Szarosc_Click(object sender, EventArgs e)
        {
         

            Color pixel = img.GetPixel(1, 1); // Get single pixel

            Color pixelGS = fip.color2greyscale(pixel); // Single pixel convertion using luminance method

            Bitmap average = fip.ToGreyscaleAVG(img); // Average method of greyscaling
            
            pictureBox1.Image = average;

        }

        private void CzernBiel_Click(object sender, EventArgs e)
        {
            Bitmap bw = fip.ToBlackwhite(img, 128); // Convert to black and white with threshold on 128
            Bitmap bwinv = fip.ToBlackwhiteInverse(img, 80); // Convert to black and white with threshold on 80 and invert over this point
            pictureBox1.Image = bw;
        }

        private void Negatyw_Click(object sender, EventArgs e)
        {

            Bitmap negative = fip.NegativeImageColor(img); // Color image negative
            Bitmap negativeGS = fip.NegativeImageGS(img); // Converts to greyscale and negative transform
            pictureBox1.Image = negative;
        }

        private void Inwersja_Click(object sender, EventArgs e)
        {
            Bitmap inverse = fip.InverseImage(img, 190); // Inverse image on point 190
            pictureBox1.Image = inverse;
        }

        private void DodajiSubstrakcja_Click(object sender, EventArgs e)
        {
            Bitmap a = new Bitmap("a.jpg");
            Bitmap b = new Bitmap("b.jpg");

            Bitmap c = fip.AddImages(a, b); // Add two images
            Bitmap d = fip.SubtractImages(a, b); // subtract two images a - b
        }

        private void Kontrast_Click(object sender, EventArgs e)
        {

        }

        private void numericUpDownKontrast_ValueChanged(object sender, EventArgs e)
        {

        }

        private void HistogramShift_Click(object sender, EventArgs e)
        {
            Bitmap histshift = fip.HistogramShift(img, 50);
        }

        private void HistogramEqualization_Click(object sender, EventArgs e)
        {

            Bitmap histeq = fip.HistoramEqualization(img);
        }

        private void ZmianaRozmiaru_Click(object sender, EventArgs e)
        {
            Bitmap img2 = fip.Resize(img, 50, 50); // Image resize with nearest neighbourhood method
            Bitmap img3 = fip.Resize2(img, 50, 50); // Image resize with bilinear interpolation method
            pictureBox1.Image = img2;
        }

        private void Obrot_Click(object sender, EventArgs e)
        {
            Bitmap rotate = fip.Rotate(img, 30); // Image rotation over 30 degrees
            pictureBox1.Image = rotate;
        }

        private void SzaroscJasniej_Click(object sender, EventArgs e)
        {
            Color pixel = img.GetPixel(1, 1); // Get single pixel

            Color pixelGS = fip.color2greyscale(pixel); // Single pixel convertion using luminance method

            
           Bitmap lightness = fip.ToGreyscaleLightness(img); // Lightness method of greyscaling
                                    
            pictureBox1.Image = lightness;
        }

        private void SzaroscLuminancja_Click(object sender, EventArgs e)
        {
            Color pixel = img.GetPixel(1, 1); // Get single pixel

            Color pixelGS = fip.color2greyscale(pixel); // Single pixel convertion using luminance method

            
            Bitmap luminance = fip.ToGreyscale(img); // Luminance method of greyscaling
            pictureBox1.Image = luminance;
        }

        private void ObrotPoziomy_Click(object sender, EventArgs e)
        {

            if (img != null)
            {
                try
                {
                   
                    img.RotateFlip(RotateFlipType.Rotate180FlipY);
                    pictureBox1.Image = img;
                }
                catch (Exception ex)
                {

                }
            }

        }

        private void ObrotPionowy_Click(object sender, EventArgs e)
        {

            if (img != null)
            {
                try
                {

                    img.RotateFlip(RotateFlipType.Rotate180FlipX);
                    pictureBox1.Image = img;
                }
                catch (Exception ex)
                {

                }
            }
        }

        private void EfektKreskowka_Click(object sender, EventArgs e)
        {
            Bitmap cartoon = fip.Cartoon(img, 7, 10, 40); // Cartoon effect with radius 7, 20 levels of intensities, Sobel edge detecting, inverse on point 40
            pictureBox1.Image = cartoon;
        }

        private void EfektOlejowy_Click(object sender, EventArgs e)
        {
            Bitmap oilpaint = fip.OilPaint(img, 7, 20); // Oil paint effect, radius 7, 20 levels 
            pictureBox1.Image = oilpaint;
        }

        private void EfektDlugopisu_Click(object sender, EventArgs e)
        {
            Bitmap sketch = fip.Sketch(img); // Pen sketch effect with paramaters from article
            pictureBox1.Image = sketch;
        }

        private void DetekcjaKrawedzi_Click(object sender, EventArgs e)
        {
            Bitmap prewitt1 = fip.ImagePrewittFilterColor(img); // Prewitt edge detecting on color image
            pictureBox1.Image = prewitt1;
        }

        private void trackBar2_Scroll(object sender, EventArgs e)
        {
            
        }

        private void TrackBarBrightness_Scroll(object sender, EventArgs e)
        {
            DomainUpDownBrightness.Text = TrackBarBrightness.Value.ToString();
            float value = TrackBarBrightness.Value * 0.01f;
            float[][] colorMatrixElements = {
new float[] {1,0,0,0,0},
new float[] {0,1,0,0,0},
new float[] {0,0,1,0,0},
new float[] {0,0,0,1,0},
new float[] {value,value,value,0,1}
};


            ColorMatrix colorMatrix = new ColorMatrix(colorMatrixElements);

            ImageAttributes imageAttributes = new ImageAttributes();
            imageAttributes.SetColorMatrix(colorMatrix, ColorMatrixFlag.Default, ColorAdjustType.Bitmap);
            //Image _img = Img;
            //PictureBox1.Image
            Graphics _g = default(Graphics);
            Bitmap bm_dest = new Bitmap(Convert.ToInt32(img.Width), Convert.ToInt32(img.Height));
            _g = Graphics.FromImage(bm_dest);
            _g.DrawImage(img, new Rectangle(0, 0, bm_dest.Width + 1, bm_dest.Height + 1), 0, 0, bm_dest.Width + 1, bm_dest.Height + 1, GraphicsUnit.Pixel, imageAttributes);
            pictureBox1.Image = bm_dest;

        }

        private void LinearFIlter_Click(object sender, EventArgs e)
        {
            Bitmap fitered = fip.ImageFilterColor(img, fip.LaplaceF1());
            pictureBox1.Image = fitered;
        }

        private void KuwaharaFilter_Click(object sender, EventArgs e)
        {
            Bitmap kuwahara = fip.ImageKuwaharaFilterColor(img, 3); // Kuwahara filtartion with mask size 3
            pictureBox1.Image = kuwahara;
        }

        private void KolorFilterMagneta_Click(object sender, EventArgs e)
        {
            Bitmap filteredColor = fip.ColorFiltration(img, "Magenta"); // Color filtration with Magenta filter
            pictureBox1.Image = filteredColor;
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void KolorFilterZolty_Click(object sender, EventArgs e)
        {
            Bitmap filteredColor = fip.ColorFiltration(img, "Yellow"); // Color filtration with Magenta filter
            pictureBox1.Image = filteredColor;
        }

        private void KolorFilterCyan_Click(object sender, EventArgs e)
        {
            Bitmap filteredColor = fip.ColorFiltration(img, "Cyan"); // Color filtration with Magenta filter
            pictureBox1.Image = filteredColor;
        }

        private void ZmianaKoloru_Click(object sender, EventArgs e)
        {

        }

        private void FiltracjaKolor_Click(object sender, EventArgs e)
        {

        }

        private void trackBarContrast_Scroll(object sender, EventArgs e)
        {
            DomainUpDownContrast.Text = trackBarContrast.Value.ToString();
            contrast = 0.04f * trackBarContrast.Value;
            //Graphics g2 = Graphics.FromImage(img);
            //ImageAttributes ia = new ImageAttributes();
            ColorMatrix cm = new ColorMatrix(new float[][]{
                new float[]{contrast, 0f,0f,0f,0f},
                new float[]{0f,contrast,0f,0f,0f},
                new float []{0f,0f,contrast,0f,0f },
                new float[]{0f,0f,0f,1f,0f},
                new float []{0.001f,0.001f,0.001f,0f,1f }}

                );
            ImageAttributes ia = new ImageAttributes();
            ia.SetColorMatrix(cm);
            Graphics g2 = default(Graphics);
            Bitmap bm_dest2 = new Bitmap(Convert.ToInt32(img.Width), Convert.ToInt32(img.Height));
            g2 = Graphics.FromImage(bm_dest2);
            g2.DrawImage(img, new Rectangle(0, 0, bm_dest2.Width + 1, bm_dest2.Height + 1), 0, 0, bm_dest2.Width + 1, bm_dest2.Height + 1, GraphicsUnit.Pixel, ia);
            g2.Dispose();
            ia.Dispose();
            pictureBox1.Image = bm_dest2;
        }

        private void RysHistogram_Click(object sender, EventArgs e)
        {
            int[,] rgbHistogram = fip.RGBHistogram(img); // RGB histogram
            pictureBox1.Image = img;
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void DetekcjaKraw_Click(object sender, EventArgs e)
        {

        }
    }
}
