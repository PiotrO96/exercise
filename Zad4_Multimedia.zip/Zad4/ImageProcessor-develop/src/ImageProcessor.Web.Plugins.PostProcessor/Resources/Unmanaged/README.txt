﻿PostProcessor Versions
======================

gifsicle - 1.8.8 http://www.lcdf.org/gifsicle/

pngquant - 2.9.1 https://pngquant.org/

truepng 0.6.2.2  https://css-ig.net/articles/truepng.php
                 http://x128.ho.ua/pngutils.html

jpegtran - 9b    http://jpegclub.org/

mozjpeg  - 3.1 https://github.com/mozilla/mozjpeg 
	           https://mozjpeg.codelove.de/binaries.html
