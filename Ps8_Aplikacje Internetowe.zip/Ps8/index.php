<?php
session_start();

$pictures = array();
if(isset($_SESSION['graphics']))
{
	$pictures = $_SESSION['graphics'];
}

if(!empty($_POST) && $_POST['url']!="" && $_POST['desc']!="")
{
	$user = $_POST('user');
	$pass = $_POST('pass');
	$db = 'strona';
	
	$db = new mysqli ('localhost', $user, $pass, $db) or die ("Error");
	if(strstr($_POST['url'], "http://")==$_POST['url'] || strstr($_POST['url'], "https://")==$_POST['url'])
	{
		$date_clicked = date("h:i:sa d-m-Y");
		$pictures[] = array('url' => $_POST['url'], 'desc' => $_POST['desc'], 'date' => $date_clicked);
	}
	else
		echo "Wpisz dobry adres.";
}
else
	echo "Wypelnij pola!.";
$_SESSION['graphics'] = $pictures;
?>
<!doctype html>
<html lang="pl">
	<head>
		<meta charset="utf-8">

		<title>Galeria z zdjeciami</title>
		<meta name="description" content="Dziwne zdjecia">

		<link rel="stylesheet" href="style.css">

	</head>
	<body>
	<form method="post">
			Login:<input type="text" name="login"><br>
			Haslo:<input type="text" name="pass"><br>
			<input type="submit" value="Wyślij">
		</form>
		<form method="post">
			URL:<input type="text" name="url"><br>
			Podpis:<input type="text" name="desc"><br>
			<input type="submit" value="Wyślij">
		</form>
		
		<?php
		foreach($pictures as $id => $pic)
		{ ?>
			<figure>
				<img src="<?php echo $pic['url'];?>">
				
				<figcaption>
				<?php 
					echo $pic['desc'];
					echo " ";
					echo $pic['date'];
					echo "<button>Usun</button>";
					echo "<button>+</button>";
					echo "<button>-</button>";
				?>
				</figcaption>
			</figure>
		<?php } ?>
	</body>
</html>
