﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using NAudio.Wave;
using System.IO;
using NAudio.Mixer;
using System.Diagnostics;
using NAudio.Wave.SampleProviders;
using NAudio.CoreAudioApi;
using NAudio.Lame;


namespace SoundMixer
{
    public partial class OknoGlowne : Form
    {

        private IWaveIn input;
        private WaveFileWriter fileWriter;
        private string loopBackFileName;
        private string micFileName;
        private string outputFileName;
        private readonly string outputFolder;
        MyRecorder recorder;
        WasapiOut masterOut = new WasapiOut(NAudio.CoreAudioApi.AudioClientShareMode.Shared, 300);// bylo 100 
        public OknoGlowne()
        {
            InitializeComponent();
            outputFolder = Path.Combine(Path.GetTempPath(), "MikserDzwiekow"); // sound mixer
            Directory.CreateDirectory(outputFolder);
            recorder = new MyRecorder();
            timer1.Enabled = true;
        }

        private void RecordBut_Click(object sender, EventArgs e)
        {
            if (input == null)
            {
                input = new WasapiLoopbackCapture();
                input.RecordingStopped += OnRecordingStopped;
            }
            loopBackFileName = string.Format("Muzyka" + "{0:yyy-MM-dd HH-mm-ss}.wav", DateTime.Now);
            fileWriter = new WaveFileWriter(Path.Combine(outputFolder, loopBackFileName), input.WaveFormat);
            recorder.BeginMonitoring(0);
            recorder.MicrophoneLevel = 10;
            micFileName = String.Format("Audio" + "{0:yyy-MM-dd HH-mm-ss}.wav", DateTime.Now);
            recorder.BeginRecording(Path.Combine(outputFolder, micFileName));
            MicVolumeBar.Enabled = true;
            input.StartRecording();
         

        }
        private void StopBut_Click(object sender, EventArgs e)
        {
            if (input != null) { input.StopRecording(); }
            recorder.Stop();
            MicVolumeBar.Enabled = false;
        }

        private void PlayBut_Click(object sender, EventArgs e)
        {
            if (listBoxRecordings.SelectedItem != null)
            {
                Process.Start(Path.Combine(outputFolder, (string)listBoxRecordings.SelectedItem));
            }
        }

        void OnRecordingStopped(object sender, StoppedEventArgs e)
        {
            if (InvokeRequired)
            {
                BeginInvoke(new EventHandler<StoppedEventArgs>(OnRecordingStopped), sender, e);
            }
            else
            {
                if (fileWriter != null)
                {
                    fileWriter.Dispose();
                    fileWriter = null;
                }
                if (e.Exception != null)
                {
                    MessageBox.Show(String.Format("Problem podczas nagrywania {0}", e.Exception.Message));
                }
                combineAllFiles();
                int newItemIndex = listBoxRecordings.Items.Add(outputFileName);
                listBoxRecordings.SelectedIndex = newItemIndex;
              
            }

        }
        
        private void combineAllFiles()
        {
            var background = new WaveFileReader(Path.Combine(outputFolder, loopBackFileName));
            var mic = new WaveFileReader(Path.Combine(outputFolder, micFileName));
            var mixer = new WaveMixerStream32();
            mixer.AutoStop = true;
            var background32 = new WaveChannel32(background);
            background32.PadWithZeroes = false;
            background32.Volume = 0.7f;//0.7f;
            mixer.AddInputStream(background32);

            
            var message32 = new WaveChannel32(mic);
            message32.PadWithZeroes = false;
            message32.Volume = 1.0f;//1.0f;
            mixer.AddInputStream(message32);


            


            outputFileName = String.Format("Nagrany" + "{0:HH-mm-ss}.wav", DateTime.Now);
            WaveFileWriter.CreateWaveFile(Path.Combine(outputFolder, outputFileName), new Wave32To16Stream(mixer));
            
        }
       
        private void OpenBut_Click(object sender, EventArgs e)
        {
            Process.Start(outputFolder);
        }
        private void OknoGlowne_Load(object sender, EventArgs e)
        {

        }

        private void player1_Load(object sender, EventArgs e)
        {

        }

        private void player1_Load_1(object sender, EventArgs e)
        {

        }

        private void OknoGlowne_FormClosing(object sender, FormClosingEventArgs e)
        {


           
        }

        private void MicVolumeBar_Scroll(object sender, EventArgs e)
        {
            recorder.MicrophoneLevel = MicVolumeBar.Value;
        }

        private void MasterVolumeBar_Scroll(object sender, EventArgs e)
        {
            masterOut.Volume = (float)MasterVolumeBar.Value / (float)MasterVolumeBar.Maximum;
        }

        

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void pauseToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void zamknijToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void playToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.RecordBut_Click(sender, e);
        }

        private void stopToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.StopBut_Click(sender, e);
        }

        private void playNagranieToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.PlayBut_Click(sender, e);
        }

        private void odtworzNagranieToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.OpenBut_Click(sender, e);
        }

       
    }
}
