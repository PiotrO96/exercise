﻿namespace SoundMixer
{
    partial class Player
    {
        /// <summary> 
        /// Wymagana zmienna projektanta.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Wyczyść wszystkie używane zasoby.
        /// </summary>
        /// <param name="disposing">prawda, jeżeli zarządzane zasoby powinny zostać zlikwidowane; Fałsz w przeciwnym wypadku.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kod wygenerowany przez Projektanta składników

        /// <summary> 
        /// Metoda wymagana do obsługi projektanta — nie należy modyfikować 
        /// jej zawartości w edytorze kodu.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.Open = new System.Windows.Forms.Button();
            this.Play = new System.Windows.Forms.Button();
            this.Pause = new System.Windows.Forms.Button();
            this.Stop = new System.Windows.Forms.Button();
            this.SongTrackBar = new System.Windows.Forms.TrackBar();
            this.VolumeTrackBar = new System.Windows.Forms.TrackBar();
            this.MuteCheck = new System.Windows.Forms.CheckBox();
            this.SongLabel = new System.Windows.Forms.Label();
            this.Volume = new System.Windows.Forms.Label();
            this.SongPositionLabel = new System.Windows.Forms.Label();
            this.openFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.timer = new System.Windows.Forms.Timer(this.components);
            this.volumeMeter1 = new NAudio.Gui.VolumeMeter();
            this.volumeMeter2 = new NAudio.Gui.VolumeMeter();
            this.EqualizerBut = new System.Windows.Forms.Button();
            this.volumeMeter3 = new NAudio.Gui.VolumeMeter();
            this.label2 = new System.Windows.Forms.Label();
            this.Prawy = new System.Windows.Forms.Button();
            this.Lewy = new System.Windows.Forms.Button();
            this.czyscbut = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.SongTrackBar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.VolumeTrackBar)).BeginInit();
            this.SuspendLayout();
            // 
            // Open
            // 
            this.Open.Location = new System.Drawing.Point(3, 121);
            this.Open.Name = "Open";
            this.Open.Size = new System.Drawing.Size(75, 23);
            this.Open.TabIndex = 0;
            this.Open.Text = "Open";
            this.Open.UseVisualStyleBackColor = true;
            this.Open.Click += new System.EventHandler(this.Open_Click);
            // 
            // Play
            // 
            this.Play.Location = new System.Drawing.Point(84, 121);
            this.Play.Name = "Play";
            this.Play.Size = new System.Drawing.Size(75, 23);
            this.Play.TabIndex = 1;
            this.Play.Text = "Play";
            this.Play.UseVisualStyleBackColor = true;
            this.Play.Click += new System.EventHandler(this.Play_Click);
            // 
            // Pause
            // 
            this.Pause.Location = new System.Drawing.Point(165, 121);
            this.Pause.Name = "Pause";
            this.Pause.Size = new System.Drawing.Size(75, 23);
            this.Pause.TabIndex = 2;
            this.Pause.Text = "Pause";
            this.Pause.UseVisualStyleBackColor = true;
            this.Pause.Click += new System.EventHandler(this.Pause_Click);
            // 
            // Stop
            // 
            this.Stop.Location = new System.Drawing.Point(246, 121);
            this.Stop.Name = "Stop";
            this.Stop.Size = new System.Drawing.Size(75, 23);
            this.Stop.TabIndex = 3;
            this.Stop.Text = "Stop";
            this.Stop.UseVisualStyleBackColor = true;
            this.Stop.Click += new System.EventHandler(this.Stop_Click);
            // 
            // SongTrackBar
            // 
            this.SongTrackBar.Location = new System.Drawing.Point(0, 0);
            this.SongTrackBar.Maximum = 100;
            this.SongTrackBar.Name = "SongTrackBar";
            this.SongTrackBar.Size = new System.Drawing.Size(702, 45);
            this.SongTrackBar.TabIndex = 4;
            this.SongTrackBar.TickStyle = System.Windows.Forms.TickStyle.TopLeft;
            this.SongTrackBar.Scroll += new System.EventHandler(this.SongTrackBar_Scroll);
            // 
            // VolumeTrackBar
            // 
            this.VolumeTrackBar.Location = new System.Drawing.Point(465, 120);
            this.VolumeTrackBar.Name = "VolumeTrackBar";
            this.VolumeTrackBar.Size = new System.Drawing.Size(104, 45);
            this.VolumeTrackBar.TabIndex = 5;
            this.VolumeTrackBar.TickStyle = System.Windows.Forms.TickStyle.Both;
            this.VolumeTrackBar.Scroll += new System.EventHandler(this.VolumeTrackBar_Scroll);
            // 
            // MuteCheck
            // 
            this.MuteCheck.AutoSize = true;
            this.MuteCheck.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.MuteCheck.Location = new System.Drawing.Point(512, 63);
            this.MuteCheck.Name = "MuteCheck";
            this.MuteCheck.Size = new System.Drawing.Size(60, 17);
            this.MuteCheck.TabIndex = 6;
            this.MuteCheck.Text = "Wycisz";
            this.MuteCheck.UseVisualStyleBackColor = true;
            this.MuteCheck.CheckedChanged += new System.EventHandler(this.MuteCheck_CheckedChanged);
            // 
            // SongLabel
            // 
            this.SongLabel.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.SongLabel.Location = new System.Drawing.Point(0, 45);
            this.SongLabel.Name = "SongLabel";
            this.SongLabel.Size = new System.Drawing.Size(234, 13);
            this.SongLabel.TabIndex = 7;
            this.SongLabel.Text = "Utwor";
            // 
            // Volume
            // 
            this.Volume.AutoSize = true;
            this.Volume.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Volume.Location = new System.Drawing.Point(408, 131);
            this.Volume.Name = "Volume";
            this.Volume.Size = new System.Drawing.Size(51, 13);
            this.Volume.TabIndex = 8;
            this.Volume.Text = "Glosnosc";
            this.Volume.Click += new System.EventHandler(this.Volume_Click);
            // 
            // SongPositionLabel
            // 
            this.SongPositionLabel.AutoSize = true;
            this.SongPositionLabel.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.SongPositionLabel.Location = new System.Drawing.Point(512, 45);
            this.SongPositionLabel.Name = "SongPositionLabel";
            this.SongPositionLabel.Size = new System.Drawing.Size(66, 13);
            this.SongPositionLabel.TabIndex = 10;
            this.SongPositionLabel.Text = "00:00/00:00";
            // 
            // openFileDialog
            // 
            this.openFileDialog.FileName = "openFileDialog1";
            // 
            // timer
            // 
            this.timer.Interval = 1000;
            this.timer.Tick += new System.EventHandler(this.timer_Tick);
            // 
            // volumeMeter1
            // 
            this.volumeMeter1.Amplitude = 0F;
            this.volumeMeter1.ForeColor = System.Drawing.Color.Crimson;
            this.volumeMeter1.Location = new System.Drawing.Point(0, 63);
            this.volumeMeter1.MaxDb = 18F;
            this.volumeMeter1.MinDb = -60F;
            this.volumeMeter1.Name = "volumeMeter1";
            this.volumeMeter1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            this.volumeMeter1.Size = new System.Drawing.Size(506, 13);
            this.volumeMeter1.TabIndex = 11;
            this.volumeMeter1.Text = "volumeMeter1";
            // 
            // volumeMeter2
            // 
            this.volumeMeter2.Amplitude = 0F;
            this.volumeMeter2.ForeColor = System.Drawing.Color.Crimson;
            this.volumeMeter2.Location = new System.Drawing.Point(0, 82);
            this.volumeMeter2.MaxDb = 18F;
            this.volumeMeter2.MinDb = -60F;
            this.volumeMeter2.Name = "volumeMeter2";
            this.volumeMeter2.Orientation = System.Windows.Forms.Orientation.Horizontal;
            this.volumeMeter2.Size = new System.Drawing.Size(506, 13);
            this.volumeMeter2.TabIndex = 12;
            this.volumeMeter2.Text = "volumeMeter2";
            this.volumeMeter2.Click += new System.EventHandler(this.volumeMeter2_Click);
            // 
            // EqualizerBut
            // 
            this.EqualizerBut.Location = new System.Drawing.Point(327, 121);
            this.EqualizerBut.Name = "EqualizerBut";
            this.EqualizerBut.Size = new System.Drawing.Size(75, 23);
            this.EqualizerBut.TabIndex = 13;
            this.EqualizerBut.Text = "Equalizer";
            this.EqualizerBut.UseVisualStyleBackColor = true;
            this.EqualizerBut.Click += new System.EventHandler(this.EqualizerBut_Click);
            // 
            // volumeMeter3
            // 
            this.volumeMeter3.Amplitude = 0F;
            this.volumeMeter3.ForeColor = System.Drawing.Color.Crimson;
            this.volumeMeter3.Location = new System.Drawing.Point(0, 101);
            this.volumeMeter3.MaxDb = 18F;
            this.volumeMeter3.MinDb = -60F;
            this.volumeMeter3.Name = "volumeMeter3";
            this.volumeMeter3.Orientation = System.Windows.Forms.Orientation.Horizontal;
            this.volumeMeter3.Size = new System.Drawing.Size(506, 13);
            this.volumeMeter3.TabIndex = 16;
            this.volumeMeter3.Text = "volumeMeter3";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(476, 45);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(30, 13);
            this.label2.TabIndex = 17;
            this.label2.Text = "Czas";
            // 
            // Prawy
            // 
            this.Prawy.Location = new System.Drawing.Point(582, 82);
            this.Prawy.Name = "Prawy";
            this.Prawy.Size = new System.Drawing.Size(104, 23);
            this.Prawy.TabIndex = 18;
            this.Prawy.Text = "Prawy Calkowity";
            this.Prawy.UseVisualStyleBackColor = true;
            this.Prawy.Click += new System.EventHandler(this.Prawy_Click);
            // 
            // Lewy
            // 
            this.Lewy.Location = new System.Drawing.Point(582, 112);
            this.Lewy.Name = "Lewy";
            this.Lewy.Size = new System.Drawing.Size(104, 23);
            this.Lewy.TabIndex = 19;
            this.Lewy.Text = "Lewy Calkowity";
            this.Lewy.UseVisualStyleBackColor = true;
            this.Lewy.Click += new System.EventHandler(this.Lewy_Click);
            // 
            // czyscbut
            // 
            this.czyscbut.Location = new System.Drawing.Point(623, 53);
            this.czyscbut.Name = "czyscbut";
            this.czyscbut.Size = new System.Drawing.Size(63, 23);
            this.czyscbut.TabIndex = 21;
            this.czyscbut.Text = "Czysc";
            this.czyscbut.UseVisualStyleBackColor = true;
            this.czyscbut.Click += new System.EventHandler(this.czyscbut_Click);
            // 
            // Player
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.czyscbut);
            this.Controls.Add(this.Lewy);
            this.Controls.Add(this.Prawy);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.volumeMeter3);
            this.Controls.Add(this.EqualizerBut);
            this.Controls.Add(this.volumeMeter2);
            this.Controls.Add(this.volumeMeter1);
            this.Controls.Add(this.SongPositionLabel);
            this.Controls.Add(this.Volume);
            this.Controls.Add(this.SongLabel);
            this.Controls.Add(this.MuteCheck);
            this.Controls.Add(this.VolumeTrackBar);
            this.Controls.Add(this.SongTrackBar);
            this.Controls.Add(this.Stop);
            this.Controls.Add(this.Pause);
            this.Controls.Add(this.Play);
            this.Controls.Add(this.Open);
            this.Name = "Player";
            this.Size = new System.Drawing.Size(709, 170);
            this.Load += new System.EventHandler(this.Player_Load);
            ((System.ComponentModel.ISupportInitialize)(this.SongTrackBar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.VolumeTrackBar)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Open;
        private System.Windows.Forms.Button Play;
        private System.Windows.Forms.Button Pause;
        private System.Windows.Forms.Button Stop;
        private System.Windows.Forms.TrackBar SongTrackBar;
        private System.Windows.Forms.TrackBar VolumeTrackBar;
        private System.Windows.Forms.CheckBox MuteCheck;
        private System.Windows.Forms.Label SongLabel;
        private System.Windows.Forms.Label Volume;
        private System.Windows.Forms.Label SongPositionLabel;
        private System.Windows.Forms.OpenFileDialog openFileDialog;
        private System.Windows.Forms.Timer timer;
        private NAudio.Gui.VolumeMeter volumeMeter1;
        private NAudio.Gui.VolumeMeter volumeMeter2;
        private System.Windows.Forms.Button EqualizerBut;
        private NAudio.Gui.VolumeMeter volumeMeter3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button Prawy;
        private System.Windows.Forms.Button Lewy;
        private System.Windows.Forms.Button czyscbut;
    }
}
