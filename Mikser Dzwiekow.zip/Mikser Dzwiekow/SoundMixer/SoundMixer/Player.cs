﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using NAudio.Wave;
using NAudio.CoreAudioApi;
using System.IO;
using NAudio.Wave.SampleProviders;

namespace SoundMixer
{
    public partial class Player : UserControl
    {
        WasapiOut wasApiOut;
        AudioFileReader reader;
        bool found = false;
        String fileName;
        EqualizerForm eForm;
        private string command;
        private bool loop;
        public Player()
        {
            InitializeComponent();
            eForm = new EqualizerForm();
        }

        private void Open_Click(object sender, EventArgs e)
        {    
            DialogResult ResultDialog;
            found = false;
            this.openFileDialog.Filter = "Muzyka wav (.wav)|*.wav|Muzyka mp3 (.mp3)|*.mp3";
            // ewentualnie w open file dialog properties dac  MP3|*.mp3 
            //this.openFileDialog.Filter = "Music Formats| " + "*.mp3;*.ram;*.rm;*.wav;*.wma;*.mid|" + "mp3 (*.mp3)|*.mp3|ram (*.ram)|*.ram|rm (*.rm)|*.rm|wav (*.wav)|*.wav|wma (*.wma)|*.wma|mid (*.mid)|*.mid|";
          //  this.openFileDialog.RestoreDirectory = true;
            this.openFileDialog.FileName = "";
            this.openFileDialog.Title = "Wybierz plik muzyczny:";
           // this.openFileDialog.CheckFileExists = true;
            //this.openFileDialog.CheckPathExists = true;
            //this.openFileDialog.Multiselect = true;
            ResultDialog = openFileDialog.ShowDialog();
            if (ResultDialog == DialogResult.OK)
            {
                fileName = openFileDialog.FileName;
                found = true;
               
            }
            if (fileName != null)
            {
              
            }
            else
            {
                MessageBox.Show("No music file selected", "Information");

            }
        }
      

        private void Play_Click(object sender, EventArgs e)
        {
            if (reader != null)
            {
                if (wasApiOut.PlaybackState == PlaybackState.Paused)
                {
                   
                    wasApiOut.Play();
                
                }

            }
            else
            {
                loop = false;
                AudioClientShareMode shareMode = AudioClientShareMode.Shared;
                bool useEventSync = false;
                wasApiOut = new WasapiOut(shareMode, useEventSync, 50);
                wasApiOut.Volume = 1.0f; //((float)VolumeTrackBar.Value / (float)VolumeTrackBar.Maximum);
                reader = new AudioFileReader(fileName);
                reader.Volume = ((float)VolumeTrackBar.Value / (float)VolumeTrackBar.Maximum);
                SongLabel.Text = Path.GetFileName(fileName);
                SongTrackBar.Maximum = (int)reader.TotalTime.TotalSeconds;
                SongTrackBar.Value = 0;
             
                var sampleChannel = new SampleChannel(reader, true);
                var postVolumeMeter = new MeteringSampleProvider(sampleChannel);
                eForm.myEqualizer = eForm.GetEqualizer(postVolumeMeter);
                postVolumeMeter.StreamVolume += OnPostVolumeMeter;
               
                wasApiOut.Init(eForm.myEqualizer); // reader w nawiasie kiedys byl // kiedys tez byl postVolumeMeter
                wasApiOut.Play();
                timer.Start();

            }
        }

        private void OnPostVolumeMeter(object sender, StreamVolumeEventArgs e)
        {
            volumeMeter1.Amplitude = e.MaxSampleValues[0];
            volumeMeter2.Amplitude = e.MaxSampleValues[1];
            volumeMeter3.Amplitude = e.MaxSampleValues[0];
        }
        private void Pause_Click(object sender, EventArgs e)
        {

            wasApiOut.Pause();

          
        }

        private void Stop_Click(object sender, EventArgs e)
        {
            wasApiOut.Stop();
          
            
           
            reader.CurrentTime = TimeSpan.FromSeconds(0);
           
           
        }

        private void Volume_Click(object sender, EventArgs e)
        {

        }

        private void VolumeTrackBar_Scroll(object sender, EventArgs e)
        {
            if (reader != null)
            {
                reader.Volume = ((float)VolumeTrackBar.Value / (float)VolumeTrackBar.Maximum);
                if (MuteCheck.Checked)
                {
                    MuteCheck.Checked = false;
                }

            }
        }

        private void timer_Tick(object sender, EventArgs e)
        {
            SongTrackBar.Value = (int)reader.CurrentTime.TotalSeconds;
            SongPositionLabel.Text = reader.CurrentTime.ToString(@"mm\:ss") + "/" + reader.TotalTime.ToString(@"mm\:ss");
        }

        private void SongTrackBar_Scroll(object sender, EventArgs e)
        {
            if (reader != null)
            {
                reader.CurrentTime = TimeSpan.FromSeconds(SongTrackBar.Value);
            }
        }

        private void MuteCheck_CheckedChanged(object sender, EventArgs e)
        {
            if (MuteCheck.Checked)
            {
                reader.Volume = 0.0f;
            }
            else
            {
                reader.Volume = ((float)VolumeTrackBar.Value / (float)VolumeTrackBar.Maximum);
            }
        }
       

        private void Player_Load(object sender, EventArgs e)
        {
            
        }
        protected override void OnCreateControl()
        {
            base.OnCreateControl();
            this.ParentForm.FormClosing += new FormClosingEventHandler(ParentForm_FormClosing);

        }
        void ParentForm_FormClosing(object sender, FormClosingEventArgs e)
        {

             timer.Stop();
            if (wasApiOut != null)
            {
                wasApiOut.Stop();
                wasApiOut.Dispose();
                wasApiOut = null;
            }
            if (reader != null)
            {
                 
                reader.Close();
                reader.Dispose();
                reader = null;

            }

          
        }

        private void EqualizerBut_Click(object sender, EventArgs e)
        {
            eForm.Show();
        }

      

        private void LeftRightTrackBar1_Scroll(object sender, EventArgs e)
        {

        }

        private void volumeMeter2_Click(object sender, EventArgs e)
        {

        }

        private void Prawy_Click(object sender, EventArgs e)
        {
            using (var reader = new AudioFileReader(fileName))
            {
                var mono = new StereoToMonoSampleProvider(reader);
                mono.LeftVolume = 0.0f; // discard the left channel
                mono.RightVolume = 1.0f; // keep the right channel

            }
                
        }

        private void Lewy_Click(object sender, EventArgs e)
        {
            using (var reader = new AudioFileReader(fileName))
            {
                var mono = new StereoToMonoSampleProvider(reader);
                mono.LeftVolume = 1.0f; // discard the left channel
                mono.RightVolume = 0.0f; // keep the right channel

            }
        }

      

        private void czyscbut_Click(object sender, EventArgs e)
        {
            timer.Stop();
            if (wasApiOut != null)
            {
                wasApiOut.Stop();
                wasApiOut.Dispose();
                wasApiOut = null;
            }
            if (reader != null)
            {

                reader.Close();
                reader.Dispose();
                reader = null;

            }
        }
    }
}
