﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using NAudio.Wave.SampleProviders;

namespace SoundMixer
{
    public partial class EqualizerForm : Form
    {

        private readonly MyEqualizerBands[] bands;
        public MyEqualizer myEqualizer;

        public EqualizerForm()
        {
            InitializeComponent();
            bands = new MyEqualizerBands[]
                {
                    new MyEqualizerBands{ Bandwidth = 0.8f, Frequency = 100, Gain = 0},
                    new MyEqualizerBands{ Bandwidth = 0.8f, Frequency = 200, Gain = 0},
                    new MyEqualizerBands{ Bandwidth = 0.8f, Frequency = 400, Gain = 0},
                    new MyEqualizerBands{ Bandwidth = 0.8f, Frequency = 800, Gain = 0},
                    new MyEqualizerBands{ Bandwidth = 0.8f, Frequency = 1200, Gain = 0},
                    new MyEqualizerBands{ Bandwidth = 0.8f, Frequency = 2400, Gain = 0},
                    new MyEqualizerBands{ Bandwidth = 0.8f, Frequency = 4800, Gain = 0},
                    new MyEqualizerBands{ Bandwidth = 0.8f, Frequency = 9600, Gain = 0},

                };
        }
        public MyEqualizer GetEqualizer(MeteringSampleProvider msp)
        {
            return new MyEqualizer(msp, this.bands);
        }

        
        private void EqualizerForm_Load(object sender, EventArgs e)
        {

        }

        private void trackBar5_Scroll(object sender, EventArgs e)
        {
            
        }
        private void trackBar_ValueChanged(object sender, EventArgs e)
        {
            var trackbar = sender as TrackBar;
            if (myEqualizer != null && trackbar != null)
            {
                int filterIndex = Int32.Parse((string)trackbar.Tag);
                bands[filterIndex].Gain = trackbar.Value;
                if (myEqualizer != null)
                {
                    myEqualizer.Update();
                }

            }
        }
    }
}
