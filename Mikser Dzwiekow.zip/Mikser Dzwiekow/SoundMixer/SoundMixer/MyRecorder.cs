﻿using NAudio.Mixer;
using NAudio.Wave;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SoundMixer
{
    class MyRecorder
    {
        WaveIn waveIn;
        readonly Aggregator aggregator;
        UnsignedMixerControl VolumeControl;
        double desiredVolume = 100;
        RecordingState recordingState;
        WaveFileWriter writer;
        WaveFormat recordingWaveFormat;

        public MyRecorder()
        {
            aggregator = new Aggregator();
            recordingWaveFormat = new WaveFormat(48000, 1);// 44100 ,1 

        }
        public WaveFormat RecordingFormat
        {
            get
            {
                return recordingWaveFormat;
            }
            set
            {
                recordingWaveFormat = value;
                aggregator.NotificationCount = value.SampleRate / 10;
            }
        }
        public void BeginMonitoring(int recordingDevice)
        {
            if (recordingState != RecordingState.Stopped)
            {
                throw new InvalidOperationException("Nie moze nagrywac podczas tego stanu: " + recordingState.ToString());
            }
                waveIn = new WaveIn();
                waveIn.DeviceNumber = recordingDevice;
                waveIn.DataAvailable += onDataAvailable;
                waveIn.RecordingStopped += OnRecordingStopped;
                waveIn.WaveFormat = recordingWaveFormat;
                waveIn.StartRecording();
                TryGetVolumeControl();
                recordingState = RecordingState.Monitoring;
    
        }
        void OnRecordingStopped(object sender, StoppedEventArgs e)
        {
            recordingState = RecordingState.Stopped;
            writer.Dispose();
        }
        public void BeginRecording(string waveFileName)
        {
            if(recordingState != RecordingState.Monitoring)
            {
                throw new InvalidOperationException("Nie moze nagrywac podczas tego stanu: " + recordingState.ToString());
            }
            writer = new WaveFileWriter(waveFileName, recordingWaveFormat);
            recordingState = RecordingState.Recording;
        }
        public void Stop()
        {
            if (recordingState == RecordingState.Recording)
            {
                recordingState = RecordingState.RequestedStop;
                waveIn.StopRecording();
            }

        }
        private void TryGetVolumeControl()
        {
            int waveInDeviceNumber = waveIn.DeviceNumber;
            var mixerLine = waveIn.GetMixerLine();
            foreach (var control in mixerLine.Controls)
            {
                if (control.ControlType == MixerControlType.Volume)
                {
                    this.VolumeControl = control as UnsignedMixerControl;
                    MicrophoneLevel = desiredVolume;
                    break;
                }

            }
        }
        public double MicrophoneLevel
        {
            get
            {
                return desiredVolume;
            }
            set
            {
                desiredVolume = value;
                if (VolumeControl != null)
                {
                    VolumeControl.Percent = value;
                }
            }

        }
        public Aggregator Aggregator
        {
            get
            {
                return aggregator;
            }
        }
        public RecordingState RecordingState
        {
            get
            {
                return recordingState;
            }
        }
        public TimeSpan RecordedTime
        {
            get
            {
                if (writer == null)
                {
                    return TimeSpan.Zero;
                }
                return TimeSpan.FromSeconds((double)writer.Length / writer.WaveFormat.AverageBytesPerSecond);
            }

        }
        void onDataAvailable(object sender, WaveInEventArgs e)
        {
            byte[] buffer = e.Buffer;
            int bytesRecorded = e.BytesRecorded;
            WriteToFile(buffer, bytesRecorded);
            for (int index = 0; index < e.BytesRecorded; index +=2)
            {
                short sample = (short)((buffer[index + 1] << 8) | buffer[index + 0]);
                float sample32 = sample / 32768f;
                aggregator.Add(sample32);

            }
        }
        private void WriteToFile(byte[] buffer, int bytesRecorded)
        {
          //  long maxFileLength = this.recordingWaveFormat.AverageBytesPerSecond * 60;
            if (recordingState == RecordingState.Recording)
            {
                writer.Write(buffer, 0, bytesRecorded);

            }

        }
        

    }
}
