﻿namespace SoundMixer
{
    partial class OknoGlowne
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.RecordBut = new System.Windows.Forms.Button();
            this.StopBut = new System.Windows.Forms.Button();
            this.PlayBut = new System.Windows.Forms.Button();
            this.OpenBut = new System.Windows.Forms.Button();
            this.listBoxRecordings = new System.Windows.Forms.ListBox();
            this.MicVolumeBar = new System.Windows.Forms.TrackBar();
            this.MasterVolumeBar = new System.Windows.Forms.TrackBar();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.menuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.zamknijToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nagrywanieToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.playToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.stopToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.playNagranieToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.odtworzNagranieToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.player3 = new SoundMixer.Player();
            this.player2 = new SoundMixer.Player();
            this.player1 = new SoundMixer.Player();
            ((System.ComponentModel.ISupportInitialize)(this.MicVolumeBar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.MasterVolumeBar)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // RecordBut
            // 
            this.RecordBut.Location = new System.Drawing.Point(12, 161);
            this.RecordBut.Name = "RecordBut";
            this.RecordBut.Size = new System.Drawing.Size(75, 23);
            this.RecordBut.TabIndex = 3;
            this.RecordBut.Text = "Nagrywaj";
            this.RecordBut.UseVisualStyleBackColor = true;
            this.RecordBut.Click += new System.EventHandler(this.RecordBut_Click);
            // 
            // StopBut
            // 
            this.StopBut.Location = new System.Drawing.Point(93, 161);
            this.StopBut.Name = "StopBut";
            this.StopBut.Size = new System.Drawing.Size(75, 23);
            this.StopBut.TabIndex = 4;
            this.StopBut.Text = "Stop";
            this.StopBut.UseVisualStyleBackColor = true;
            this.StopBut.Click += new System.EventHandler(this.StopBut_Click);
            // 
            // PlayBut
            // 
            this.PlayBut.Location = new System.Drawing.Point(174, 161);
            this.PlayBut.Name = "PlayBut";
            this.PlayBut.Size = new System.Drawing.Size(75, 23);
            this.PlayBut.TabIndex = 5;
            this.PlayBut.Text = "Play";
            this.PlayBut.UseVisualStyleBackColor = true;
            this.PlayBut.Click += new System.EventHandler(this.PlayBut_Click);
            // 
            // OpenBut
            // 
            this.OpenBut.Location = new System.Drawing.Point(216, 41);
            this.OpenBut.Name = "OpenBut";
            this.OpenBut.Size = new System.Drawing.Size(64, 108);
            this.OpenBut.TabIndex = 6;
            this.OpenBut.Text = "Otworz nagrania";
            this.OpenBut.UseVisualStyleBackColor = true;
            this.OpenBut.Click += new System.EventHandler(this.OpenBut_Click);
            // 
            // listBoxRecordings
            // 
            this.listBoxRecordings.FormattingEnabled = true;
            this.listBoxRecordings.Location = new System.Drawing.Point(12, 41);
            this.listBoxRecordings.Name = "listBoxRecordings";
            this.listBoxRecordings.Size = new System.Drawing.Size(198, 108);
            this.listBoxRecordings.TabIndex = 7;
            // 
            // MicVolumeBar
            // 
            this.MicVolumeBar.Location = new System.Drawing.Point(12, 237);
            this.MicVolumeBar.Name = "MicVolumeBar";
            this.MicVolumeBar.Size = new System.Drawing.Size(104, 45);
            this.MicVolumeBar.TabIndex = 8;
            this.MicVolumeBar.Value = 5;
            this.MicVolumeBar.Scroll += new System.EventHandler(this.MicVolumeBar_Scroll);
            // 
            // MasterVolumeBar
            // 
            this.MasterVolumeBar.Location = new System.Drawing.Point(12, 315);
            this.MasterVolumeBar.Name = "MasterVolumeBar";
            this.MasterVolumeBar.Size = new System.Drawing.Size(104, 45);
            this.MasterVolumeBar.TabIndex = 9;
            this.MasterVolumeBar.Value = 5;
            this.MasterVolumeBar.Scroll += new System.EventHandler(this.MasterVolumeBar_Scroll);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(35, 216);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(48, 13);
            this.label1.TabIndex = 10;
            this.label1.Text = "Mikrofon";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(22, 299);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(74, 13);
            this.label2.TabIndex = 11;
            this.label2.Text = "MasterVolume";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuToolStripMenuItem,
            this.nagrywanieToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1028, 24);
            this.menuStrip1.TabIndex = 12;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // menuToolStripMenuItem
            // 
            this.menuToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.zamknijToolStripMenuItem});
            this.menuToolStripMenuItem.Name = "menuToolStripMenuItem";
            this.menuToolStripMenuItem.Size = new System.Drawing.Size(50, 20);
            this.menuToolStripMenuItem.Text = "Menu";
            // 
            // zamknijToolStripMenuItem
            // 
            this.zamknijToolStripMenuItem.Name = "zamknijToolStripMenuItem";
            this.zamknijToolStripMenuItem.Size = new System.Drawing.Size(117, 22);
            this.zamknijToolStripMenuItem.Text = "Zamknij";
            this.zamknijToolStripMenuItem.Click += new System.EventHandler(this.zamknijToolStripMenuItem_Click);
            // 
            // nagrywanieToolStripMenuItem
            // 
            this.nagrywanieToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.playToolStripMenuItem,
            this.stopToolStripMenuItem,
            this.playNagranieToolStripMenuItem,
            this.odtworzNagranieToolStripMenuItem});
            this.nagrywanieToolStripMenuItem.Name = "nagrywanieToolStripMenuItem";
            this.nagrywanieToolStripMenuItem.Size = new System.Drawing.Size(82, 20);
            this.nagrywanieToolStripMenuItem.Text = "Nagrywanie";
            // 
            // playToolStripMenuItem
            // 
            this.playToolStripMenuItem.Name = "playToolStripMenuItem";
            this.playToolStripMenuItem.Size = new System.Drawing.Size(168, 22);
            this.playToolStripMenuItem.Text = "Nagrywaj";
            this.playToolStripMenuItem.Click += new System.EventHandler(this.playToolStripMenuItem_Click);
            // 
            // stopToolStripMenuItem
            // 
            this.stopToolStripMenuItem.Name = "stopToolStripMenuItem";
            this.stopToolStripMenuItem.Size = new System.Drawing.Size(168, 22);
            this.stopToolStripMenuItem.Text = "Stop";
            this.stopToolStripMenuItem.Click += new System.EventHandler(this.stopToolStripMenuItem_Click);
            // 
            // playNagranieToolStripMenuItem
            // 
            this.playNagranieToolStripMenuItem.Name = "playNagranieToolStripMenuItem";
            this.playNagranieToolStripMenuItem.Size = new System.Drawing.Size(168, 22);
            this.playNagranieToolStripMenuItem.Text = "Play nagranie";
            this.playNagranieToolStripMenuItem.Click += new System.EventHandler(this.playNagranieToolStripMenuItem_Click);
            // 
            // odtworzNagranieToolStripMenuItem
            // 
            this.odtworzNagranieToolStripMenuItem.Name = "odtworzNagranieToolStripMenuItem";
            this.odtworzNagranieToolStripMenuItem.Size = new System.Drawing.Size(168, 22);
            this.odtworzNagranieToolStripMenuItem.Text = "Odtworz nagranie";
            this.odtworzNagranieToolStripMenuItem.Click += new System.EventHandler(this.odtworzNagranieToolStripMenuItem_Click);
            // 
            // player3
            // 
            this.player3.Location = new System.Drawing.Point(12, 378);
            this.player3.Name = "player3";
            this.player3.Size = new System.Drawing.Size(746, 167);
            this.player3.TabIndex = 2;
            // 
            // player2
            // 
            this.player2.Location = new System.Drawing.Point(147, 202);
            this.player2.Name = "player2";
            this.player2.Size = new System.Drawing.Size(709, 170);
            this.player2.TabIndex = 1;
            // 
            // player1
            // 
            this.player1.Location = new System.Drawing.Point(286, 28);
            this.player1.Name = "player1";
            this.player1.Size = new System.Drawing.Size(709, 168);
            this.player1.TabIndex = 0;
            this.player1.Load += new System.EventHandler(this.player1_Load_1);
            // 
            // OknoGlowne
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1028, 556);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.MasterVolumeBar);
            this.Controls.Add(this.MicVolumeBar);
            this.Controls.Add(this.listBoxRecordings);
            this.Controls.Add(this.OpenBut);
            this.Controls.Add(this.PlayBut);
            this.Controls.Add(this.StopBut);
            this.Controls.Add(this.RecordBut);
            this.Controls.Add(this.player3);
            this.Controls.Add(this.player2);
            this.Controls.Add(this.player1);
            this.Controls.Add(this.menuStrip1);
            this.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "OknoGlowne";
            this.Text = "OknoGlowne";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.OknoGlowne_FormClosing);
            this.Load += new System.EventHandler(this.OknoGlowne_Load);
            ((System.ComponentModel.ISupportInitialize)(this.MicVolumeBar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.MasterVolumeBar)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Player player1;
        private Player player2;
        private Player player3;
        private System.Windows.Forms.Button RecordBut;
        private System.Windows.Forms.Button StopBut;
        private System.Windows.Forms.Button PlayBut;
        private System.Windows.Forms.Button OpenBut;
        private System.Windows.Forms.ListBox listBoxRecordings;
        private System.Windows.Forms.TrackBar MicVolumeBar;
        private System.Windows.Forms.TrackBar MasterVolumeBar;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem menuToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem zamknijToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem nagrywanieToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem playToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem stopToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem playNagranieToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem odtworzNagranieToolStripMenuItem;
    }
}