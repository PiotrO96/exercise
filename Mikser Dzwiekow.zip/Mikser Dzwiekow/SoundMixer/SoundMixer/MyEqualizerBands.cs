﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SoundMixer
{
    public class MyEqualizerBands
    {
        public float Frequency { get; set; }
        public float Gain { get; set; }
        public float Bandwidth { get; set; }

    }
}
