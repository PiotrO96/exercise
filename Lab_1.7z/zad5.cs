﻿using System;
using System.Linq;

namespace Lab1
{
    class Program
    {
        static void Main(string[] args)
        {
            Matrix3x3 matrix = new Matrix3x3();

            Console.WriteLine("Suma elementów: " + matrix.SumValues());
            Console.WriteLine("Największa wartość: " + matrix.FindMaxValue());

        }
        private class Matrix3x3
        {
            public double[,] matrix;

            public Matrix3x3()
            {
                Random rnd = new Random((int)DateTime.Now.Ticks);
                matrix = new double[3, 3];

                for (int x = 0; x < matrix.GetLength(0); x++)
                {
                    for (int y = 0; y < matrix.GetLength(1); y++)
                    {
                        matrix[x,y] = Math.Round(rnd.NextDouble() * (20 - 1) + 1, 2);
                    }
                }
            }

            public double SumValues()
            {
                double sum = 0;

                for (int x = 0; x < matrix.GetLength(0); x++)
                {
                    for (int y = 0; y < matrix.GetLength(1); y++)
                    {
                        sum += matrix[x, y];
                    }
                }

                return sum;
            }

            public double FindMaxValue() => matrix.Cast<double>().Max();
        }

    }

}
