using System;

public class Program
{
    public static void Main()
    {
        Rectangle rectangle = new Rectangle(5, 20);
        Console.WriteLine("Pole kwadratu o bokach " + rectangle.SideA + " i " + rectangle.SideA + " wynosi " + rectangle.Field);
        Rectangle square = new Rectangle(5);
        Console.WriteLine("Pole kwadratu o boku " + square.SideA + " wynosi " + square.Field);
    }

    private class Shape
    {
        public double SideA { get; set; }
        public double SideB { get; set; }
        public double Field => SideA * SideB;
    }

    private class Rectangle : Shape
    {
        public Rectangle(double side)
        {
            SideA = side;
            SideB = side;
        }

        public Rectangle(double sideA, double sideB)
        {
            SideA = sideA;
            SideB = sideB;
        }
    }
}