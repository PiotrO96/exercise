using System;
                    
public class Program
{
    public static void Main()
    {
        double a;
		double b;
		
		Console.WriteLine("Podaj pierwszą liczbę:");
		a = Convert.ToDouble(Console.ReadLine());
		Console.WriteLine("Podaj drugą liczbę:");
		b = Convert.ToDouble(Console.ReadLine());
		
		Console.WriteLine("Suma liczb: " + ObliczSume(a,b));
		Console.WriteLine("Średnia liczb: " + ObliczSrednia(a,b));
    }
	
	private static double ObliczSume(double a, double b){
		return a+b;
	}
	
	private static double ObliczSrednia(double a, double b){
		return (a+b)/2;
	}
}