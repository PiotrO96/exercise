using System;
                    
public class Program
{
    public static void Main()
    {
        double a;
		double b;
		
		Console.WriteLine("Podaj pierwszą liczbę:");
		a = Convert.ToDouble(Console.ReadLine());
		Console.WriteLine("Podaj drugą liczbę:");
		b = Convert.ToDouble(Console.ReadLine());

		var sum = a+b;
		var average = (a+b)/2;
		
		Console.WriteLine("Suma liczb: " + sum);
		Console.WriteLine("Średnia liczb: " + average);
    }
}