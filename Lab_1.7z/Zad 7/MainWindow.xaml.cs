﻿using System.Collections.Generic;
using System.Windows;

namespace Lab1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        List<Person> people = new List<Person>();

        public MainWindow()
        {
            InitializeComponent();
            people.AddRange(new List<Person>{
                new Person("Jan", "Nowak"),
                new Person("Jan", "Nowak"),
                new Person("Jan", "Nowak"),
                new Person("Jan", "Nowak"),
                new Person("Jan", "Nowak")
            });
            personList.ItemsSource = people;
        }

        public class Person
        {
            public string Name { get; set; }
             
            public string Surname { get; set; }

            public string GetFullName()
            {
                return Name + " " + Surname;
            }

            public Person(string name, string surname)
            {
                Name = name;
                Surname = surname;
            }
        }

        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            AddWindow addWindow = new AddWindow();
            addWindow.Show();
        }

        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            if(personList.SelectedItem != null)
            {
                people.Remove((Person)personList.SelectedItem);
                personList.Items.Refresh();
            }
        }

        public void AddPerson(string name, string surname)
        {
            people.Add(new Person(name, surname));
            personList.Items.Refresh();
        }
    }
}
