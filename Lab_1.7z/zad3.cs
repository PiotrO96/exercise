using System;

namespace Lab1
{
    class Program
    {
        static void Main(string[] args)
        {
            double[] numbers = new double[10];

            for(int i = 0; i < numbers.Length; i++)
            {
                Console.WriteLine("Podaj liczbę numer " + (i + 1));
                numbers[i] = Convert.ToDouble(Console.ReadLine());
            }

            foreach(double number in numbers)
            {
                Console.WriteLine(number);
            }
        }
    }
}
