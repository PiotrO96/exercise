using System;

namespace Lab1
{
    class Program
    {
        static void Main(string[] args)
        {
            double[] numbers = new double[15];
            Random rnd = new Random((int)DateTime.Now.Ticks);

            for (int i = 0; i < numbers.Length; i++)
            {
                numbers[i] = Math.Round(rnd.NextDouble() * (20 - 1) + 1, 2);
            }

            double sum = 0;

            for (int i = 0; i < numbers.Length; i++)
            {
                if (i % 2 != 1)
                {
                    sum += numbers[i];
                }
            }

            Console.WriteLine("Suma elementów o parzystym indeksie tablicy: " + sum);
        }
    }
}
